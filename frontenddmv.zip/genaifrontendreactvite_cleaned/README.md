# SmartPal Virginia

This is a web application designed to provide information about various bills in Virginia.

## Prerequisites

Note: Please ensure you have installed <code><a href="https://nodejs.org/en/download/">nodejs</a></code>

To preview and run the project on your device:

1. Open project folder in <a href="https://code.visualstudio.com/download">Visual Studio Code</a>
2. In the terminal, run `npm install`
3. Run `npm start` to view project in browser

## Project Structure

src/
├── components/
│ ├── chatUi/
│ │ ├── BotMessage.jsx
│ │ ├── ChatInterfaceBill.jsx
│ │ ├── ChatInterfaceDmv.jsx
│ │ ├── ChatResponse.jsx
│ │ ├── CircularLoader.jsx
│ │ ├── FeedbackAccordion.jsx
│ │ ├── ScrollableCards.jsx
│ │ ├── SuggestiveQuestionContent.jsx
│ │ └── UserInput.jsx
│ ├── common/
│ │ ├── ReusableFAQ.jsx
│ │ ├── ReusableModal.jsx
│ │ └── ThemeToggle.jsx
│ ├── contexts/
│ │ ├── BillContext.jsx
│ │ ├── CustomContext.jsx
│ │ ├── DmvContext.jsx
│ │ └── ThemeContext.jsx
│ ├── History/
│ │ ├── History.jsx
│ │ └── HistoryAccordion.jsx
│ ├── layouts/
│ │ ├── Sidebar/
│ │ │ ├── Sidebar.jsx
│ │ └── WithAuth.jsx
│ ├── SignIn/
│ │ ├── Buttons.jsx
│ │ ├── Input.jsx
│ │ ├── ChatUi.jsx
│ │ └── Section.jsx
├── pages/
│ ├── AdminContent.jsx
│ ├── CommonContent.jsx
│ ├── DMVContent.jsx
│ ├── Home.jsx
│ ├── LegislativeBillsContent.jsx
│ └── SignIn.jsx
├── styles/
│ ├── global.scss
│ ├── Home.scss
│ ├── SignIn.scss
├── utils/
│ ├── api.js
├── redux/
│ ├── actions/
│ │ ├── index.js
│ ├── reducers/
│ │ ├── index.js
│ │ ├── exampleReducer.js
│ ├── store.js
├── App.jsx
├── index.jsx
├── reportWebVitals.js
└── .gitignore
.env
.env.dev
.env.prod
.env.uat


# Deploy React + FastAPI to Azure Web App using VS Code (Azure Extensions)

This README gives **drop‑in, step‑by‑step** instructions to deploy a React frontend and a Python FastAPI backend to **Azure App Service** using **VS Code** and the **Azure App Service** extension. It covers both one‑click deploy and a repeatable GitHub Actions CI/CD, with tips to avoid common Oryx pitfalls (e.g., `No module named uvicorn`).

---

## 0) Prerequisites (do once)

* **Accounts & CLI**

  * Azure subscription (Contributor/Owner on target sub).
  * [Azure CLI](https://learn.microsoft.com/cli/azure/install-azure-cli) ≥ 2.55 (`az version`).
  * Node.js ≥ 18 LTS for local React build (`node -v`, `npm -v`).
  * Python 3.10–3.12 for FastAPI (`python --version`).
* **VS Code + Extensions**

  * VS Code latest.
  * Extensions: **Azure Account**, **Azure App Service**, **Azure Resources**, **Python**, **Pylance**.
* **Project Layout (example)**

  ```text
  repo-root/
  ├─ frontend/           # React app (Vite or CRA)
  │  ├─ package.json
  │  └─ ...
  └─ backend/            # FastAPI app
     ├─ main.py          # exposes `app = FastAPI()`
     ├─ requirements.txt # must include fastapi, uvicorn, gunicorn, etc.
     └─ startup.sh       # optional; see below
  ```

---

## 1) Prepare the Frontend (React)

1. **Install & build locally**

   ```bash
   cd frontend
   npm ci   # or: npm install
   npm run build
   npm run preview  # optional sanity check
   ```
2. **Ensure SPA routing works on Azure**

   * CRA: no additional config; Azure Oryx uses `pm2 serve` with `--spa` by default.
   * Vite: ensure `"build": { "outDir": "dist" }` (default). Azure will serve the build output.
3. **Optional: set API base URL**

   * Add `VITE_API_BASE` (or similar) and reference it in code via `import.meta.env.VITE_API_BASE`.

---

## 2) Prepare the Backend (FastAPI)

1. **Create `requirements.txt`** (minimum):

   ```txt
   fastapi
   uvicorn[standard]
   gunicorn
   ```

   Add any extras you use (pydantic, python-dotenv, azure-* SDKs, etc.).
2. **`main.py`** must expose `app`:

   ```python
   from fastapi import FastAPI
   app = FastAPI()

   @app.get("/healthz")
   def healthz():
       return {"status": "ok"}
   ```
3. **Startup command (recommended)**

   * We’ll tell App Service to run Gunicorn w/ Uvicorn worker:

     ```
     gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app --timeout 120 --keep-alive 5
     ```
   * You will set this as **Startup Command** in the App Service (see below).

---

## 3) Sign in to Azure in VS Code

1. Open VS Code → **View > Extensions**: confirm Azure extensions.
2. **Sign in**: Press `F1` → `Azure: Sign In` → choose your tenant/subscription.
3. In the **Azure** side bar, expand **Resources** and pick the correct subscription.

---

## 4) Create Azure Resources (one‑time)

### Option A — Let VS Code create during deploy (simplest)

You can deploy and choose **Create new Web App…** when prompted. Do this **twice**: once for frontend (Node) and once for backend (Python).

### Option B — Create with CLI (more control)

```bash
# Variables (edit)
SUB="<your-subscription-id>"
RG="my-rg-react-fastapi"
LOC="eastus"
PLAN="my-linux-plan"
APP_FE="my-react-frontend"
APP_BE="my-fastapi-backend"

az account set --subscription $SUB
az group create -n $RG -l $LOC
az appservice plan create -g $RG -n $PLAN --is-linux --sku P1v3

# Frontend (Node runtime is inferred by Oryx at deploy time)
az webapp create -g $RG -p $PLAN -n $APP_FE --runtime "NODE:18LTS"

# Backend (Python runtime)
az webapp create -g $RG -p $PLAN -n $APP_BE --runtime "PYTHON:3.12"

# Configure Backend startup command
az webapp config set -g $RG -n $APP_BE --startup-file \
  "gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app --timeout 120 --keep-alive 5"

# (Optional) Application settings / env vars
az webapp config appsettings set -g $RG -n $APP_BE \
  --settings "ENV=prod" "CORS_ORIGINS=https://$APP_FE.azurewebsites.net"
```

---

## 5) Deploy the Frontend from VS Code (Zip Deploy)

1. In VS Code, open **frontend** folder.
2. Press `F1` → `Azure App Service: Deploy to Web App…` → select subscription → select **$APP_FE**.
3. When prompted `Always deploy the workspace?` choose **Yes** (or set later).
4. VS Code zips & deploys. Azure **Oryx** will:

   * Detect Node app → run `npm install` and `npm run build`.
   * Serve the built assets via `pm2 serve /home/site/wwwroot --no-daemon --spa`.
5. After deploy, open the site: `https://$APP_FE.azurewebsites.net`.

**Tip:** If your React build artifacts live in `dist/` or `build/`, don’t pre‑zip just the folder—deploy the project root and let Oryx build it. If you *must* deploy prebuilt static files, place them at repo root and add `staticwebapp.config.json` or a `routes.json` equivalent; but Oryx build is easiest.

---

## 6) Deploy the Backend from VS Code (Zip Deploy)

1. Open **backend** folder in VS Code.
2. Ensure `requirements.txt` at project root and `main.py` exposes `app`.
3. Press `F1` → `Azure App Service: Deploy to Web App…` → select **$APP_BE**.
4. After deploy, verify startup command is set (Portal → App Service → **Configuration** → **General settings** → **Startup Command**):

   ```
   gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app --timeout 120 --keep-alive 5
   ```
5. Browse: `https://$APP_BE.azurewebsites.net/healthz` → expect `{ "status": "ok" }`.

**Common fix:** If you see `ModuleNotFoundError: No module named 'uvicorn'` or `No module named 'gunicorn'`, confirm both are in `requirements.txt`, redeploy, and **Restart** the Web App.

---

## 7) Configure CORS (Frontend ↔ Backend)

* Easiest: Handle CORS in FastAPI.

  ```python
  from fastapi.middleware.cors import CORSMiddleware
  app.add_middleware(
      CORSMiddleware,
      allow_origins=["https://<APP_FE>.azurewebsites.net", "http://localhost:5173"],
      allow_credentials=True,
      allow_methods=["*"],
      allow_headers=["*"],
  )
  ```
* Or set `CORS_*` app settings in Azure and read them at startup.

---

## 8) Wire Up Frontend to Backend

* In React, set `VITE_API_BASE=https://<APP_BE>.azurewebsites.net` in **App Service → Configuration → Application settings** (for the frontend app). Access it at runtime via `import.meta.env.VITE_API_BASE`.
* Re‑deploy frontend (or use CI/CD) after changing.

---

## 9) Optional: CI/CD via GitHub Actions (click‑ops)

1. In VS Code Azure side bar, right‑click each Web App → **Configure Deployment Source** → **GitHub Actions**.
2. Follow prompts (repo, branch, runtime). VS Code will push a workflow like:

   * **Frontend**: checkout → setup Node → `npm ci` → `npm run build` → `azure/webapps-deploy@v2`.
   * **Backend**: checkout → setup Python → `pip install -r requirements.txt` → `azure/webapps-deploy@v2`.
3. Push to `main` to trigger builds and deployments.

---

## 10) Logs, SSH, Kudu (Advanced Ops)

* **Logs (live)**: Portal → App Service → **Log stream**.
* **Container/Process logs**: Portal → **Log stream** and **Diagnostics settings** (enable App Service logs).
* **SSH**: Portal → App Service → **SSH** (in‑browser shell).
* **Kudu**: `https://<app>.scm.azurewebsites.net/` → Debug console, process explorer, site files under `site/wwwroot`.

---

## 11) Troubleshooting Cheatsheet

* **React shows 404 on refresh**: Ensure SPA mode. Oryx’s default `pm2 serve ... --spa` should handle this. If not, add a `routes.json` with a catch‑all to `index.html`.
* **White page / build didn’t run**: Confirm Oryx detected Node. Check **Log stream** for `Oryx` messages. Ensure `package.json` has a `build` script.
* **FastAPI 500 on boot**: Check `Startup Command`, `requirements.txt`, and Python runtime version matches your local.
* **`No module named uvicorn/gunicorn`**: Add to `requirements.txt`, redeploy, **Restart**.
* **Large deps timeout**: Consider `SCM_DO_BUILD_DURING_DEPLOYMENT=true` (default for Zip Deploy) and increase timeout on Gunicorn. For heavier stacks, use **Docker**.

---

## 12) (Optional) Docker‑based Deploys from VS Code

If you prefer containers (repeatable across environments):

1. Add a `Dockerfile` in **backend** (example):

   ```dockerfile
   FROM mcr.microsoft.com/azure-functions/python:4-python3.12
   # or: FROM python:3.12-slim
   WORKDIR /app
   COPY backend/ ./
   RUN pip install --no-cache-dir -r requirements.txt
   EXPOSE 8000
   CMD gunicorn -w 4 -k uvicorn.workers.UvicornWorker main:app -b 0.0.0.0:8000
   ```
2. VS Code: **Docker: Build Image** → **Azure App Service: Create Web App…** → **Docker** → push to ACR.
3. For React, use `nginx:alpine` and copy build to `/usr/share/nginx/html`.

> **Note**: The guide above uses **non‑Docker Zip Deploy** because it’s the fastest path with the Azure App Service extension.

---

## 13) Clean Up

```bash
az group delete -n my-rg-react-fastapi --yes --no-wait
```

---

## 14) Quick Checklist (Copy/Paste)

* [ ] `frontend`: `npm ci && npm run build` works locally.
* [ ] `backend`: `requirements.txt` includes `fastapi`, `uvicorn[standard]`, `gunicorn`.
* [ ] `main.py` exposes `app`.
* [ ] Backend Startup Command set to Gunicorn/Uvicorn.
* [ ] Frontend env var points to backend URL.
* [ ] CORS allow list includes frontend origin.
* [ ] Logs verified in **Log stream**.

**You’re deployed!** Frontend: `https://<APP_FE>.azurewebsites.net` → talks to Backend: `https://<APP_BE>.azurewebsites.net`.
