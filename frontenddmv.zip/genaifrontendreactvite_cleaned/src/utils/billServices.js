import { fetchEventSource } from "@microsoft/fetch-event-source";
import { convertToUserTimezone } from "./datetimeUtils.jsx";

export const backendAppUrl = import.meta.env.VITE_APP_BACKEND_URL;
export const backendBillsUrl = import.meta.env.VITE_BILLS_BACKEND_URL;
export const backendVdotspecUrl = import.meta.env.VITE_VDOTSPEC_BACKEND_URL;
export const backendDmvUrl = import.meta.env.VITE_DMV_BACKEND_URL;

const backendUrls = {
  SuggestiveCard: `${backendAppUrl}/app/cards`,
  feedbackRating: `${backendAppUrl}/feedback/rating`,
  setSessionHistory: `${backendAppUrl}/history/setsession`,
  getAllHistoryList: `${backendAppUrl}/history/all`,
  getChatHistory: `${backendAppUrl}/history/getsession`,
  getsuggestiveQuestion: `${backendAppUrl}/history/suggestivequestion`,
  chatCompletion: `${backendBillsUrl}/bills/chatcompletion/stream`,
  /*  Add more URLs as needed */
};

export const setCardsTitles = async (
  User,
  setBillState,
  accessToken,
  setError
) => {
  try {
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify({
        card_id: "1",
        user_id: User,
        app_type: "legislativebills",
      }),
    };

    const response = await fetch(backendUrls.SuggestiveCard, requestOptions);

    if (!response.ok) {
      throw new Error(`Failed to fetch cards. Status: ${response.status}`);
    }

    const data = await response.json();

    setBillState((prevState) => ({
      ...prevState,
      cards: data.output,
    }));
  } catch (error) {
    console.error("Error getting suggestive questions:", error);
    setBillState((prevState) => ({
      ...prevState,
      cards: [],
    }));
    setError(
      "cards",
      "Something wrong with loading the cards. Please try again & if the issue persists, contact Administrator."
    );
  }
};

export const updateRating = async (ratingContext, accessToken, setError) => {
  if (!ratingContext) return;
  try {
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(ratingContext),
    };

    const response = await fetch(backendUrls.feedbackRating, requestOptions);

    if (!response.ok) {
      throw new Error(`Failed to update rating. Status: ${response.status}`);
    }

    const data = await response.json();
    console.log("Connection made message", data.output);
    return data;
  } catch (error) {
    console.error("Error updating rating:", error);
    setError(
      "ratings",
      "Something wrong with loading the ratings. Please try again & if the issue persists, contact Administrator."
    );
    throw error;
  }
};

export const setHistory = async (
  sessionuuid,
  User,
  setBillState,
  accessToken,
  setError
) => {
  try {
    setBillState((prevState) => ({
      ...prevState,
      isLoading: true,
    }));

    /*  let backendUrl = "https://dev01-appsvc-backendbillscopilot.azurewebsites.net/openaillm/history/setsession";
     if (isUAT) { 
     let backendUrl = 
       "https://dev01-appsvc-backendbillscopilot.azurewebsites.net/openaillm/history/setsession"; 
     } */

    const historyContext = {
      chat_id: sessionuuid,
      user_id: User,
      app_type: "legislativebills",
    };

    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(historyContext),
    };

    const response = await fetch(backendUrls.setSessionHistory, requestOptions);

    if (!response.ok) {
      throw new Error(
        `Failed to set session history. Status: ${response.status}`
      );
    }

    const data = await response.json();
    console.log("Connection made message setHistory", data.output);

    setBillState((prevState) => ({
      ...prevState,
      message: "",
    }));

    getHistoryList(sessionuuid, User, setBillState, accessToken, setError);
  } catch (error) {
    console.error("Error setting session history:", error);
    setError(
      "setHistory",
      "'Something wrong with setting the history. Please try again & if the issue persists, contact Administrator.'"
    );
  } finally {
    setBillState((prevState) => ({
      ...prevState,
      isLoading: false,
    }));
  }
};

export const getHistoryList = async (
  sessionuuid,
  User,
  setBillState,
  accessToken,
  setError
) => {
  try {
    const historyContext = {
      chat_id: sessionuuid,
      user_id: User,
      app_type: "legislativebills",
    };

    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(historyContext),
    };

    const response = await fetch(backendUrls.getAllHistoryList, requestOptions);

    if (!response.ok) {
      throw new Error(
        `Failed to fetch history data. Status: ${response.status}`
      );
    }

    const data = await response.json();
    // console.log("Connection made message history", data.output);

    let parseddata = JSON.parse(data.output);
    let newArray = [];
    if (parseddata) {
      parseddata.map((historydata) => {
        let obj = {
          id: historydata["_id"],
          topic: historydata.topic,
          chatid: historydata.chatid,
          insertedDate: convertToUserTimezone(historydata.insertedDate),
        };
        newArray.push(obj);
      });
    }

    setBillState((prevState) => ({
      ...prevState,
      historyData: newArray,
      isLoading: false,
    }));
  } catch (error) {
    console.error("Error fetching history data:", error);
    setError(
      "historyList",
      "Something wrong with loading the list. Please try again & if the issue persists, contact Administrator."
    );
  }
};

export const getHistory = async (
  updateUrl,
  User,
  chat_id,
  setBillState,
  accessToken,
  newSession,
  setError,
  setHasErrorClass
) => {
  // updateUrl(chat_id);
  setBillState((prevState) => ({
    ...prevState,
    isLoadingchat: true,
    isCentered: false,
  }));
  try {
    let historyContext = {
      chat_id: chat_id,
      user_id: User,
      app_type: "legislativebills",
    };

    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(historyContext),
    };
    const response = await fetch(backendUrls.getChatHistory, requestOptions);
    if (!response.ok) {
      throw new Error(
        `Failed to fetch history data. Status: ${response.status}`
      );
    }

    const data = await response.json();
    console.log(
      "Connection made message history details",
      JSON.parse(data.output)
    );

    const parseddata = JSON.parse(data.output);
    let isFirsttime = true;
    let chatid = "";
    let msgs = [];
    let assistantContentfromRes = {};
    let ratingfromRes = {};
    let feedbackfromRes = {};
    let expandedQuestions = {};
    let submittedQuestions = {};

    parseddata.map((chat, index) => {
      chatid = chat.chatid;
      msgs.push({ role: "user", content: chat.userquery });
      msgs.push({ role: "Assistant", content: "" });

      ratingfromRes = {
        ...ratingfromRes,
        [msgs.length]: {
          thumbsUp: chat.user_feedback_sentiment == "Positive" ? 1 : 0,
          thumbsDown: chat.user_feedback_sentiment == "Negative" ? 1 : 0,
          item: null,
          user_comment:
            chat.user_feedback_sentiment == "Negative"
              ? chat.user_feedback_comment
              : "",
          question_id: chat._id,
        },
      };
      if (chat.user_feedback_sentiment == "Negative") {
        feedbackfromRes = {
          ...feedbackfromRes,
          [chat._id]: chat.user_feedback_comment,
        };
        expandedQuestions = {
          [chat._id]: false,
        };

        submittedQuestions = {
          [chat._id]: chat.user_feedback_comment ? true : false,
        };
      }

      console.log("rating", ratingfromRes);
      assistantContentfromRes = {
        ...assistantContentfromRes,
        [msgs.length]: { content: chat.gptresponse },
      };
    });

    const sessionData = {
      chatid: chatid,
      assistantContentfromRes: assistantContentfromRes,
      ratingfromRes: ratingfromRes,
      feedbackfromRes: feedbackfromRes,
      expandedQuestions: expandedQuestions,
      submittedQuestions: submittedQuestions,
      msgs: msgs,
    };
    newSession(sessionData);
    setBillState((prevState) => ({
      ...prevState,
      isLoadingchat: false,
    }));
  } catch (error) {
    console.error("Error fetching history data:", error);
    setHasErrorClass(true);
    setError(
      "getHistory",
      "Something wrong with loading the chat history. Please try again & if the issue persists, contact Administrator."
    );
  }
};

export const getSuggestiveQuestion = async (
  chatId,
  User,
  setBillState,
  accessToken,
  setError
) => {
  try {
    let request = {
      chat_id: chatId,
      user_id: User,
      app_type: "legislativebills",
    };
    const requestOptions = {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(request),
    };

    const response = await fetch(
      backendUrls.getsuggestiveQuestion,
      requestOptions
    );

    if (!response.ok) {
      throw new Error(
        `Failed to set session history. Status: ${response.status}`
      );
    }

    const data = await response.json();

    setBillState((prevState) => ({
      ...prevState,
      suggestiveQuestions: data.output,
    }));
  } catch (error) {
    console.error("Error getting suggestive questions:", error);
    setError(
      "suggestive",
      "Something wrong with loading the suggestive questions. Please try again & if the issue persists, contact Administrator."
    );
  }
};

export const fetchChatData = async (
  User,
  request,
  setBillState,
  chats,
  ratings,
  scrollableDivRef,
  assistantContent,
  sessionuuid,
  accessToken,
  setError
) => {
  let msgs = chats;

  await fetchEventSource(backendUrls.chatCompletion, {
    method: "POST",
    openWhenHidden: true,
    headers: {
      "Content-Type": "application/json",
      Accept: "text/event-stream",
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify(request),
    mode: "cors",
    onopen(res) {
      if (res.ok && res.status === 200) {
        console.log("Connection made ", res);
      } else if (res.status >= 400 && res.status < 500 && res.status !== 429) {
        console.log("Client-side error ", res);
        setBillState((prevState) => ({
          ...prevState,
          isTyping: false,
          isLLMLoadingInProgress: false,
        }));
        throw new Error();
      }
    },
    onmessage(event) {
      console.log(event.data);
      if (
        !event.data.includes("Custom_Information_Used_By_LLM") &&
        !event.data.includes("Custom_Information_Used_By_LLM_QuestionID:")
      ) {
        if (
          event.data != "" &&
          event.data != undefined &&
          event.data != "None"
        ) {
          const parsedData = decodeURIComponent(
            escape(window.atob(event.data))
          );
          const index = msgs.length;
          const updateassistantContent = { ...assistantContent };
          updateassistantContent[index].content += parsedData;
          setBillState((prevState) => ({
            ...prevState,
            assistantContent: updateassistantContent,
          }));

          if (scrollableDivRef.current) {
            scrollableDivRef.current.scrollTop =
              scrollableDivRef.current.scrollHeight;
          }
        }
      } else {
        if (event.data.includes("Custom_Information_Used_By_LLM:")) {
          const index = msgs.length;
          const json_string = event.data.replace(
            "Custom_Information_Used_By_LLM:",
            ""
          );
          const list_of_arrays = JSON.parse(
            decodeURIComponent(escape(window.atob(json_string)))
          );
          const updateRatings = { ...ratings };
          updateRatings[index].item = list_of_arrays;
          setBillState((prevState) => ({
            ...prevState,
            ratings: updateRatings,
          }));
        } else if (
          event.data.includes("Custom_Information_Used_By_LLM_QuestionID:")
        ) {
          const index = msgs.length;
          const question_id = event.data.replace(
            "Custom_Information_Used_By_LLM_QuestionID:",
            ""
          );
          const updateRatings = { ...ratings };
          updateRatings[index].question_id = question_id;
          setBillState((prevState) => ({
            ...prevState,
            ratings: updateRatings,
            isExpanded: {
              ...prevState.isExpanded,
              [question_id]: false,
            },
          }));
        }
      }
    },
    onclose() {
      console.log("Connection closed by the server");
      setHistory(sessionuuid, User, setBillState, accessToken, setError);
      setBillState((prevState) => ({
        ...prevState,
        isTyping: false,
        isLLMLoadingInProgress: false,
      }));
      getSuggestiveQuestion(
        sessionuuid,
        User,
        setBillState,
        accessToken,
        setError
      );
    },
    onerror(err) {
      console.log("There was an error from server", err);
      setBillState((prevState) => ({
        ...prevState,
        isTyping: false,
        isLLMLoadingInProgress: false,
      }));
      setError(
        "fetchChat",
        "Something wrong with loading the chat. Please try again & if the issue persists, contact Administrator."
      );
      throw new Error();
    },
  });
};
