import moment from "moment-timezone";

export const convertToUserTimezone = (datetime) => {
  if (!datetime) return datetime; // Early return for invalid input

  const userTimezone = moment.tz.guess();
  const isoDatetime = convertToISO8601(datetime);

  const formattedDatetime = moment
    .tz(isoDatetime, userTimezone)
    .format("MM-DD-YYYY HH:mm:ss");
  console.log(formattedDatetime); // Log the converted datetime
  return formattedDatetime;
};

const convertToISO8601 = (datetime) => {
  const parsedDatetime = moment(datetime, "MM-DD-YYYY HH:mm:ss", true); // Use strict parsing
  if (!parsedDatetime.isValid()) {
    throw new Error(
      "Invalid datetime format. Please provide datetime in 'MM-DD-YYYY HH:mm:ss' format."
    );
  }
  return parsedDatetime.toISOString(); // Convert to ISO 8601 format
};
