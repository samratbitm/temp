import { fetchEventSource } from "@microsoft/fetch-event-source";
import { getHistoryList, backendAppUrl } from "./billServices";

const backendUrls = {
  exportUrl: `${backendAppUrl}/history/export`,
  deleteUrl: `${backendAppUrl}/history/delete`,
  /*  Add more URLs as needed */
};

export const deleteHistoryItem = async (
  chatId,
  User,
  accessToken,
  setBillState,
  setError
) => {
  const request = {
    chat_id: chatId,
    user_id: User,
    app_type: "legislativebills",
  };
  try {
    const response = await fetch(backendUrls.deleteUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      throw new Error(
        `Failed to delete history item. Status: ${response.status}`
      );
    }

    await getHistoryList(chatId, User, setBillState, accessToken, setError);
    setBillState((prevState) => ({
      ...prevState,
      chats: [],
    }));
  } catch (error) {
    console.error("Error deleting history item:", error);
    setError(
      "delete",
      "Something wrong with deleting the history. Please try again & if the issue persists, contact Administrator."
    );
    throw error;
  }
};

export const exportChat = async (chatId, User, setError) => {
  const request = {
    chat_id: chatId,
    user_id: User,
    app_type: "dmv",
  };

  try {
    const response = await fetch(backendUrls.exportUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(request),
    });

    if (!response.ok) {
      throw new Error("Network response was not ok");
    }

    debugger;
    // Extract the filename from the Content-Disposition header
    const disposition = response.headers.get('content-disposition') || response.headers.get('Content-Disposition');
    const filename = disposition
      ? disposition.split('filename=')[1].replace(/"/g, '') // Extract filename
      : 'download.pdf'; // Default filename if not provided

    const blob = await response.blob(); // Convert to a Blob object
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");

    link.href = url;
    link.setAttribute("download", filename); // Specify the filename
    document.body.appendChild(link);
    link.click();
    // link.parentNode.removeChild(link);
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url); // Clean up the URL
  } catch (error) {
    console.error("Error exporting chat:", error);
    setError(
      "export",
      "Something wrong with exporting the history. Please try again & if the issue persists, contact Administrator."
    );
    throw error;
  }
};
