import { useEffect } from "react";
import { Routes, Route, useNavigationType, useLocation, Navigate } from "react-router-dom";
import { MsalProvider } from "@azure/msal-react";
import { msalInstance } from "./Config.js";

import Home from "./pages/Home.jsx";
import DMVContent from "./pages/DMVContent.jsx";
import SignIn from "./pages/SignIn.jsx";
import CommonContent from "./pages/CommonContent.jsx";

import withAuth from "./components/layouts/WithAuth.jsx";
import { CustomContextProvider } from "./components/contexts/CustomContext.jsx";
import { DmvProvider } from "./components/contexts/DmvContext.jsx";
import { ErrorProvider } from "./components/contexts/ErrorContext.jsx";

const HomeAuth = withAuth(Home);
const CommonContentAuth = withAuth(CommonContent);

export default function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  // Basic page meta updates (optional)
  useEffect(() => {
    let title = "GenAI DMV Assistant";
    let metaDescription = "DMV assistant experience.";

    if (pathname.startsWith("/home/dmv")) {
      title = "DMV";
      metaDescription = "DMV assistant.";
    } else if (pathname === "/") {
      title = "Sign In";
      metaDescription = "Sign in to continue.";
    }

    document.title = title;
    const meta = document.querySelector('meta[name="description"]');
    if (meta) meta.setAttribute("content", metaDescription);
  }, [action, pathname]);

  return (
    <MsalProvider instance={msalInstance}>
      <CustomContextProvider>
        <ErrorProvider>
          <DmvProvider>
            <Routes>
              <Route path="/" element={<SignIn />} />

              <Route path="/home" element={<HomeAuth type="default" />}>
                <Route index element={<Navigate to="/home/dmv" replace />} />
                <Route path="dmv" element={<CommonContentAuth />} />
                <Route path="dmv-page" element={<DMVContent />} />
                <Route path="*" element={<Navigate to="/home/dmv" replace />} />
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </DmvProvider>
        </ErrorProvider>
      </CustomContextProvider>
    </MsalProvider>
  );
}
