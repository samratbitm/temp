import { PublicClientApplication } from "@azure/msal-browser";

const msalConfig = {
  auth: {
    clientId: "83c997c6-2f99-4150-9cd7-d94cde803602",
    redirectUrl: " http://localhost:5173",
    scopes: ["user.read"],
    authority:
      "https://login.microsoftonline.com/shantatexplorers.onmicrosoft.com",
  },
};

export const msalInstance = new PublicClientApplication(msalConfig);
