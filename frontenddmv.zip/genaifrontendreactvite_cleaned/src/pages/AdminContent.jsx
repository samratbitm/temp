import { Outlet } from "react-router-dom";
import Sidebar from "../components/layouts/sidebar/Sidebar";

function AdminContent() {
  return (
    <div className="main-content">
      <Sidebar type="admin" />
      <div className="header-parent">{/* <Outlet /> */}</div>
    </div>
  );
}

export default AdminContent;
