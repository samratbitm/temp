import "../styles/Home.scss";
// import "../components/Sidebar/Sidebar.css"; check
import Sidebar from "../components/layouts/sidebar/Sidebar";
import React, { useEffect, useState } from "react";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Typography from "@mui/material/Typography";
import Link from "@mui/material/Link";
import {
  TextField,
  IconButton,
  Paper,
  InputAdornment,
  Tooltip,
  Menu,
  MenuItem,
} from "@mui/material";
import LogoutIcon from "@mui/icons-material/Logout";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import EmailOutlinedIcon from "@mui/icons-material/EmailOutlined";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import PhoneOutlinedIcon from "@mui/icons-material/PhoneOutlined";
import SendIcon from "@mui/icons-material/Send";
import MicIcon from "@mui/icons-material/Mic";
// import History from "../components/History/History";
// import ChatInterface from "../components/chatUi/ChatInterface";
import SearchIcon from "@mui/icons-material/Search";
import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import InfoIcon from "@mui/icons-material/Info";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import { useAuth } from "../components/contexts/CustomContext";
import LightModeIcon from "@mui/icons-material/LightMode";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import LightModeOutlinedIcon from "@mui/icons-material/LightModeOutlined";
import ThemeToggle from "../components/common/ThemeToggle";
import {
  Outlet,
  useNavigate,
  useOutletContext,
  useLocation,
} from "react-router-dom";
import { useTheme } from "../components/contexts/ThemeContext";

const Home = ({ type }) => {
  const { theme, logoSrc, texLogoSrc } = useTheme();
  const [query, setQuery] = useState("");
  const [anchorEl, setAnchorEl] = useState(null);
  const [email, setEmail] = useState(sessionStorage.getItem("email"));
  const [displayname, setDisplayName] = useState(
    sessionStorage.getItem("displayname")
  );
  const [phone, setPhone] = useState(sessionStorage.getItem("phone"));
  const navigate = useNavigate();
  const location = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showHistoryOnly, setShowHistoryOnly] = useState(false);
  // const displayname = localStorage.getItem("displayname") != "" || "No name provided";
  // const email = localStorage.getItem("email") != "" || "No Email provided";
  // const displayname = localStorage.getItem("phone") != "" || "No Ph. provided";
  // Function to handle search input change
  const handleNavigation = (path) => {
    navigate(path);
  };

  const handleSearchInputChange = (event) => {
    const query = event.target.value;
    setQuery(query);
  };
  const handleProfileClick = (e) => {
    setAnchorEl(e.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };
  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  const toggleHistory = () => {
    setShowHistoryOnly(true);
  };

  useEffect(() => {
    const userState = sessionStorage.getItem("username");
    if (!userState) {
      navigate("/");
    }
  }, []);

  const handleLogout = () => {
    // clear local storage, redirect to login page
    sessionStorage.clear();
    navigate("/");
    handleClose(); // Close menu after logout
    console.log("Logout clicked");
  };

  const contextProps = {
    query: query,
    showHistoryOnly: showHistoryOnly,
    onClosebtn: () => setShowHistoryOnly(false),
    setShowHistoryOnly: setShowHistoryOnly,
  };

  return (
    <div className="home">
      <div className="header">
        <div className="tex-logo-wrapper">
          {/* <img
              className="tex-logo-icon"
              loading="lazy"
              alt=""
              src="/Tex Logo.svg"
            /> */}
          <img
            className="image-6-icon"
            loading="lazy"
            alt=""
            onClick={() => handleNavigation("/home/dmv")}
            // src="/image 6.svg"
            src={logoSrc}
          />
        </div>
        {/* <div className="misc">
              <div className="misc-child" />
              <div className="background">
                <div className="background-child" />
                <div className="search-icon-wrapper">
                  <img className="search-icon" alt="" src="/search-icon.svg" />
                </div>
                <input
                  className="search"
                  placeholder="Search History"
                  type="text"
                />
              </div>
              <div className="search-field">
                <img
                  className="notifications-none-icon"
                  loading="lazy"
                  alt=""
                  src="/notifications-none.svg"
                />
              </div>
              <div className="moon-solid-1-wrapper">
                <img
                  className="moon-solid-1-icon"
                  loading="lazy"
                  alt=""
                  src="/moonsolid-1.svg"
                />
              </div>
              <div className="search-field1">
                <img
                  className="info-outline-icon"
                  loading="lazy"
                  alt=""
                  src="/info-outline.svg"
                />
              </div>
              <img
                className="misc-item"
                loading="lazy"
                alt=""
                src="/Account circle.svg"
              />
            </div> */}
        <Paper elevation={3} className="misc">
          <TextField
            value={query}
            placeholder="Search History"
            variant="filled"
            onChange={handleSearchInputChange}
            sx={{
              "& .MuiFilledInput-root": {
                backgroundColor: "var(--color-sidebarHover) ",
                borderRadius: "var(--br-30xl)",
                height: "40px",
              },
              "& .MuiInputAdornment-root": {
                margin: "0 !important",
              },
              "& .MuiFilledInput-input": {
                padding: "0px !important",

                "&::placeholder": {
                  color: "var(--color-sidebarToggle)", // Change placeholder color
                  opacity: 0.6, // Ensure placeholder is not transparent
                },
              },
            }}
            InputProps={{
              disableUnderline: true,
              startAdornment: (
                <InputAdornment position="start">
                  <IconButton>
                    <SearchIcon className="search-icon" />
                  </IconButton>
                </InputAdornment>
              ),
            }}
          />
          {/* <div className="search-field">
                <IconButton>
                  <NotificationsNoneIcon className="notifications-none-icon" />
                </IconButton>
              </div> */}
          <IconButton
            sx={{ marginRight: 1, color: "#757575" }}
            onClick={() => handleNavigation("/admin/prompt")}
          >
            <SettingsOutlinedIcon />
          </IconButton>
          <ThemeToggle />

          <img
            className="user-input-child"
            loading="lazy"
            alt=""
            src="/Account circle.svg"
            onClick={handleProfileClick}
          />
          {/* {isLogout && (
                <div className="tooltip-content">
                  <Tooltip title="Logout">
                    <IconButton onClick={handleLogout}>
                      <LogoutIcon />
                    </IconButton>
                  </Tooltip>
                </div>
              )} */}
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
            sx={{
              "& .MuiPaper-root": {
                width: "auto",
                backgroundColor: "var(--color-white)",
              },
            }}
          >
            <MenuItem
              style={{ backgroundColor: "transparent", fontFamily: "Lato" }}
            >
              <PersonOutlineIcon sx={{ marginRight: 1, color: "#757575" }} />

              <Typography
                // className="custom-typography"
                variant="body1"
                sx={{
                  fontSize: "14px",
                  lineHeight: "1.875rem",
                  color: "var(--color-darkslategray-100)",
                }}
                className="menu-text"
              >
                {displayname}
              </Typography>
            </MenuItem>
            <div className="separator" />
            <MenuItem
              style={{ backgroundColor: "transparent", fontFamily: "Lato" }}
            >
              <EmailOutlinedIcon sx={{ marginRight: 1, color: "#757575" }} />

              <Typography
                // className="custom-typography"
                variant="body1"
                sx={{
                  fontSize: "14px",
                  lineHeight: "1.875rem",
                  color: "var(--color-darkslategray-100)",
                }}
                className="menu-text"
              >
                {email}
              </Typography>
            </MenuItem>

            <div className="separator" />
            <MenuItem
              style={{ backgroundColor: "transparent", fontFamily: "Lato" }}
            >
              <PhoneOutlinedIcon sx={{ marginRight: 1, color: "#757575" }} />

              <Typography
                // className="custom-typography"
                variant="body1"
                sx={{
                  fontSize: "14px",
                  lineHeight: "1.875rem",
                  color: "var(--color-darkslategray-100)",
                }}
                className="menu-text"
              >
                {phone}
              </Typography>
            </MenuItem>
            <div className="separator" />
            <MenuItem
              onClick={handleLogout}
              style={{ backgroundColor: "transparent", fontFamily: "Lato" }}
            >
              <LogoutIcon sx={{ marginRight: 1, color: "#757575" }} />

              <Typography
                // className="custom-typography"
                variant="body1"
                sx={{
                  fontSize: "14px",
                  lineHeight: "1.875rem",
                  color: "var(--color-darkslategray-100)",
                }}
                className="menu-text"
              >
                Logout
              </Typography>
            </MenuItem>
          </Menu>
          {/* <IconButton>
                <AccountCircleIcon className="misc-item" />
              </IconButton> */}
        </Paper>
      </div>
      <div className="overlay-button-wrapper">
        <button className="toggle-button" onClick={toggleSidebar}>
          {"❭"}
        </button>
        <button className="toggle-button" onClick={toggleHistory}>
          {"❬"}
        </button>
      </div>
      <div className="main-content">
        <Sidebar type={type}></Sidebar>
        <Outlet context={query} />
      </div>
      {isSidebarOpen && (
        <div class="overlay sidebar-overlay">
          <Sidebar
            type={type}
            isOpen={isSidebarOpen}
            onClose={() => setIsSidebarOpen(false)}
          ></Sidebar>
        </div>
      )}
      {showHistoryOnly && (
        <div class="overlay history-overlay">
          <Outlet context={contextProps} />
        </div>
      )}
      <div className="footer">
        <div className="tex-logo-wrapper">
          <img
            className="tex-logo-icon"
            loading="lazy"
            alt=""
            src={texLogoSrc}
          />
        </div>
      </div>
    </div>
  );
};

export default Home;
