import Input from "../components/signIn/Input";
import Buttons from "../components/signIn/Buttons";
import Checkbox from "@mui/material/Checkbox";
import React, { useState, useCallback, useEffect } from "react";
import Typography from "@mui/material/Typography";
import { useNavigate } from "react-router-dom";
import FormControlLabel from "@mui/material/FormControlLabel";
import "../styles/SignIn.scss";
import { useAuth } from "../components/contexts/CustomContext";
import { Button } from "@mui/material";
import {
  useMsal,
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
} from "@azure/msal-react";
import { msalInstance } from "../Config";

const SignIn = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const navigate = useNavigate();
  const { authenticated, setAuthenticated } = useAuth();

  // const { instance, accounts } = useMsal();

  // const handleLogin = async () => {
  //   try {
  //     const loginResponse = await instance.loginPopup();
  //     console.log("Login Response:", loginResponse);
  //   } catch (error) {
  //     console.error("Login Error:", error);
  //   }
  // };

  // const handleLogout = async () => {
  //   try {
  //     instance.logoutPopup();
  //   } catch (error) {
  //     console.error("Logout Error:", error);
  //   }
  // };

  useEffect(() => {
    const isvalidUser = sessionStorage.getItem("isvalidUser");
    if (isvalidUser == "true") {
      setAuthenticated(true);
      navigate("/home/dmv");
    } else {
      setAuthenticated(false);
    }
  }, []);

  const handleSubmit = async(loginResponse) => {

      debugger;
      
      const hardcodedEmail = loginResponse.account.username;
      const displayname = loginResponse.account.name;
      const hardcodedPassword = "Virginiabills@genaidemo";
      // navigate("/home/dmv");
      // setAuthenticated(true);
      const isvalidUser = sessionStorage.getItem("isvalidUser");

      if (isvalidUser == "true") {
        setAuthenticated(true);
        navigate("/home/dmv", { state: { email: hardcodedEmail } });
      } else {
        // Reset previous errors
        setEmailError("");
        setPasswordError("");

        // // Validation
        // if (!email) {
        //   setEmailError("Email is required");
        // } else if (email != "" && email.toLowerCase() !== hardcodedEmail) {
        //   setEmailError("Invalid email");
        // }
        // if (!password) {
        //   setPasswordError("Password is required");
        // } else if (password !== hardcodedPassword) {
        //   setPasswordError("Invalid password");
        // }

        // If no errors, set as valid user and navigate
        if (loginResponse != "" && loginResponse.account.username != "") {
          sessionStorage.setItem("isvalidUser", "true");
          sessionStorage.setItem("username", loginResponse.account.username);
          sessionStorage.setItem("email", loginResponse.account.username);
          sessionStorage.setItem("displayname", loginResponse.account.name);
          sessionStorage.setItem("accessToken", loginResponse.accessToken);
          sessionStorage.setItem("phone", "(703) 555-7890");
          setAuthenticated(true);
          navigate("/home/dmv");
        }
      }
  };    
  

  return (
    <div className="sign-in">
      <div className="sign-in1">
        <div className="left">
          {/* <b className="welcome-to-texplorers">Welcome to texplorers</b> */}
          <img
            className="unsplashhaaskezbhac-icon"
            alt=""
            src="/unsplashhaaskezbhac@2x.png"
          />
        </div>
        <div className="right">
          <form>
            <Buttons onlogin={handleSubmit} />
          </form>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
