import React from "react";
// import ChatInterface from './ChatInterface';
// import History from "./History";
// import DMVContent from "../pages/DMVContent";
// import DMVContent from "../pages/DMVContent";

function DMVContent() {
  return (
    <div>
      <p>
        The DMV implementation is in progress. This feature will be available
        soon.
      </p>
    </div>
  );
}

export default DMVContent;
