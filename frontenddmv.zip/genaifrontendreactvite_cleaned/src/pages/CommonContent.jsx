import "../styles/Home.scss";
import React from "react";
import { useOutletContext } from "react-router-dom";
import ChatInterfaceDmv from "../components/chatUi/ChatInterfaceDmv";

const CommonContent = () => {
  const context = useOutletContext();

  const hasAllValues =
    context &&
    typeof context === "object" &&
    "query" in context &&
    "showHistoryOnly" in context &&
    "setShowHistoryOnly" in context;

  const query = hasAllValues ? context.query : context ?? "";
  const showHistoryOnly = hasAllValues ? context.showHistoryOnly : false;
  const onClosebtn =
    hasAllValues && typeof context.onClosebtn === "function"
      ? context.onClosebtn
      : () => {};

  return (
    <ChatInterfaceDmv
      query={query}
      showHistoryOnly={showHistoryOnly}
      onClosebtn={onClosebtn}
    />
  );
};

export default CommonContent;
