//  AuthContext.js */
import React, { createContext, useState, useContext } from "react";

//  Create the context */
const CustomContext = createContext();

//  Create a provider component */
export const CustomContextProvider = ({ children }) => {
  const [authenticated, setAuthenticated] = useState(false);

  return (
    <CustomContext.Provider value={{ authenticated, setAuthenticated }}>
      {children}
    </CustomContext.Provider>
  );
};

//  Custom hook to consume the context */
export const useAuth = () => useContext(CustomContext);
// export default CustomContextProvider; check