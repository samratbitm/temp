import React, { createContext, useState, useRef, useContext } from "react";
import { v4 as uuidv4 } from "uuid";

//  Create the context */
export const DmvContext = createContext();

export const DmvProvider = ({ children }) => {
  const [dmvState, setDmvState] = useState({
    cards: [],
    message: "",
    chats: [],
    isTyping: false,
    isLLMLoadingInProgress: false,
    assistantContent: {},
    ratings: {},
    countmessage: "0/200",
    isScrollable: false,
    //  showModal: false, */
    items: [],
    isUAT: true,
    GPTVersion: "4",
    data: [],
    isCentered: false,
    selectedValue: [],
    isDataLoaded: false,
    //  isValidUser: false, */
    sessionuuid: uuidv4(),
    historyData: [],
    isLoading: true,
    isLoadingchat: false,
    copied: false,
    isExpanded: {},
    isUpAccordionVisible: false,
    feedback: {},
    isSubmitted: {},
    suggestiveQuestions: [],
    elRefs: useRef([]),
    inputRef: useRef(null),
    scrollableDivRef: useRef(null),
    linksContainerRef: useRef(null),
    responseRef: useRef(null),
    //  headers: ["Score", "Content"], */
  });

  return (
    <DmvContext.Provider value={{ dmvState, setDmvState }}>
      {children}
    </DmvContext.Provider>
  );
};

// export default DmvContext; check