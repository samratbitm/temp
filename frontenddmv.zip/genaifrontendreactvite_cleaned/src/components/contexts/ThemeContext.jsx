import React, { createContext, useState, useEffect, useContext } from "react";

const ThemeContext = createContext();

export const useTheme = () => useContext(ThemeContext);

export const ThemeProvider = ({ children }) => {
  // Define paths for logos for both themes
  const logos = {
    light: {
      logoSrc: "/VirginiaLogoLight.svg",
      texLogoSrc: "/TexLogoLight.svg",
    },
    dark: {
      logoSrc: "/VirginiaLogoDark.svg",
      texLogoSrc: "/TexLogoDark.svg",
    },
  };

  const [theme, setTheme] = useState("light");
  const [logoSrc, setLogoSrc] = useState(logos.light.logoSrc);
  const [texLogoSrc, setTexLogoSrc] = useState(logos.light.texLogoSrc);

  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
  };

  useEffect(() => {
    const storedTheme = sessionStorage.getItem("theme");
    if (storedTheme) {
      setTheme(storedTheme);
    }
  }, []);

  // const [logoSrc, setLogoSrc] = useState("/VirginiaLogoLight.svg");
  // const [texlogoSrc, setTexLogoSrc] = useState("/TexLogoLight.svg");
  // const toggleTheme = () => {
  //   setTheme((prevTheme) => (prevTheme === "light" ? "dark" : "light"));
  //   setLogoSrc((prevLogoSrc) =>
  //     prevLogoSrc.includes("Light")
  //       ? prevLogoSrc.replace("Light", "Dark")
  //       : prevLogoSrc.replace("Dark", "Light")
  //   );
  //   setTexLogoSrc((prevLogoSrc) =>
  //     prevLogoSrc.includes("Light")
  //       ? prevLogoSrc.replace("Light", "Dark")
  //       : prevLogoSrc.replace("Dark", "Light")
  //   );
  // };
  useEffect(() => {
    setLogoSrc(logos[theme].logoSrc);
    setTexLogoSrc(logos[theme].texLogoSrc);
    sessionStorage.setItem("theme", theme);
  }, [theme]);
  useEffect(() => {
    document.body.className = theme === "light" ? "light-theme" : "dark-theme";
    sessionStorage.setItem("theme", theme);
  }, [theme]);

  const contextValue = {
    theme,
    toggleTheme,
    logoSrc,
    texLogoSrc,
  };

  return (
    <ThemeContext.Provider value={contextValue}>
      {children}
    </ThemeContext.Provider>
  );
};

export default ThemeContext;
