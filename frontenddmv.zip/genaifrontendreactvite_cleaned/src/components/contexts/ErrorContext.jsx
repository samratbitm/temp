import React, { createContext, useState, useContext } from "react";

const ErrorContext = createContext();

export const ErrorProvider = ({ children }) => {
  const [errorMessages, setErrorMessages] = useState({});

  const setError = (key, message) => {
    setErrorMessages((prev) => ({ ...prev, [key]: message }));
  };

  const clearError = (key) => {
    setErrorMessages((prev) => {
      const newErrors = { ...prev };
      delete newErrors[key];
      return newErrors;
    });
  };

  return (
    <ErrorContext.Provider value={{ errorMessages, setError, clearError }}>
      {children}
    </ErrorContext.Provider>
  );
};

export const useError = () => useContext(ErrorContext);
