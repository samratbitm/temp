import "../../styles/Input.scss";
import React, { useState } from "react";
import { TextField, InputAdornment, IconButton } from "@mui/material";
import { Email, Lock, Visibility, VisibilityOff } from "@mui/icons-material";
import InputLabel from "@mui/material/InputLabel";

const Input = ({
  email,
  password,
  setEmail,
  setPassword,
  emailError,
  passwordError,
}) => {
  const [showPassword, setShowPassword] = useState(false);

  const handleClickShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const handleMouseDownPassword = (event) => {
    event.preventDefault();
  };
  const [focused, setFocused] = useState(false);

  const handleFocus = () => {
    setFocused(true);
  };

  const handleBlur = () => {
    setFocused(false);
  };

  return (
    <div className="input">
      <TextField
        id="dynamic-textfield"
        onFocus={handleFocus}
        onBlur={handleBlur}
        value={email}
        placeholder="Email"
        onChange={(e) => setEmail(e.target.value)}
        variant="outlined"
        error={!!emailError}
        helperText={emailError}
        className="customTextField"
        fullWidth
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Email style={{ color: "var(--color-steelblue)" }} />
            </InputAdornment>
          ),
        }}
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: "12px",
            backgroundColor: "white",
            padding: "0px 24px",
          },
          "& .MuiOutlinedInput-input": {
            padding: "10px 8px",
          },
        }}
      />
      <TextField
        id="password"
        error={!!passwordError}
        helperText={passwordError}
        placeholder="Password"
        className="customTextField"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        type={showPassword ? "text" : "password"}
        variant="outlined"
        fullWidth
        InputProps={{
          startAdornment: (
            <InputAdornment position="start">
              <Lock style={{ color: "var(--color-steelblue)" }} />
            </InputAdornment>
          ),
          endAdornment: (
            <InputAdornment position="end">
              <IconButton
                aria-label="toggle password visibility"
                onClick={handleClickShowPassword}
                onMouseDown={handleMouseDownPassword}
                edge="end"
                style={{ color: "var(--color-steelblue)" }}
              >
                {showPassword ? <VisibilityOff /> : <Visibility />}
              </IconButton>
            </InputAdornment>
          ),
        }}
        sx={{
          "& .MuiOutlinedInput-root": {
            borderRadius: "12px",
            backgroundColor: "white",
            // height: "100%",
            padding: "0px 24px",
          },
          "& .MuiOutlinedInput-input": {
            padding: "10px 8px",
          },
        }}
      />
    </div>
  );
};

export default Input;
