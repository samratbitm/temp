import "../../styles/Buttons.scss";
import { Button } from "@mui/material";
import Typography from "@mui/material/Typography";
import { useMsal, AuthenticatedTemplate } from "@azure/msal-react";
const Buttons = ({onlogin}) => {
  // const navigate = useNavigate();

  // const onSignInContainerClick = useCallback(() => {
  //   navigate("/home");
  // }, [navigate]);
  const { instance } = useMsal();

  const handleLogin = async () => {
    try {     
      // Use MSAL instance to handle login
      const loginResponse = await instance.loginPopup();
      console.log("Login Response:", loginResponse);
      const accessToken = loginResponse.accessToken;
      onlogin(loginResponse);
    } catch (error) {
      console.error("Login Error:", error);
      onlogin("");
    }
  };
  
  // const sendTokenToBackend = async (accessToken) => {
  //   try {
  //     const response = await fetch("https://your-backend-api.com/endpoint", {
  //       method: "POST",
  //       headers: {
  //         Authorization: `Bearer ${accessToken}`,
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify({}),
  //     });

  //     if (!response.ok) {
  //       throw new Error("Failed to send token to backend");
  //     }
  //     const data = await response.json();
  //     console.log("Response from backend:", data);
  //   } catch (error) {
  //     console.error("Failed to send token to backend:", error);
  //   }
  // };

  return (
    <div className="buttons">
      <Button
        variant="contained"
        onClick={handleLogin}
        sx={{
          borderRadius: "12px",
          backgroundColor: "var(--color-steelblue)",
          width: "100%",
          height: "110%",
        }}
      >
        Sign In
      </Button>
      <Button
        variant="contained"
        startIcon={
          <img
            src="/googleremovebgpreview-1@2x.png"
            width="24px"
            height="24px"
            alt="Google"
          />
        }
        sx={{
          borderRadius: "10px",
          backgroundColor: "var(--color-darkslategray-100)",
          width: "100%",
          height: "90%",
          textTransform: "none",
        }}
      >
        Continue with Google
      </Button>
      <a className="dont-have-an-container">
        <Typography>
          <span>
            <span>{`Don’t have an account? `}</span>
            <span className="sign-up">{`Sign Up `}</span>
          </span>
        </Typography>
      </a>
    </div>
  );
};

export default Buttons;
