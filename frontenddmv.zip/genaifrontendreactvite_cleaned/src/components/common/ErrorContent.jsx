import Typography from "@mui/material/Typography";

const ErrorContent = ({ message }) => {
  const typographyStyles = {
    fontSize: "14px",
    lineHeight: "1.875rem",
  };
  return (
    <Typography variant="body1" sx={typographyStyles} className="error-message">
      {message}
    </Typography>
  );
};

export default ErrorContent;
