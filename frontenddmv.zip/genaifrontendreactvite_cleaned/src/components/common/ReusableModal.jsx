import React from "react";
import { Button, Modal, Typography, Box } from "@mui/material";
import { WidthFull } from "@mui/icons-material";

const ReusableModal = ({
  open,
  handleClose,
  modalTitle,
  modalContent,
  confirmText,
  cancelText,
  onConfirm,
}) => {
  const modalStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  };

  const modalContainerStyle = {
    position: "absolute",
    // top: "50%",
    // left: "50%",
    // transform: "translate(-50%, -50%)",
    // width: "auto",
    maxWidth: "70vw",
    maxHeight: "90vh",
    minWidth: "40vw",
    minHeight: "20vh",
    backgroundColor: "var(--color-white)",
    boxShadow: "0px 4px 20px rgba(0, 0, 0, 0.1)",
    overflow: "hidden",
    padding: "16px",
  };

  const modalBodyStyle = {
    maxHeight: "calc(90vh - 128px)",
    overflowY: "auto",
    maxWidth: "100%",
  };
  const scrollbarStyle = `
  ::-webkit-scrollbar {
    width: 0;
  }
`;
  return (
    <Modal
      open={open}
      onClose={handleClose}
      aria-labelledby="modal-title"
      aria-describedby="modal-description"
      style={modalStyle}
    >
      <Box style={modalContainerStyle}>
        <style>{scrollbarStyle}</style>
        <Typography variant="h6" component="h2">
          {modalTitle}
        </Typography>
        <Box style={modalBodyStyle}>
          <Box mt={2}>{modalContent}</Box>
        </Box>
        <Box mt={2} textAlign="right">
          <Button onClick={handleClose} color="secondary">
            {cancelText}
          </Button>
          <Button
            onClick={onConfirm}
            variant="contained"
            color="primary"
            sx={{ ml: 2 }}
          >
            {confirmText}
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default ReusableModal;
