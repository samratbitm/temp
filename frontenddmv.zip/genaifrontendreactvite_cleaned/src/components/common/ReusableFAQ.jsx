import React, { useState, useEffect } from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { backendAppUrl } from "../../utils/billServices";

const FAQModal = () => {
  const [expanded, setExpanded] = useState(false);
  const [faqs, setFaqs] = useState([]);
  const [accessToken, setAccessToken] = useState(
    sessionStorage.getItem("accessToken")
  );

  const getFAQ = async () => {
    const BackendUrl = `${backendAppUrl}/app/faq/all`;

    fetch(BackendUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
    })
      .then((response) => response.json())
      .then((data) => {
        setFaqs(data.output);
      })
      .catch((error) => {
        console.error("Error fetching the FAQs:", error);
      });
  };

  useEffect(() => {
    getFAQ();
  }, []);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  return (
    <>
      {faqs.map((faq, index) => (
        <Accordion
          key={index}
          expanded={expanded === `panel${index}`}
          onChange={handleChange(`panel${index}`)}
          sx={{
            boxShadow: "none",
            borderBottom: "1px solid var(--primary-p7)",
            "&:before": {
              display: "none",
            },
            "&.Mui-expanded": {
              margin: "auto",
            },
            "&:last-child": {
              border: "none",
            },
            "&.MuiAccordion-root": {
              backgroundColor: "transparent !important",
            },
          }}
        >
          <AccordionSummary
            expandIcon={
              <ExpandMoreIcon
                sx={{
                  color: "var(--color-darkslategray-100)",
                }}
              />
            }
            aria-controls={`panel${index}a-content`}
            id={`panel${index}a-header`}
          >
            <Typography
              variant="body1"
              sx={{ color: "var(--color-darkslategray-100)" }}
            >
              {faq.question}
            </Typography>
          </AccordionSummary>
          <AccordionDetails>
            <Typography
              variant="body2"
              sx={{ color: "var(--color-darkslategray-100)" }}
            >
              {faq.answer}
            </Typography>
          </AccordionDetails>
        </Accordion>
      ))}
    </>
  );
};

export default FAQModal;
