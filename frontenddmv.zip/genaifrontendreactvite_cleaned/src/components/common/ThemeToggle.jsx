import React from "react";
import IconButton from "@mui/material/IconButton";
import DarkModeOutlinedIcon from "@mui/icons-material/DarkModeOutlined";
import { useTheme } from "../contexts/ThemeContext";

const ThemeToggle = () => {
  const { toggleTheme } = useTheme();

  return (
    <div className="search-field1">
      <IconButton onClick={toggleTheme} sx={{ color: "#757575" }}>
        <DarkModeOutlinedIcon className="info-outline-icon" />
      </IconButton>
    </div>
  );
};

export default ThemeToggle;
