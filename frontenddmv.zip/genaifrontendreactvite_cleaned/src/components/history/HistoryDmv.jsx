import "../../styles/Home.scss";
import { useState, useEffect } from "react";
import AddIcon from "@mui/icons-material/Add";
import MoreHorizIcon from "@mui/icons-material/MoreHoriz";
import CircularLoader from "../chatUi/CircularLoader";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import HistoryAccordionDmv from "./HistoryAccordionDmv";
import { useOutletContext } from "react-router-dom";
import { Button, IconButton } from "@mui/material";
import CloseIcon from "@mui/icons-material/Close";
import { backendAppUrl } from "../../utils/billServices";

const HistoryDmv = ({
  todays,
  settodays,
  previous7Days,
  setprevious7Days,
  lastMonth,
  setlastMonth,
  olderItems,
  setolderItems,
  selectedItemIndex,
  setSelectedItemIndex,
  sessionuuid,
  chats,
  newChatHandler,
  getHistory,
  setHistory,
  query,
  historyData,
  isLoading,
  getHistoryList,
  User,
  setChats,
  showHistoryOnly,
  onClosebtn,
}) => {
  // const [todays, settodays] = useState([]);
  // const [previous7Days, setprevious7Days] = useState([]);
  // const [lastMonth, setlastMonth] = useState([]);
  // const [olderItems, setolderItems] = useState([]);
  // const [selectedItemIndex, setSelectedItemIndex] = useState(null);

  const [expanded, setExpanded] = useState(null);
  const outletContext = useOutletContext();
  const handleChange = (panel) => {
    setExpanded(expanded === panel ? null : panel);
  };
  const groupByDate = (historyData) => {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Calculate exactly 7 days ago from today, including today
    const oneWeekAgo = new Date(today.getTime() - 6 * 24 * 60 * 60 * 1000);
    oneWeekAgo.setHours(0, 0, 0, 0);
    // Calculate the first day of the current month
    const firstDayOfCurrentMonth = new Date(
      today.getFullYear(),
      today.getMonth(),
      1
    );
    // // Ensure that oneWeekAgo is set to the beginning of the day
    // oneWeekAgo.setHours(0, 0, 0, 0);
    const todays = [];
    const previous7Days = [];
    const lastMonth = [];
    const olderItems = [];

    function isToday(date) {
      const today = new Date();
      return (
        date.getDate() === today.getDate() &&
        date.getMonth() === today.getMonth() &&
        date.getFullYear() === today.getFullYear()
      );
    }

    historyData.forEach((item) => {
      if (item.insertedDate) {
        const [dateStr, timeStr] = item.insertedDate.split(" ");
        const [month, day, year] = dateStr.split("-").map(Number);
        const [hour, minute, second] = timeStr.split(":").map(Number);

        // Create a Date object in GMT
        const itemDateGMT = new Date(
          Date.UTC(year, month - 1, day, hour, minute, second)
        );

        // Convert GMT to local time zone
        const itemDateLocal = new Date(
          itemDateGMT.toISOString().toLocaleString()
        ); // Converts to local time automatically

        // const itemDate = new Date(year, month - 1, day, hour, minute, second); // Month is 0-indexed in Date constructor

        if (isToday(itemDateLocal)) {
          todays.push(item);
        } else if (itemDateLocal >= oneWeekAgo) {
          previous7Days.push(item);
        } else if (itemDateLocal >= firstDayOfCurrentMonth) {
          lastMonth.push(item);
        } else {
          olderItems.push(item);
        }
      }
    });

    return { todays, previous7Days, lastMonth, olderItems };
  };
  useEffect(() => {
    const { todays, previous7Days, lastMonth, olderItems } = historyData
      ? groupByDate(historyData)
      : { todays: [], previous7Days: [], lastMonth: [], olderItems: [] };
    settodays(todays);
    setprevious7Days(previous7Days);
    setlastMonth(lastMonth);
    setolderItems(olderItems);
    if (selectedItemIndex != null && selectedItemIndex != sessionuuid) {
      setSelectedItemIndex(null);
    }
  }, [historyData]);

  const handleHistoryItemClick = (chatid) => {
    setSelectedItemIndex(chatid);
  };

  const deleteHistoryItem = async (chatId) => {
    try {
      let BackendUrl = `${backendAppUrl}/history/delete`;

      let request = {
        chat_id: chatId,
        user_id: User,
        app_type: "legislativebills",
      };
      fetch(BackendUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          // Authorization: `Bearer ${accessToken}`
        },
        body: JSON.stringify(request),
      })
        .then((res) => {
          if (res.status === 200) {
            getHistoryList();
            setChats([]);
          }
        })
        .catch((error) => {
          console.log(error);
        });
    } catch (error) {
      console.error("Error deleting history item:", error);
    }
  };

  const exportChat = async (chatId) => {
    try {
      let BackendUrl = `${backendAppUrl}/history/export`;
      let filename = 'DMV_History.pdf'; 

      let request = {
        chat_id: chatId,
        user_id: User,
        app_type: "dmv",
      };

      fetch(BackendUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(request),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Network response was not ok");
          }
          // Extract the filename from the Content-Disposition header             
          const disposition = response.headers.get('content-disposition') || response.headers.get('Content-Disposition');
          if (disposition) {
            const match = disposition.match(/filename="?([^"]+)"?/);
            if (match && match[1]) {
              filename = match[1].trim(); // Extract and set the filename
            }
          }
          
          return response.blob(); // Convert to a Blob object
        })
        .then((blob) => {
          // Create a link element, use it to trigger the download
          const url = window.URL.createObjectURL(new Blob([blob]));
          const link = document.createElement("a");
          link.href = url;
          link.setAttribute("download", filename); // Specify the filename
          document.body.appendChild(link);
          link.click();
          link.parentNode.removeChild(link);
        })
        .catch((error) => {
          console.error("There was an error!", error);
        });
    } catch (error) {
      console.error("Error exporting chat:", error);
    }
  };

  // Render history items
  const renderHistoryItems = () => {
    const todaysFiltered = query
      ? todays.filter((item) =>
          item.topic.toLowerCase().includes(query.toLowerCase())
        )
      : todays;
    const previous7DaysFiltered = query
      ? previous7Days.filter((item) =>
          item.topic.toLowerCase().includes(query.toLowerCase())
        )
      : previous7Days;
    const lastMonthFiltered = query
      ? lastMonth.filter((item) =>
          item.topic.toLowerCase().includes(query.toLowerCase())
        )
      : lastMonth;
    const OlderItemsFiltered = query
      ? olderItems.filter((item) =>
          item.topic.toLowerCase().includes(query.toLowerCase())
        )
      : olderItems;

    const sections = [
      {
        title: "Today",
        items: todaysFiltered,
      },
      {
        title: "Previous 7 Days",
        items: previous7DaysFiltered,
      },
      {
        title: "Previous 30 Days",
        items: lastMonthFiltered,
      },
      {
        title: "Older",
        items: OlderItemsFiltered,
      },
    ];
    return (
      <>
        {sections.map((section, index) => (
          <HistoryAccordionDmv
            key={section.items.chatid}
            title={section.title}
            items={section.items}
            selectedItemIndex={selectedItemIndex}
            getHistory={getHistory}
            handleHistoryItemClick={handleHistoryItemClick}
            deleteHistoryItem={deleteHistoryItem}
            exportChat={exportChat}
            expanded={expanded}
            onChange={handleChange}
          />
        ))}
      </>
    );
  };

  return (
    <div className={`history ${showHistoryOnly ? "open" : ""} `}>
      <IconButton
        className="close-btn"
        onClick={onClosebtn}
        style={{ color: "var(--color-dimgray-100)" }}
      >
        <CloseIcon />
      </IconButton>
      <Button
        sx={{
          flexDirection: "row",
          gap: "var(--gap-xs)",
          width: "100%",
          backgroundColor: "var(--color-blueviolet)",
          color: "var(--color-white)",
          padding: "var(--padding-2xs) 1rem",
          borderRadius: "6px",
          border: "1px solid rgba(0, 0, 0, 0.2)",
          cursor: "pointer",
          "&:hover": {
            backgroundColor: "darken",
          },
        }}
        variant="contained"
        color="primary"
        className="new-chat-button1"
        onClick={newChatHandler}
        startIcon={<AddIcon />}
      >
        New Topic
      </Button>

      {/* <div className="separator"></div> */}
      <div className="history-list">
        {isLoading ? (
          // Display loader while history items are loading
          <CircularLoader />
        ) : (
          // Once history items are loaded, render the history items component
          renderHistoryItems()
          // <>
          //   <section>
          //     <Typography variant="subtitle1">Previous 7 Days</Typography>
          //     <ul>
          //       {previous7Days.map((item) => (
          //         <>
          //           <Typography variant="body1" key={item.id}>
          //             {new Date(item.date).toDateString()}
          //           </Typography>
          //           <IconButton aria-label="more options">
          //             <MoreHorizIcon />
          //           </IconButton>
          //         </>
          //       ))}
          //     </ul>
          //   </section>
          //   {/* <section>
          //     <h2>Older</h2>
          //     <ul>
          //       {olderItems.map((item) => (
          //         <li key={item.id}>{new Date(item.date).toDateString()}</li>
          //       ))}
          //     </ul>
          //   </section> */}
          // </>
        )}
      </div>
      {/* <div className="history-list">{renderHistoryItems()}</div> */}
      {/* <div className="pagetitle-parent">
        <b className="pagetitle">Today</b>
        <div className="frame-parent2">
          <div className="pagetitle-group">
            <div className="pagetitle1">Your last question</div>
            <img
              className="more-horiz-icon"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="pagetitle-container">
            <div className="pagetitle2">hb 3</div>
            <img
              className="more-horiz-icon1"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="gpt-avatar">
            <div className="pagetitle3">How to write a code</div>
            <img className="more-horiz-icon2" alt="" src="/morehoriz.svg" />
          </div>
          <div className="history-more-button">
            <div className="pagetitle4">Lorem ipsum</div>
            <img className="more-horiz-icon3" alt="" src="/morehoriz.svg" />
          </div>
        </div>
      </div>
      <div className="history-item" />
      <div className="pagetitle-parent1">
        <b className="pagetitle5">Yesterday</b>
        <div className="frame-parent3">
          <div className="pagetitle-parent2">
            <div className="pagetitle6">Your last question</div>
            <img
              className="more-horiz-icon4"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="pagetitle-parent3">
            <div className="pagetitle7">hb 3</div>
            <img
              className="more-horiz-icon5"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="pagetitle-parent4">
            <div className="pagetitle8">How to write a code</div>
            <img
              className="more-horiz-icon6"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="pagetitle-parent5">
            <div className="pagetitle9">Lorem ipsum</div>
            <img
              className="more-horiz-icon7"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
        </div>
      </div>
      <div className="history-inner" />
      <div className="pagetitle-parent6">
        <b className="pagetitle10">Last 7 days</b>
        <div className="frame-parent4">
          <div className="pagetitle-parent7">
            <div className="pagetitle11">Your last question</div>
            <img
              className="more-horiz-icon8"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="pagetitle-parent8">
            <div className="pagetitle12">hb 3</div>
            <img
              className="more-horiz-icon9"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="pagetitle-parent9">
            <div className="pagetitle13">How to write a code</div>
            <img
              className="more-horiz-icon10"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
          <div className="pagetitle-parent10">
            <div className="pagetitle14">Lorem ipsum</div>
            <img
              className="more-horiz-icon11"
              loading="lazy"
              alt=""
              src="/morehoriz.svg"
            />
          </div>
        </div>
      </div> */}
    </div>
  );
};

export default HistoryDmv;
