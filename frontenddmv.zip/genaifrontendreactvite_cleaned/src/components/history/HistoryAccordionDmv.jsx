import React, { useState } from "react";
import {
  Typography,
  Grid,
  IconButton,
  Accordion,
  Box,
  AccordionSummary,
  AccordionDetails,
} from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import FileDownloadOutlined from "@mui/icons-material/FileDownloadOutlined";

const HistoryAccordionDmv = ({
  title,
  items,
  selectedItemIndex,
  getHistory,
  handleHistoryItemClick,
  deleteHistoryItem,
  exportChat,
  expanded,
  onChange,
}) => {
  return (
    <Accordion
      expanded={expanded === title}
      onChange={() => onChange(title)}
      sx={{
        boxShadow: "none",
        borderBottom: "1px solid var(--primary-p7)",
        "&:before": {
          display: "none",
        },
        "&.Mui-expanded": {
          margin: "auto 0",
        },
        "&:last-child": {
          border: "none",
        },
        "&.MuiAccordion-root": {
          backgroundColor: "transparent !important",
        },
      }}
    >
      <AccordionSummary
        expandIcon={
          <ExpandMoreIcon
            sx={{
              color: "var(--color-darkslategray-100)",
            }}
          />
        }
        sx={{ padding: "0px" }}
      >
        <Typography
          variant="subtitle1"
          sx={{ fontWeight: "bold", color: "var(--color-darkslategray-100)" }}
        >
          {title}
        </Typography>
      </AccordionSummary>
      <AccordionDetails sx={{ padding: "0px" }}>
        <Grid container direction="column">
          {items &&
            items.map((item) => (
              <Grid
                item
                key={item.chatid}
                className={`pagetitle-group ${
                  selectedItemIndex === item.chatid ? "selected" : ""
                }`}
                onClick={() => {
                  getHistory(item.chatid);
                  handleHistoryItemClick(item.chatid);
                }}
                style={{ cursor: "pointer" }}
              >
                <Typography
                  variant="body1"
                  sx={{
                    fontSize: "14px",
                    lineHeight: "1.2rem",
                    color: "var(--color-darkslategray-100)",
                  }}
                >
                  {item.topic}
                </Typography>
                <Box display="inline-flex">
                  <IconButton
                    className="history-icons"
                    onClick={(e) => {
                      e.stopPropagation(); // Prevent the click from propagating to the parent li
                      deleteHistoryItem(item.chatid);
                    }}
                  >
                    <DeleteOutlineIcon
                      sx={{
                        color: "#757575",
                      }}
                    />
                  </IconButton>
                  <IconButton
                    onClick={(e) => {
                      e.stopPropagation(); // Prevent the click from propagating to the parent li
                      exportChat(item.chatid);
                    }}
                    className="history-icons"
                  >
                    <FileDownloadOutlined sx={{ color: "#757575" }} />
                  </IconButton>
                </Box>
              </Grid>
            ))}
        </Grid>
      </AccordionDetails>
    </Accordion>
  );
};

export default HistoryAccordionDmv;
