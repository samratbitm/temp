import "../../../styles/Sidebar.scss";
import { useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Typography } from "@mui/material";
import DescriptionOutlinedIcon from "@mui/icons-material/DescriptionOutlined";

/**
 * Minimal sidebar kept for DMV + base APIs only.
 * Props are accepted to stay compatible with Home.jsx.
 */
export default function Sidebar({ type, isOpen, onClose }) {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = useMemo(() => {
    return (path) => location.pathname === path || location.pathname.startsWith(path + "/");
  }, [location.pathname]);

  const handleNav = (path) => {
    navigate(path);
    if (typeof onClose === "function") onClose();
  };

  return (
    <div className={`sidebar ${isOpen ? "open" : ""}`}>
      <div className="sidebar-header">
        <Typography variant="h6" className="sidebar-title">
          {type === "admin" ? "Admin" : "DMV Assistant"}
        </Typography>
      </div>

      <div className="nav-menu">
        <div
          className={`menu-item ${isActive("/home/dmv") ? "active" : ""}`}
          role="button"
          tabIndex={0}
          onClick={() => handleNav("/home/dmv")}
          onKeyDown={(e) => e.key === "Enter" && handleNav("/home/dmv")}
        >
          <DescriptionOutlinedIcon
            sx={{
              color: isActive("/home/dmv") ? "var(--color-blueviolet)" : "#757575",
            }}
          />
          <Typography variant="body1" sx={{ fontSize: "14px", marginLeft: "10px" }}>
            DMV
          </Typography>
        </div>
      </div>
    </div>
  );
}
