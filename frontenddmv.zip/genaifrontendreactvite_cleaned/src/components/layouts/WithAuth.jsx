import React from "react";
import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/CustomContext";

const withAuth = (WrappedComponent) => {
  const Auth = (props) => {
    const { authenticated, setAuthenticated } = useAuth();

    //  Check authentication status */
    if (!authenticated) {
      return <Navigate to="/" />;
    }

    //  Render the wrapped component if authenticated */
    return <WrappedComponent {...props} />;
  };

  return Auth;
};

export default withAuth;
