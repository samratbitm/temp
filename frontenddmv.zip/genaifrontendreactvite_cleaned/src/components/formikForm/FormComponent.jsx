import React, { useEffect, useState } from "react";
import { useFormik } from "formik";
import * as Yup from "yup";
import "./FormComponent.css";

// const fetchFormConfig = async () => {
//   const response = await fetch("/api/form-config");
//   const data = await response.json();
//   return data;
// };



const generateValidationSchema = (sections) => {
  const schema = sections.reduce((acc, section) => {
    section.fields.forEach((field) => {
      if (field.validation) {
        let validator = Yup.string();
        if (field.validation.required) {
          validator = validator.required("Required");
        }
        if (field.validation.minLength) {
          validator = validator.min(
            field.validation.minLength,
            `Minimum ${field.validation.minLength} characters`
          );
        }
        if (field.validation.min) {
          validator = Yup.number().min(
            field.validation.min,
            `Minimum value is ${field.validation.min}`
          );
        }
        if (field.validation.max) {
          validator = Yup.number().max(
            field.validation.max,
            `Maximum value is ${field.validation.max}`
          );
        }
        acc[field.name] = validator;
      }
    });
    return acc;
  }, {});

  return Yup.object(schema);
};

const FormComponent = ({
    formsubmittedfromparent,
    key,
    formconfig, 
    index, 
    handleFormConfigChange,
    submitvalid
  }) => {
  const [formConfig, setFormConfig] = useState(null); 
  const [formData, setFormData] = useState(null);
  
  // const extractFormValue = (formschema) => {
  //     // Initialize state from schema
  //     const initialData = {};
  //     formschema.sections.forEach(section => {
  //       section.fields.forEach(field => {
  //         formik.values[field.name] = field.value;
  //         formik.handleChange(field.name);
  //       });
  //     });      
  // };

  useEffect(() => {
    const loadConfig = async () => {
      debugger;
      console.log(key);
      console.log(index);
      setFormConfig(eval(formconfig));
      //setFormData(extractFormValue(eval(formconfig).formconfig));
    };
    // const loadConfig = async () => {
    //   const config = await fetchFormConfig();
    //   setFormConfig(config);
    // };
    loadConfig();
  }, [formconfig]);

  useEffect(() => {
    if (formsubmittedfromparent>0){
      formik.handleSubmit();
    }
  }, [formsubmittedfromparent]);

  const handleChange = async (e,fieldname) => {  
    e.preventDefault();    
    formik.handleChange(e);
    const updatedSchema = { ...formConfig };
    updatedSchema.sections.forEach(section => {
      section.fields.forEach(field => {
        if(field.name === e.target.name){
          field.value = e.target.value;
        }
      });
    });

    handleFormConfigChange(e,index+1,updatedSchema, false);   
  };   

  const formik = useFormik({
    initialValues: formConfig
      ? formConfig.sections.reduce((acc, section) => {
          section.fields.forEach((field) => {
            if (field.type === "checkbox") {
              acc[field.name] = field.value;
            } else {
              acc[field.name] = field.value;
            }
          });
          return acc;
        }, {})
      : {},
    validationSchema: formConfig
      ? generateValidationSchema(formConfig.sections)
      : null,
    onSubmit: async (values) => {
      debugger;
      try {
        const updatedSchema = { ...formConfig };
        updatedSchema.sections.forEach(section => {
          section.fields.forEach(field => {           
              field.value = values[field.name];            
          });
        });

        handleFormConfigChange(window.event,index+1,updatedSchema,true);

        console.log("Form submitted successfully:", result);
      } catch (error) {
        console.error("There was a problem with the submission:", error);
      }
    },
    enableReinitialize: true,
  });

  const renderField = (field) => {
    switch (field.type) {
      case "text":
      case "email":
      case "date":
      case "number":
        return (
          <div key={field.name} className="form-field">
            <label>{field.label}</label>
            <input
              type={field.type}
              name={field.name}
              onChange={(e)=>handleChange(e,field.name)}
              onBlur={formik.handleBlur}
              value={formik.values[field.name]}
            />
            {formik.touched[field.name] && formik.errors[field.name] ? (
              <div className="error">{formik.errors[field.name]}</div>
            ) : null}
          </div>
        );
      case "radio":
        return (
          <div key={field.name} className="form-field">
            <label>{field.label}</label>
            <div className="radio-group">
              {field.options.map((option) => (
                <label key={option} className="radio-option">
                  <input
                    type="radio"
                    name={field.name}
                    value={option}
                    onChange={(e)=>handleChange(e,field.name)}
                    onBlur={formik.handleBlur}
                    checked={formik.values[field.name] === option}
                  />
                  {option}
                </label>
              ))}
            </div>
            {formik.touched[field.name] && formik.errors[field.name] ? (
              <div className="error">{formik.errors[field.name]}</div>
            ) : null}
          </div>
        );
      case "checkbox":
        return (
          <div key={field.name} className="form-field">
            <label>{field.label}</label>
            {field.options.map((option) => (
              <label key={option} className="checkbox-option">
                <input
                  type="checkbox"
                  name={field.name}
                  value={option}
                  onChange={(e)=>handleChange(e,field.name)}
                  onBlur={formik.handleBlur}
                  //checked={formik.values[field.name]?.includes(option)}
                  checked={formik.values[field.name]?.includes(option)}
                />
                {option}
              </label>
            ))}
            {formik.touched[field.name] && formik.errors[field.name] ? (
              <div className="error">{formik.errors[field.name]}</div>
            ) : null}
          </div>
        );
      case "select":
        return (
          <div key={field.name} className="form-field">
            <label>{field.label}</label>
            <select
              name={field.name}
              onChange={(e)=>handleChange(e,field.name)}
              onBlur={formik.handleBlur}
              value={formik.values[field.name]}
            >
              <option value="" label="Select option" />
              {field.options.map((option) => (
                <option key={option} value={option} label={option} />
              ))}
            </select>
            {formik.touched[field.name] && formik.errors[field.name] ? (
              <div className="error">{formik.errors[field.name]}</div>
            ) : null}
          </div>
        );
      case "textarea":
        return (
          <div key={field.name} className="form-field">
            <label>{field.label}</label>
            <textarea
              name={field.name}
              onChange={(e)=>handleChange(e,field.name)}
              onBlur={formik.handleBlur}
              value={formik.values[field.name]}
            />
            {formik.touched[field.name] && formik.errors[field.name] ? (
              <div className="error">{formik.errors[field.name]}</div>
            ) : null}
          </div>
        );
      default:
        return null;
    }
  };

  const renderSection = (section) => {
    return (
      <div key={section.title} className="form-section">
        <h3 className="section-title">{section.title}</h3>
        <div className="form-row">
          {section.fields.map((field) => renderField(field))}
        </div>
      </div>
    );
  };

  if (!formConfig) {
    return "<div>Loading...</div>";
  }

  return (
    <form onSubmit={formik.handleSubmit} className="formik-form">
      {formConfig.sections.map((section) => renderSection(section))}
      <button type="submit" className="submit-button" style={{ display: submitvalid ? "block" : "none" }}>
        Submit
      </button>
    </form>
  );
};

export default FormComponent;