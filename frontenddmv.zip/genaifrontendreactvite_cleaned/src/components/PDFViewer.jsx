// import React, { useEffect, useRef, useState } from 'react';
// import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';
// import 'pdfjs-dist/web/pdf_viewer.css';

// // Configure the worker file
// GlobalWorkerOptions.workerSrc = `../../node_modules/pdfjs-dist/build/pdf.worker.js`;

// const PDFViewer = ({ pdfUrl, pageNumber, blockIndex }) => {
//     const canvasRef = useRef(null);
//     const [progress, setProgress] = useState(0); // State for download progress

//     useEffect(() => {
//         const loadPdf = async () => {
//             try {
//                 const loadingTask = getDocument({
//                     url: pdfUrl,
//                     withCredentials: false, // If using a public blob URL
//                 });

//                 // Track download progress
//                 loadingTask.onProgress = (progressData) => {
//                     const percent = Math.round((progressData.loaded / progressData.total) * 100);
//                     setProgress(percent);
//                 };

//                 const pdf = await loadingTask.promise;
//                 debugger;
//                 const page = await pdf.getPage(parseInt(pageNumber));
//                 const viewport = page.getViewport({ scale: 1.5 });

//                 // Render PDF page
//                 const canvas = canvasRef.current;
//                 const context = canvas.getContext('2d');
//                 canvas.width = viewport.width;
//                 canvas.height = viewport.height;

//                 const renderContext = {
//                     canvasContext: context,
//                     viewport,
//                 };
//                 await page.render(renderContext).promise;

//                 // Highlight specific block
//                 if (blockIndex !== null) {
//                     const textContent = await page.getTextContent();
//                     const block = textContent.items[parseInt(blockIndex)];
//                     if (block) {
//                         const { transform, width, height } = block;
//                         const x = transform[4];
//                         const y = transform[5] - height;

//                         context.fillStyle = 'rgba(255, 255, 0, 0.5)'; // Highlight color
//                         context.fillRect(x, viewport.height - y, width, height);
//                     }
//                 }
//             } catch (error) {
//                 console.error('Error loading PDF:', error);
//             }
//         };

//         loadPdf();
//     }, [pdfUrl, pageNumber, blockIndex]);

//     return (
//         <div style={{ position: 'relative' }}>
//             {/* Show download progress */}
//             {progress < 100 && (
//                 <div style={{ position: 'absolute', top: 0, left: 0, width: '100%', textAlign: 'center', backgroundColor: 'rgba(0, 0, 0, 0.5)', color: 'white', padding: '10px' }}>
//                     Loading PDF... {progress}%
//                 </div>
//             )}
//             <canvas ref={canvasRef} />
//         </div>
//     );
// };

// export default PDFViewer;
// import React, { useEffect, useRef, useState } from 'react';
// import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';
// import 'pdfjs-dist/web/pdf_viewer.css';

// // Configure the worker file
// GlobalWorkerOptions.workerSrc = `../../node_modules/pdfjs-dist/build/pdf.worker.js`;

// const PDFViewer = ({ pdfUrl, initialPageNumber = "1", blockIndex = null }) => {
//     const canvasRef = useRef(null);
//     const [progress, setProgress] = useState(0);
//     const [pdfInstance, setPdfInstance] = useState(null);
//     const [currentPage, setCurrentPage] = useState(parseInt(initialPageNumber));
//     const [zoomLevel, setZoomLevel] = useState(1.5);
//     const [controlsVisible, setControlsVisible] = useState(false);

//     // Load PDF document
//     useEffect(() => {
//         const loadPdf = async () => {
//             try {
//                 setControlsVisible(false);
//                 const storedPdf = sessionStorage.getItem(`${pdfUrl}_binary`);
//                 if (!storedPdf) {
//                     const loadingTask = getDocument({
//                         url: pdfUrl,
//                         withCredentials: false,
//                     });

//                     loadingTask.onProgress = (progressData) => {
//                         const percent = Math.round((progressData.loaded / progressData.total) * 100);
//                         setProgress(percent);
//                     };

//                     const pdf = await loadingTask.promise;

//                     // Save PDF to session storage
//                     const binaryData  = await loadingTask._transport.pdfDataRangeTransport._params.data; //await fetch(pdfUrl);
//                     // const arrayBuffer = await response.arrayBuffer();
//                     const base64String = btoa(
//                         String.fromCharCode(...new Uint8Array(binaryData))
//                     );
//                     sessionStorage.setItem(`${pdfUrl}_binary`, base64String);
//                     setPdfInstance(pdf);                    
//                 } else {
//                     // Load PDF from session storage
//                     const binaryData = Uint8Array.from(
//                         atob(storedPdf),
//                         (char) => char.charCodeAt(0)
//                     );
//                     const pdf = await getDocument({ data: binaryData }).promise;
//                     setPdfInstance(pdf);
//                 }
//             } catch (error) {
//                 console.error('Error loading PDF:', error);
//             }
//         };

//         loadPdf();
//     }, [pdfUrl]);

//     // Render PDF page
//     const renderPage = async (pageNumber) => {
//         if (!pdfInstance) return;

//         try {
//             const page = await pdfInstance.getPage(pageNumber);
//             const viewport = page.getViewport({ scale: zoomLevel });

//             const canvas = canvasRef.current;
//             const context = canvas.getContext('2d');
//             canvas.width = viewport.width;
//             canvas.height = viewport.height;

//             const renderContext = {
//                 canvasContext: context,
//                 viewport,
//             };

//             await page.render(renderContext).promise;

//             setControlsVisible(true);

//             // Highlight specific block
//             if (blockIndex !== null) {
//                 const textContent = await page.getTextContent();
//                 const block = textContent.items[parseInt(blockIndex)];
//                 if (block) {
//                     const { transform, width, height } = block;
//                     const x = transform[4];
//                     const y = transform[5] - height;

//                     context.fillStyle = 'rgba(255, 255, 0, 0.5)';
//                     context.fillRect(x, viewport.height - y, width, height);
//                 }
//             }
//         } catch (error) {
//             console.error('Error rendering page:', error);
//         }
//     };

//     useEffect(() => {
//         if (pdfInstance) {
//             renderPage(currentPage);
//         }
//     }, [pdfInstance, currentPage, zoomLevel, blockIndex]);

//     // Handle zoom
//     const handleZoomIn = () => setZoomLevel((prevZoom) => Math.min(prevZoom + 0.5, 3));
//     const handleZoomOut = () => setZoomLevel((prevZoom) => Math.max(prevZoom - 0.5, 0.5));

//     // Handle page navigation
//     const handleNextPage = () => {
//         if (currentPage < pdfInstance.numPages) {
//             setCurrentPage((prevPage) => prevPage + 1);
//         }
//     };

//     const handlePrevPage = () => {
//         if (currentPage > 1) {
//             setCurrentPage((prevPage) => prevPage - 1);
//         }
//     };

//     return (
//         <div style={{ position: 'relative' }}>
//             {/* Show download progress */}
//             {progress < 100 && (
//                 <div
//                     style={{
//                         position: 'absolute',
//                         top: 0,
//                         left: 0,
//                         width: '100%',
//                         height: '100%',
//                         display: 'flex',
//                         flexDirection: 'column',
//                         alignItems: 'center',
//                         justifyContent: 'center',
//                         backgroundColor: 'rgba(0, 0, 0, 0.5)',
//                         color: 'rgba(0, 0, 0, 0.5)',
//                         zIndex: 10,
//                     }}
//                 >
//                     <div style={{ textAlign: 'center', width: '80%' }}>
//                         <p style={{ fontSize: '18px', marginBottom: '10px' }}>Loading PDF... {progress}%</p>
//                         <progress
//                             value={progress}
//                             max="100"
//                             style={{
//                                 width: '100%',
//                                 height: '50px',
//                                 appearance: 'none',
//                                 backgroundColor: '#ddd',
//                                 borderRadius: '5px',
//                                 overflow: 'hidden',
//                             }}
//                         />
//                     </div>
//                 </div>
//             )}



//             {controlsVisible && (
//                 <div>
//                     <button onClick={handlePrevPage} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
//                         Previous Page
//                     </button>
//                     <button onClick={handleNextPage} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
//                         Next Page
//                     </button>
//                     <button onClick={handleZoomIn} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
//                         Zoom In
//                     </button>
//                     <button onClick={handleZoomOut} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
//                         Zoom Out
//                     </button>
//                 </div>
//             )}

//             <canvas
//                 ref={canvasRef}
//                 style={{
//                     border: controlsVisible ? '1px solid black' : 'none',
//                     display: progress < 100 ? 'none' : 'block',
//                 }}
//             />
//         </div>
//     );
// };

// export default PDFViewer;
import React, { useEffect, useRef, useState } from 'react';
import { getDocument, GlobalWorkerOptions } from 'pdfjs-dist';
import { set, get } from 'idb-keyval'; // Import IndexedDB helpers
import 'pdfjs-dist/web/pdf_viewer.css';

// Configure the worker file
GlobalWorkerOptions.workerSrc = `../../node_modules/pdfjs-dist/build/pdf.worker.js`;

const PDFViewer = ({ pdfUrl, initialPageNumber = "1", blockIndex = null, finename="PDF Viewer"}) => {
    const canvasRef = useRef(null);
    const [progress, setProgress] = useState(0);
    const [pdfInstance, setPdfInstance] = useState(null);
    const [currentPage, setCurrentPage] = useState(parseInt(initialPageNumber));
    const [zoomLevel, setZoomLevel] = useState(1.5);
    const [controlsVisible, setControlsVisible] = useState(false);

    // Fetch PDF with progress and store in IndexedDB
    const fetchPdfWithProgress = async (url) => {
        const response = await fetch(url);
        const reader = response.body.getReader();
        const contentLength = +response.headers.get('Content-Length');

        let receivedLength = 0;
        let chunks = [];

        while (true) {
            const { done, value } = await reader.read();

            if (done) break;

            chunks.push(value);
            receivedLength += value.length;

            const percent = Math.round((receivedLength / contentLength) * 100);
            setProgress(percent);
        }

        const pdfData = new Uint8Array(receivedLength);
        let position = 0;
        for (let chunk of chunks) {
            pdfData.set(chunk, position);
            position += chunk.length;
        }

        // Store PDF data in IndexedDB
        await set(`${url}_binary`, pdfData);

        return pdfData;
    };

    // Load PDF document
    useEffect(() => {
        const loadPdf = async () => {
            try {
                setControlsVisible(false);
                let pdfData;

                // Check if the PDF is cached in IndexedDB
                const cachedPdf = await get(`${pdfUrl}_binary`);
                if (cachedPdf) {
                    pdfData = cachedPdf;
                    setProgress(100);
                } else {
                    pdfData = await fetchPdfWithProgress(pdfUrl);
                }

                const pdf = await getDocument({ data: pdfData }).promise;
                setPdfInstance(pdf);
            } catch (error) {
                console.error('Error loading PDF:', error);
            }
        };

        loadPdf();
    }, [pdfUrl]);

    // Render PDF page
    const renderPage = async (pageNumber) => {
        if (!pdfInstance) return;

        try {
            const page = await pdfInstance.getPage(pageNumber+1);
            const viewport = page.getViewport({ scale: zoomLevel });

            const canvas = canvasRef.current;
            const context = canvas.getContext('2d');
            canvas.width = viewport.width;
            canvas.height = viewport.height;

            await page.render({ canvasContext: context, viewport }).promise;
            setControlsVisible(true);
        } catch (error) {
            console.error('Error rendering page:', error);
        }
    };

    useEffect(() => {
        if (pdfInstance) {
            renderPage(currentPage);
        }
    }, [pdfInstance, currentPage, zoomLevel]);

    // Handle zoom
    const handleZoomIn = () => setZoomLevel((prevZoom) => Math.min(prevZoom + 0.5, 3));
    const handleZoomOut = () => setZoomLevel((prevZoom) => Math.max(prevZoom - 0.5, 0.5));

    // Handle page navigation
    const handleNextPage = () => {
        if (currentPage < pdfInstance.numPages) {
            setCurrentPage((prevPage) => prevPage + 1);
        }
    };

    const handlePrevPage = () => {
        if (currentPage > 1) {
            setCurrentPage((prevPage) => prevPage - 1);
        }
    };

    return (
        <div>
        <h3>{finename}</h3> 
        <br/>   
        <br/>   
            <div style={{ position: 'relative' }}>
                {/* Show download progress */}
                {progress < 100 && (
                    <div
                        style={{
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            width: '100%',
                            height: '100%',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            backgroundColor: 'rgba(0, 0, 0, 0.5)',
                            color: 'rgba(0, 0, 0, 0.5)',
                            zIndex: 10,
                        }}
                    >
                        <div style={{ textAlign: 'center', width: '80%' }}>
                            <p style={{ fontSize: '18px', marginBottom: '10px' }}>Loading PDF... {progress}%</p>
                            <progress
                                value={progress}
                                max="100"
                                style={{
                                    width: '100%',
                                    height: '50px',
                                    appearance: 'none',
                                    backgroundColor: '#ddd',
                                    borderRadius: '5px',
                                    overflow: 'hidden',
                                }}
                            />
                        </div>
                    </div>
                )}

                {controlsVisible && (
                    <div>
                        <button onClick={handlePrevPage} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
                            Previous Page
                        </button>
                        <button onClick={handleNextPage} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
                            Next Page
                        </button>
                        <button onClick={handleZoomIn} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
                            Zoom In
                        </button>
                        <button onClick={handleZoomOut} style={{ margin: '0 10px', background: 'none', border: 'none', color: 'blue', textDecoration: 'underline', cursor: 'pointer' }}>
                            Zoom Out
                        </button>
                    </div>
                )}

                <canvas
                    ref={canvasRef}
                    style={{
                        border: controlsVisible ? '1px solid black' : 'none',
                        display: progress < 100 ? 'none' : 'block',
                    }}
                />
            </div>
        </div>
    );
};

export default PDFViewer;

