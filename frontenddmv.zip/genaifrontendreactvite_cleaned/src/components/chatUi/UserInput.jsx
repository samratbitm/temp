import React, { Suspense } from "react";

const UserInput = ({ chat, replaceWithBr }) => (
  <div className="user-input">
    <Suspense fallback={<div>Loading...</div>}>
      <img
        className="user-input-child"
        loading="lazy"
        alt="User Account"
        src="/Account circle.svg"
      />
    </Suspense>
    <div className="hb-3">{replaceWithBr(chat.content)}</div>
  </div>
);

export default UserInput;
