import { useState, useEffect, useRef, createRef } from "react";
import "../../styles/Home.scss";
import { Grid, IconButton, TextField, Typography } from "@mui/material";
import ScrollableCards from "./ScrollableCards";
import HistoryDmv from "../history/HistoryDmv";
import SendIcon from "@mui/icons-material/Send";
import parse from "html-react-parser";
import { fetchEventSource } from "@microsoft/fetch-event-source";
import { v4 as uuidv4 } from "uuid";
import ReusableModal from "../common/ReusableModal";
import CircularLoader from "./CircularLoader";
import SuggestiveQuestionContent from "./SuggestiveQuestionContent";
import ChatResponse from "./ChatResponse";
import { convertToUserTimezone } from "../../utils/datetimeUtils";
import { json } from "react-router-dom";
import { backendAppUrl, backendDmvUrl } from "../../utils/billServices";
import PDFViewer from "../PDFViewer" 

function ChatInterfaceDmv({ query, showHistoryOnly, onClosebtn }) {
  const [dmvCards, setDmvCards] = useState([]);
  const [dmvMessage, setDmvMessage] = useState("");
  const [dmvChats, setDmvChats] = useState([]);
  const [dmvIsTyping, setDmvIsTyping] = useState(false);
  const [dmvIsLLMLoadingInProgress, setDmvLLMLoadingInProgress] =
    useState(false);
  const [dmvAssistantContent, setDmvAssistantContent] = useState({});
  const [dmvRatings, setDmvRatings] = useState({});
  const [dmvCountMessage, setDmvCountMessage] = useState("0/200");
  const dmvElRefs = useRef([]);
  const dmvInputRef = useRef(null);
  const dmvScrollableDivRef = useRef(null);
  const dmvLinksContainerRef = useRef(null);
  const [dmvIsScrollable, setDmvIsScrollable] = useState(false);
  const [dmvShowModal, setDmvShowModal] = useState(false);
  const [dmvPDFShowModal, setDmvPDFShowModal] = useState(false);
  const [dmvItems, setDmvItems] = useState(Array());
  const dmvHeaders = ["Score","Page","Para","Content"]; // Dynamic headers
  const [dmvIsUAT, setDmvIsUAT] = useState(true);
  const [dmvGPTVersion, setDmvGPTVersion] = useState("4");
  const [dmvData, setDmvData] = useState([]);
  const dmvResponseRef = useRef(null);
  const [dmvIsCentered, setDmvIsCentered] = useState(false);
  const [dmvSelectedValue, setDmvSelectedValue] = useState([]);
  const [dmvIsDataLoaded, setDmvIsDataLoaded] = useState(false);
  const [dmvIsValidUser, setDmvIsValidUser] = useState(false);
  const dmvValidUserValue = { dmvIsValidUser, setDmvIsValidUser };
  const [dmvSessionUUID, setDmvSessionUUID] = useState(uuidv4());
  const [dmvUser, setDmvUser] = useState(sessionStorage.getItem("username"));
  const [accessToken, setAccessToken] = useState(
    sessionStorage.getItem("accessToken")
  );
  const [dmvHistoryData, setDmvHistoryData] = useState([]);
  const [dmvIsLoading, setDmvIsLoading] = useState(true);
  const [dmvIsLoadingChat, setDmvIsLoadingChat] = useState(false);
  const [dmvCopied, setDmvCopied] = useState(false);
  const [dmvIsExpanded, setDmvIsExpanded] = useState({});
  const [dmvIsUpAccordionVisible, setDmvIsUpAccordionVisible] = useState(false);
  const [dmvFeedback, setDmvFeedback] = useState({});
  const [dmvIsSubmitted, setDmvIsSubmitted] = useState({});
  const [dmvSuggestiveQuestions, setDmvSuggestiveQuestions] = useState([]);
  const [dmvcardsWithImages, setDmvCardsWithImages] = useState([]);
  const [isdmvCardScrollable, setIsDmvCardScrollable] = useState(false);

  const [todaysDmv, settodaysDmv] = useState([]);
  const [previous7DaysDmv, setprevious7DaysDmv] = useState([]);
  const [lastMonthDmv, setlastMonthDmv] = useState([]);
  const [olderItemsDmv, setolderItemsDmv] = useState([]);
  const [selectedItemIndexDmv, setSelectedItemIndexDmv] = useState(null);
  const [imageList, setImageList] = useState(Array());
  const [isconnectionclose, setIsConnectionClose] = useState(false);

  const [formconfigs, setFormConfigs] = useState({});
  const [apptype, setAppType] = useState("dmv");
  const [currentformindex, setCurrentFormIndex] = useState(0);
  const [formsubmittedfromparent, setSubmittedFromParent] = useState(0);

  const [pdf, setPDF] = useState({});
  const [isDownload, setIsDownload] = useState(false);

  const [pdfUrl, setPdfUrl] = useState('');
  const [pageNumber, setPageNumber] = useState(1);
  const [blockIndex, setBlockIndex] = useState(null);
  const [pdffilename, setPdffilename] = useState("PDF Viewer");
  
  const defaultconfig = {
    sections: [
      {
        title: "Applicant Information",
        fields: [
          {
            name: "name",
            label: "Full Legal Name",
            type: "text",
            value: "Samrat Chowdhury",
            validation: {
              required: true,
              minLength: 2,
            },
          },
          {
            name: "birthdate",
            label: "Birthdate (yyyy-mm-dd)",
            type: "date",
            value: "",
            validation: {
              required: true,
            },
          },
          {
            name: "phone_number",
            label: "Phone Number (optional)",
            type: "text",
            value: "",
          },
          {
            name: "sex",
            label: "Sex (check one)",
            type: "radio",
            options: ["Male", "Female", "Non-binary"],
            value: "",
          },
          {
            name: "weight",
            label: "Weight",
            type: "number",
            value: "",
          },
          {
            name: "height",
            label: "Height",
            type: "number",
            value: "",
          },
          {
            name: "eye_color",
            label: "Eye Color",
            type: "text",
            value: "",
          },
          {
            name: "hair_color",
            label: "Hair Color",
            type: "text",
            value: "",
          },
        ],
      },
      {
        title: "Address Information",
        fields: [
          {
            name: "street_address",
            label: "Street Address",
            type: "text",
            value: "",
            validation: {
              required: true,
            },
          },
          {
            name: "city",
            label: "City",
            type: "text",
            value: "",
            validation: {
              required: true,
            },
          },
          {
            name: "state",
            label: "State",
            type: "text",
            value: "",
            validation: {
              required: true,
            },
          },
          {
            name: "zip_code",
            label: "ZIP Code",
            type: "text",
            value: "",
            validation: {
              required: true,
            },
          },
          {
            name: "mailing_address",
            label: "Mailing Address (if different from above)",
            type: "text",
            value: "",
          },
        ],
      },
    ],
  };

  const setDmvCardsTitles = async () => {
    const hardcodedcards = [
      {
        title:
          "Help me understand the rules of pickleball and any other helpful tips",
      },
      { title: "Card 2" },
      {
        title:
          "Help me understand the rules of pickleball and any other helpful tips",
      },
      { title: "Card 4" },
      { title: "Card 5" },
    ];

    try {
      let request = {
        card_id: "1",
        user_id: dmvUser,
        app_type: "dmv",
      };
      fetch(`${backendAppUrl}/app/cards`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(request),
      })
        .then((response) => response.json())
        .then((data) => {
          // if (data.length > 0) {
          setDmvCards(data.output);
          // }
        })
        .catch((error) => {
          console.log(error);
        });
    } catch (error) {
      console.error("Error getting suggestive questions:", error);
      setDmvCards(hardcodedcards);
    }
  };

  const handleLeftScroll = () => {
    const linksContainer = dmvLinksContainerRef.current;
    linksContainer.scrollTo({
      left: 0,
      behavior: "smooth",
    });
  };

  const handleRightScroll = () => {
    const linksContainer = dmvLinksContainerRef.current;
    const maxScrollLeft =
      linksContainer.scrollWidth - linksContainer.clientWidth;
    linksContainer.scrollTo({
      left: maxScrollLeft, // Scroll to the extreme right
      behavior: "smooth",
    });
  };

  useEffect(() => {
    const responseElement = dmvResponseRef.current;
    const scrollElement = responseElement.querySelector(".parent-container1");

    setDmvCardsTitles();
    getHistoryList();

    if (scrollElement) {
      setDmvIsCentered(true);
    } else {
      setDmvIsCentered(false);
    }
  }, []);

  useEffect(() => {
    const checkScrollable = () => {
      const container = dmvLinksContainerRef.current;
      if (container) {
        setDmvIsScrollable(container.scrollWidth > container.clientWidth);
      }
    };

    checkScrollable();
    window.addEventListener("resize", checkScrollable);
    return () => window.removeEventListener("resize", checkScrollable);
  }, [dmvSuggestiveQuestions]);

  const replaceWithBrDmv = (text) => {
    try {
      text = parse(text);
    } catch {}
    return text && text.length ? text : "Loading...";
  };

  const toggleAccordionDmv = (questionID) => {
    setDmvIsExpanded((prev) => ({ ...prev, [questionID]: !prev[questionID] }));
  };

  const handleFeedbackChangeDmv = (e, questionID) => {
    dmvFeedback[questionID] = e.target.value;
    setDmvFeedback({ ...dmvFeedback });
  };

  const handleFormConfigChange = (e, index, value, isFormSubmitted) => {
    //if(index % 2 !== 0){
    //  index = index +1
    //}
    setCurrentFormIndex(index);
    const dmvFormConfigs = { ...formconfigs };
    dmvFormConfigs[index].formconfig = value;
    dmvFormConfigs[index].isvalid = true;
    setFormConfigs(dmvFormConfigs);

    if (isFormSubmitted) {
      setDmvMessage("Submit");
      chat(e, "Submit");
    }
  };

  const handlefeedbackDmv = (index) => {
    const updateRatings = { ...dmvRatings };
    // const updatedisSubmitted = !dmvIsSubmitted.includes(index)
    //   ? [...dmvIsSubmitted, index]
    //   : dmvIsSubmitted;

    let ratingContext = {
      question_id: updateRatings[index + 1].question_id,
      user_sentiment: "Negative",
      user_comment: dmvFeedback[updateRatings[index + 1].question_id],
    };
    updateDmvRating(ratingContext);
    setDmvRatings(updateRatings);
    setDmvIsSubmitted((prev) => ({
      ...prev,
      [updateRatings[index + 1].question_id]: true,
    }));
    // setDmvFeedback("")

    setDmvIsExpanded((prev) => ({
      ...prev,
      [updateRatings[index + 1].question_id]: false,
    }));
  };

  //new changes
  const handleThumbsUpDmv = (index) => {
    setDmvIsUpAccordionVisible(true);
    const updateRatings = { ...dmvRatings };
    if (updateRatings[index + 1]) {
      updateRatings[index + 1].thumbsUp =
        updateRatings[index + 1].thumbsUp == 0 ? 1 : 0;
      updateRatings[index + 1].thumbsDown = 0;
    }
    let ratingContext = {
      question_id: updateRatings[index + 1].question_id,
      user_sentiment: "Positive",
      user_comment: "",
    };
    updateDmvRating(ratingContext);
    setDmvRatings(updateRatings);
  };

  //new changes
  const handleThumbsDownDmv = (index) => {
    //  setIsDownAccordionVisible(true);
    const updateRatings = { ...dmvRatings };
    if (updateRatings[index + 1]) {
      updateRatings[index + 1].thumbsDown =
        updateRatings[index + 1].thumbsDown == 0 ? 1 : 0;
      updateRatings[index + 1].thumbsUp = 0;
    }
    let ratingContext = {
      question_id: updateRatings[index + 1].question_id,
      user_sentiment: "Negative",
      user_comment: "",
      app_type: "dmv",
    };
    updateDmvRating(ratingContext);
    setDmvRatings(updateRatings);
  };

  const updateDmvRating = async (ratingContext) => {
    if (!ratingContext) return;

    // if (dmvIsUAT) {
    //   backendUrl = "http://127.0.0.1:8000/feedback/rating";
    // }

    await fetch(`${backendAppUrl}/feedback/rating`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(ratingContext),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Connection made message", data.output);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const selectsuggestiveDmvquestion = async (e, message) => {
    setDmvMessage(message);
    chat(e, message);
  };

  const chat = async (e, message) => {
    setDmvIsCentered(false);
    e.preventDefault();
    if (!message) return;

    if (dmvScrollableDivRef.current) {
      dmvScrollableDivRef.current.scrollTop =
        dmvScrollableDivRef.current.scrollHeight;
    }
    let msgs = dmvChats;
    msgs.push({ role: "user", content: message });
    setDmvChats(msgs);
    msgs.push({ role: "Assistant", content: "" });
    setDmvChats(msgs);

    setDmvRatings({
      ...dmvRatings,
      [msgs.length]: { thumbsUp: 0, thumbsDown: 0, item: Array() },
    });

    setDmvAssistantContent({
      ...dmvAssistantContent,
      [msgs.length]: { content: "" },
    });

    setFormConfigs({
      ...formconfigs,
      [msgs.length]: { isvalid: false, formconfig: undefined },
    });

    setDmvIsTyping(true);
  };

  const assignObjectPaths = (obj, stack) => {
    Object.keys(obj).forEach((k) => {
      const node = obj[k];
      if (typeof node === "object") {
        node.path = stack ? `${stack}.${k}` : k;
        assignObjectPaths(node, node.path);
      }
    });
  };

  //new changes
  const setHistory = async () => {
    setDmvIsLoading(true);
    let historyContext = {
      chat_id: dmvSessionUUID,
      user_id: dmvUser,
      app_type: "dmv",
    };

    // let backendUrl = "http://127.0.0.1:8000/dmv/history/setsession";
    // if (isUAT) {
    //}

    await fetch(`${backendAppUrl}/history/setsession`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(historyContext),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Connection made message setHsiroty", data.output);
        setDmvMessage("");
        setDmvCountMessage("0/200");
        getHistoryList();
      })
      .catch((error) => {
        console.log(error);
      });
  };

  const getHistoryList = async () => {
    let historyContext = {
      chat_id: dmvSessionUUID,
      user_id: dmvUser,
      app_type: "dmv",
    };

    console.log(dmvSessionUUID);
    console.log(dmvUser);

    // let backendUrl = "http://127.0.0.1:8000/dmv/history/all";
    // if (isUAT) {
    // let backendUrl = "http://127.0.0.1:8000/history/all";
    // }

    await fetch(`${backendAppUrl}/history/all`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(historyContext),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Connection made message history", JSON.parse(data.output));
        let parseddata = JSON.parse(data.output);
        let newArray = [];
        if (parseddata) {
          parseddata.map((historydata) => {
            let obj = {
              id: historydata["_id"],
              topic: historydata.topic,
              chatid: historydata.chatid,
              insertedDate: convertToUserTimezone(historydata.insertedDate),
            };
            newArray.push(obj);
          });
        }
        setDmvHistoryData(newArray);
        setDmvIsLoading(false);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };

  const getHistory = async (chat_id) => {
    setDmvIsLoadingChat(true);
    setDmvIsCentered(false);
    let historyContext = {
      chat_id: chat_id,
      user_id: dmvUser,
      app_type: "dmv",
    };

    // let backendUrl = "http://127.0.0.1:8000/dmv/history/getsession";
    // if (isUAT) {
    // }

    await fetch(`${backendAppUrl}/history/getsession`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${accessToken}`,
      },
      body: JSON.stringify(historyContext),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log(
          "Connection made message history details",
          JSON.parse(data.output)
        );
        let parseddata = JSON.parse(data.output);
        console.log("parseddata:", parseddata);

        let isFirsttime = true;
        let chatid = "";
        let msgs = [];
        let assistantContentfromRes = {};
        let ratingfromRes = {};
        let feedbackfromRes = {};
        let expandedQuestions = {};
        let submittedQuestions = {};
        let info_json = [];

        parseddata.map((chat, index) => {
          // if (isFirsttime) {
          //   newDmvSession(chat.chatid);
          //   isFirsttime = false;
          // }
          chatid = chat.chatid;
          if (chat.info_json_string) {
            info_json = JSON.parse(chat.info_json_string);
          }

          // msgs = chats;
          msgs.push({ role: "user", content: chat.userquery });
          msgs.push({ role: "Assistant", content: "" });
          // setDmvChats(msgs);
          // msgs.push({ role: "Assistant", content: chat.gptresponse });

          ratingfromRes = {
            ...ratingfromRes,
            [msgs.length]: {
              thumbsUp: chat.user_feedback_sentiment == "Positive" ? 1 : 0,
              thumbsDown: chat.user_feedback_sentiment == "Negative" ? 1 : 0,
              item: null,
              user_comment:
                chat.user_feedback_sentiment == "Negative"
                  ? chat.user_feedback_comment
                  : "",
              question_id: chat._id,
            },
          };
          if (chat.user_feedback_sentiment == "Negative") {
            feedbackfromRes = {
              ...feedbackfromRes,
              [chat._id]: chat.user_feedback_comment,
            };
            expandedQuestions = {
              [chat._id]: false,
            };

            submittedQuestions = {
              [chat._id]: chat.user_feedback_comment ? true : false,
            };

            // indexedDB
          }

          console.log("rating", ratingfromRes);
          assistantContentfromRes = {
            ...assistantContentfromRes,
            [msgs.length]: {
              content: SetDmvImagesInResponse(chat.gptresponse, info_json),
            },
          };
        });

        const sessionData = {
          chatid: chatid,
          assistantContentfromRes: assistantContentfromRes,
          ratingfromRes: ratingfromRes,
          feedbackfromRes: feedbackfromRes,
          expandedQuestions: expandedQuestions,
          submittedQuestions: submittedQuestions,
          msgs: msgs,
          info_json: info_json,
        };
        newDmvSession(sessionData);
        setDmvIsLoadingChat(false);
      })
      .catch((error) => {
        console.log(error);
      });
  };

  // Store a reference to the global listener function
  let dynamicLinkListener = null;

  // Function to add the global listener
  const addGlobalListener = () => {
    if (!dynamicLinkListener) {
      // Define the listener function
      dynamicLinkListener = (e) => {
        if (e.target && e.target.classList.contains("dynamic-link")) {
          e.preventDefault();
          console.log("Dynamic link clicked");

          // Extract data attributes
          const url = e.target.dataset.url;
          const page = e.target.dataset.page;
          const para = e.target.dataset.para;
          const pdffname = e.target.dataset.pdffname;

          // Call the modal function
          openPDFModal(url, page, para, pdffname);
        }
      };

      // Add the global event listener
      document.body.addEventListener("click", dynamicLinkListener);
      console.log("Global listener added.");
    }
  };

  // Function to remove the global listener
  const removeGlobalListener = () => {
    if (dynamicLinkListener) {
      document.body.removeEventListener("click", dynamicLinkListener);
      dynamicLinkListener = null;
      console.log("Global listener removed.");
    }
  };

  const SetDmvImagesInResponse = (gptresponse, iList) => {
    debugger;
    const parser = new DOMParser();
    const doc = parser.parseFromString(gptresponse, "text/html");
    const elements = doc.querySelectorAll(".recordId");
    if (elements) {
      elements.forEach((element, index) => {
          if (!element.dataset.eventAdded) {
              const recordIdText = element.textContent;
              let match = recordIdText.match(/\[([0-9]+)\]/);
              const match1 = recordIdText.match(/(\d+)/);
              match = match1 ? match1 : match;

              if (match) {
                  if (iList && iList.length > 0) {
                      const record = iList[match[1] - 1];

                      // Create an anchor link
                      const link = document.createElement("a");
                      link.href = "javascript:void(0);"; // Prevent default navigation
                      link.textContent = "View Document Section";
                      link.className = "dynamic-link"; // Add a class for delegation
                      link.style = "display:block;margin-bottom:5px;";

                      // Add data attributes
                      link.dataset.url = `https://prod01storggenaisource.blob.core.windows.net/ingesteddotdocs/dmv39.pdf`;
                      link.dataset.page = record["page"];
                      link.dataset.para = record["para"];
                      link.dataset.pdffname = "dmv39.pdf";//record["document_name"]; 

                      // Create a div wrapper for record["image_htlm"]
                      const contentWrapper = document.createElement("div");
                      contentWrapper.style = `
                          display: block;
                          max-height: 100%;
                          max-width: 100%;
                          width: inherit;
                          height: inherit;
                          overflow: hidden; /* Ensures content does not overflow the div */
                      `;

                      // Parse and insert the record["image_htlm"] content
                      const tempDiv = document.createElement("div");
                      tempDiv.innerHTML = record["image_htlm"];

                      // Process <img> tags
                      const images = tempDiv.querySelectorAll("img");
                      if (images.length > 0) {
                          images.forEach((img) => {
                              img.style = `
                                  display: block;
                                  max-height: 100%;
                                  max-width: 100%;
                                  width: auto;
                                  height: auto;
                                  margin-bottom: 5px; /* Add spacing if needed */
                              `;
                              contentWrapper.appendChild(img);
                          });
                      } else {
                          // If no <img> tags, handle <br /> tags
                          const brContent = document.createElement("div");
                          brContent.innerHTML = record["image_htlm"];
                          brContent.style = `
                              display: block;
                              max-height: inherit;
                              width: 100%;
                              overflow: hidden;
                          `;
                          contentWrapper.appendChild(brContent);
                      }

                      // Clear the existing element content
                      element.innerHTML = "";

                      // Append the anchor and the content wrapper
                      element.appendChild(link); // Anchor link on top
                      element.appendChild(contentWrapper); // Content below the link
                      element.style = "display:block";
                      element.className = "none";

                      removeGlobalListener();
                      addGlobalListener();

                  } else {
                      element.innerHTML = "";
                      element.style = "display:none";
                      element.className = "none";
                  }
              } else {
                  element.innerHTML = "";
                  element.style = "display:none";
                  element.className = "none";
              }
              element.dataset.eventAdded = "true"; // Mark as processed
          }
      });
    } 
    return doc.body.innerHTML;
  };

  //new changes
  const newDmvSession = async (sessionData) => {
    if (sessionData) {
      console.log("item is", sessionData.ratingfromRes.item);
      console.log("set session id: ", sessionData.chatid);
      SuggestiveDmvQuestion(sessionData.chatid);
      setDmvSessionUUID(sessionData.chatid);
      setDmvAssistantContent(sessionData.assistantContentfromRes);
      setDmvRatings(sessionData.ratingfromRes);
      setDmvChats(sessionData.msgs);
      setDmvFeedback(sessionData.feedbackfromRes);
      setDmvIsExpanded(sessionData.expandedQuestions);
      setDmvIsSubmitted(sessionData.submittedQuestions);
      //setImageList(sessionData.info_json);
      //SetDmvImages(imageList);
    } else {
      const id = uuidv4();
      setDmvSessionUUID(id);
      SuggestiveDmvQuestion(id);
      setDmvRatings({});
      setDmvAssistantContent({});
      setDmvChats([]);
    }
    setDmvMessage("");
    setDmvCountMessage("0/200");
  };

  // const SetDmvImages = async (iList) => {
  //   const elements = document.querySelectorAll(".recordId");
  //   if (elements) {
  //     debugger;
  //     elements.forEach((element, index) => {
  //       if (!element.dataset.eventAdded) {
  //         const recordIdText = element.textContent;
  //         let match = recordIdText.match(/\[([0-9]+)\]/);
  //         const match1 = recordIdText.match(/(\d+)/);
  //         match = match1 ? match1 : match;
  //         if (match) {
  //           if (iList && iList.length > 0) {
  //             const record = iList[match[1] - 1];
  //             element.innerHTML = record["image_htlm"];
  //             element.style = "display:block;max-width: 100%;max-height: 100%;width: auto;height: auto;";;
  //             element.className = "none";
  //           } else {
  //             element.innerHTML = "";
  //             element.style = "display:none";
  //             element.className = "none";
  //           }
  //         } else {
  //           element.innerHTML = "";
  //           element.style = "display:none";
  //           element.className = "none";
  //         }
  //         element.dataset.eventAdded = "true";
  //       }
  //     });
  //   }
  // };

  const SetDmvImages = async (iList) => {
    const elements = document.querySelectorAll(".recordId");
    if (elements) {
        elements.forEach((element, index) => {
            if (!element.dataset.eventAdded) {
                const recordIdText = element.textContent;
                let match = recordIdText.match(/\[([0-9]+)\]/);
                const match1 = recordIdText.match(/(\d+)/);
                match = match1 ? match1 : match;

                if (match) {
                    if (iList && iList.length > 0) {
                        const record = iList[match[1] - 1];

                        // Create an anchor link
                        const link = document.createElement("a");
                        link.href = "javascript:void(0);"; // Prevent default navigation
                        link.textContent = "View Document Section";
                        link.className = "dynamic-link"; // Add a class for delegation
                        link.style = "display:block;margin-bottom:5px;";

                        // Add data attributes
                        link.dataset.url = `https://prod01storggenaisource.blob.core.windows.net/ingesteddotdocs/dmv39.pdf`;
                        link.dataset.page = record["page"];
                        link.dataset.para = record["para"];
                        link.dataset.pdffname = "dmv39.pdf"; // record["document_name"]; 

                        // Create a div wrapper for record["image_htlm"]
                        const contentWrapper = document.createElement("div");
                        contentWrapper.style = `
                            display: block;
                            max-height: 100%;
                            max-width: 100%;
                            width: inherit;
                            height: inherit;
                            overflow: hidden; /* Ensures content does not overflow the div */
                        `;

                        // Parse and insert the record["image_htlm"] content
                        const tempDiv = document.createElement("div");
                        tempDiv.innerHTML = record["image_htlm"];

                        // Process <img> tags
                        const images = tempDiv.querySelectorAll("img");
                        if (images.length > 0) {
                            images.forEach((img) => {
                                img.style = `
                                    display: block;
                                    max-height: 100%;
                                    max-width: 100%;
                                    width: auto;
                                    height: auto;
                                    margin-bottom: 5px; /* Add spacing if needed */
                                `;
                                contentWrapper.appendChild(img);
                            });
                        } else {
                            // If no <img> tags, handle <br /> tags
                            const brContent = document.createElement("div");
                            brContent.innerHTML = record["image_htlm"];
                            brContent.style = `
                                display: block;
                                max-height: inherit;
                                width: 100%;
                                overflow: hidden;
                            `;
                            contentWrapper.appendChild(brContent);
                        }

                        // Clear the existing element content
                        element.innerHTML = "";

                        // Append the anchor and the content wrapper
                        element.appendChild(link); // Anchor link on top
                        element.appendChild(contentWrapper); // Content below the link
                        element.style = "display:block";
                        element.className = "none";

                        removeGlobalListener();
                        addGlobalListener();

                    } else {
                        element.innerHTML = "";
                        element.style = "display:none";
                        element.className = "none";
                    }
                } else {
                    element.innerHTML = "";
                    element.style = "display:none";
                    element.className = "none";
                }
                element.dataset.eventAdded = "true"; // Mark as processed
            }
        });
    }  
  };

  const SuggestiveDmvQuestion = async (chatId) => {
    try {
      // let backendUrl = "http://127.0.0.1:8000/history/suggestivequestion";
      let request = {
        chat_id: chatId,
        user_id: dmvUser,
        app_type: "dmv",
      };
      fetch(`${backendAppUrl}/history/suggestivequestion`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(request),
      })
        .then((response) => response.json())
        .then((data) => {
          // if (data.length > 0) {
          setDmvSuggestiveQuestions(data.output);
          // }
        })
        .catch((error) => {
          console.log(error);
        });
    } catch (error) {
      console.error("Error getting suggestive questions:", error);
    }
  };

  useEffect(() => {
    console.log(imageList);
    if (isconnectionclose) {
      SetDmvImages(imageList);
    }
  }, [isconnectionclose]);

  useEffect(() => {
    debugger;
    let pdf_file = pdf;
    console.log(pdf_file);
    pdf_file = JSON.stringify(pdf_file);
    if (isDownload) {
      debugger;
      const downloadPDF = (pdf_file) => {
        let filename = 'DriverLicenseForm.pdf'; 
        fetch(`${backendDmvUrl}/dmv/generate-pdf`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${accessToken}`,
          },
          body: pdf_file.replace("\n\n", ""),
        })
          .then((response) => {
            if (!response.ok) {
              setIsDownload(false);
              throw new Error("Network response was not ok");
            }

            // Extract the filename from the Content-Disposition header             
            const disposition = response.headers.get('content-disposition') || response.headers.get('Content-Disposition');
            if (disposition) {
              const match = disposition.match(/filename="?([^"]+)"?/);
              if (match && match[1]) {
                filename = match[1].trim(); // Extract and set the filename
              }
            }
            
            return response.blob(); // Convert to a Blob object
          })
          .then((blob) => {
            // Create a link element, use it to trigger the download
            const url = window.URL.createObjectURL(new Blob([blob]));
            const link = document.createElement("a");
            link.href = url;
            link.setAttribute("download", filename); // Use the extracted filename
            document.body.appendChild(link);
            link.click();
            link.parentNode.removeChild(link);
            setIsDownload(false);
          })
          .catch((error) => {
            console.error("There was an error!", error);
            setIsDownload(false);
          });
      };

      downloadPDF(pdf);
    }
  }, [pdf]);

  useEffect(() => {
    const fetchData = async () => {
      if (dmvMessage) {
        let request = {
          model_name: dmvGPTVersion,
          user_message: dmvMessage,
          filter_options: "",
          chat_history: null,
          chat_id: dmvSessionUUID,
          user_id: dmvUser,
          app_type: "dmv",
        };

        let dmv_request = {
          chatcompletiontitem: request,
          sections: null,
        };

        if (currentformindex > 0 && formconfigs[currentformindex].isvalid) {
          dmv_request.sections =
            formconfigs[currentformindex].formconfig["sections"];

          for (const key in formconfigs) {
            formconfigs[key].isvalid = false;
          }
        }

        console.log(dmvSessionUUID);
        console.log(dmvUser);

        setDmvMessage("");
        setDmvCountMessage("0/200");
        let msgs = dmvChats;

        // let backendUrl = "http://127.0.0.1:8000/dmv/chatcompletion/stream";

        // if (isUAT) {
        // let backendUrl =
        // local: http://127.0.0.1:8000/
        // Prod: http://127.0.0.1:8000/
        // Dev: http://127.0.0.1:8000/";
        //}

        await fetchEventSource(`${backendDmvUrl}/dmv/chatcompletion/stream`, {
          method: "POST",
          openWhenHidden: true,
          headers: {
            "Content-Type": "application/json",
            Accept: "text/event-stream",
            Authorization: `Bearer ${accessToken}`,
          },
          body: JSON.stringify(dmv_request),
          mode: "cors",
          onopen(res) {
            if (res.ok && res.status === 200) {
              console.log("Connection made ", res);
              setIsConnectionClose(false);
              setImageList(Array());
            } else if (
              res.status >= 400 &&
              res.status < 500 &&
              res.status !== 429
            ) {
              console.log("Client-side error ", res);
              setDmvIsTyping(false);
              setDmvLLMLoadingInProgress(false);
              throw new Error();
            }
          },
          onmessage(event) {
            console.log(event.data);
            if (
              !event.data.includes("Custom_Information_Used_By_LLM") &&
              !event.data.includes(
                "Custom_Information_Used_By_LLM_QuestionID:"
              ) &&
              !event.data.includes("Custom_Information_FormConfigrationAgent:")
            ) {
              if (
                event.data != "" &&
                event.data != undefined &&
                event.data != "None"
              ) {
                let parsedData = decodeURIComponent(
                  escape(window.atob(event.data))
                );
                //setDmvData((data) => [...data, parsedData]); // Important to set the data this way, otherwise old data may be overwritten if the stream is too fast
                const index = msgs.length;
                let pdf_file = undefined;
                if (
                  parsedData.includes(
                    "Submitted, Downloading Drive Licenses Form..."
                  )
                ) {
                  debugger;
                  pdf_file = parsedData.replace(
                    "Submitted, Downloading Drive Licenses Form...",
                    ""
                  );
                  parsedData = "Submitted, Downloading Drive Licenses Form...";
                }

                const updateassistantContent = { ...dmvAssistantContent };
                updateassistantContent[index].content += parsedData; //== "."? ".\n":parsedData +" ");
                setDmvAssistantContent(updateassistantContent);
                // setShowSuggestiveQuestion(true);

                // SuggestiveDmvQuestion();
                if (dmvScrollableDivRef.current) {
                  dmvScrollableDivRef.current.scrollTop =
                    dmvScrollableDivRef.current.scrollHeight;
                }

                if (pdf_file) {
                  setCurrentFormIndex(0);
                  setIsDownload(true);
                  setPDF(pdf_file);
                }
              }
            } else {
              if (event.data.includes("Custom_Information_Used_By_LLM:")) {
                const index = msgs.length;
                const json_string = event.data.replace(
                  "Custom_Information_Used_By_LLM:",
                  ""
                );
                const list_of_arrays = JSON.parse(
                  decodeURIComponent(escape(window.atob(json_string)))
                );
                const updateRatings = { ...dmvRatings };
                updateRatings[index].item = list_of_arrays;
                setDmvRatings(updateRatings);
                setImageList(list_of_arrays);
              } else if (
                event.data.includes(
                  "Custom_Information_Used_By_LLM_QuestionID:"
                )
              ) {
                const index = msgs.length;
                const question_id = event.data.replace(
                  "Custom_Information_Used_By_LLM_QuestionID:",
                  ""
                );
                const updateRatings = { ...dmvRatings };
                updateRatings[index].question_id = question_id;
                setDmvRatings(updateRatings);
                setDmvIsExpanded((prev) => ({ ...prev, [question_id]: false }));
              } else if (
                event.data.includes("Custom_Information_FormConfigrationAgent:")
              ) {
                debugger;
                const index = msgs.length;
                let dynamicconfig = event.data.replace(
                  "Custom_Information_FormConfigrationAgent:",
                  ""
                );

                dynamicconfig = JSON.parse(
                  decodeURIComponent(escape(window.atob(dynamicconfig)))
                );

                const dmvFormConfigs = { ...formconfigs };

                dmvFormConfigs[index].isvalid = true;
                dmvFormConfigs[index].formconfig = dynamicconfig;
                setFormConfigs(dmvFormConfigs);
                setCurrentFormIndex(index);
              }
              //const content =  msgs[index].content;
              //msgs[index].content = content + (parsedData == "."? ".\n":parsedData +" ");
            }
          },
          onclose() {
            console.log("Connection closed by the server");
            setHistory();
            setDmvIsTyping(false);
            setDmvLLMLoadingInProgress(false);
            SuggestiveDmvQuestion(dmvSessionUUID);
            setIsConnectionClose(true);
          },
          onerror(err) {
            console.log("There was an error from server", err);
            setDmvIsTyping(false);
            setDmvLLMLoadingInProgress(false);
            setIsConnectionClose(true);
            if (currentformindex > 0) {
              formconfigs[currentformindex].isvalid = true;
            }
            throw new Error();
          },
        });
      } else {
        console.log("invalid user question");
        setDmvIsTyping(false);
        setDmvLLMLoadingInProgress(false);
        throw new Error();
      }
    };

    if (dmvIsTyping && !dmvIsLLMLoadingInProgress) {
      setDmvLLMLoadingInProgress(true);
      fetchData();
    }

    if (dmvElRefs.current.length !== dmvChats.length) {
      // add or remove refs
      dmvElRefs.current = Array(dmvChats.length)
        .fill()
        .map((_, i) => dmvElRefs.current[i] || createRef());

      if (dmvScrollableDivRef.current) {
        dmvScrollableDivRef.current.scrollTop =
          dmvScrollableDivRef.current.scrollHeight;
      }
    }

    if (!dmvIsDataLoaded) {
      SuggestiveDmvQuestion(dmvSessionUUID);
      const defaultData = [
        {
          label: "2024",
          value: "2024",
          tagClassName: "special",
        },
        {
          label: "2023",
          value: "2023",
          tagClassName: "special",
        },
        {
          label: "2022",
          value: "2022",
          tagClassName: "special",
        },
      ];

      setDmvData(defaultData);
      setDmvSelectedValue(defaultData);
      assignObjectPaths(defaultData);

      const params = new URLSearchParams(window.location.search);
      const uat = params.get("uat");
      if (uat != null && uat != undefined && uat != "") {
        if (uat.toLowerCase() == "true")
          setDmvIsUAT(Boolean(uat.toLowerCase()));
      }
      const gpt = params.get("gpt");
      if (gpt != null && gpt != undefined && gpt != "") {
        if (
          gpt.toLowerCase() == "3.5" ||
          gpt.toLowerCase() == "4" ||
          gpt.toLowerCase() == "4-azure"
        ) {
          setDmvGPTVersion(gpt.toLowerCase());
        }
      }
      setDmvIsDataLoaded(true);
    }

    const elements = document.querySelectorAll(".element_conitnue");
    if (elements) {
      elements.forEach((element, index) => {
        if (!element.dataset.eventAdded) {
          const message = "Continue";
          element.addEventListener("click", createEventHandler(message));
          element.dataset.eventAdded = "true";
        } else {
          element.style = "pointer-events:none";
          element.removeEventListener("click", createEventHandler);
        }
      });
    }
  }, [dmvIsTyping, dmvChats, dmvIsDataLoaded, dmvIsValidUser]);

  const createEventHandler = (message) => {
    return (event) => selectsuggestiveDmvquestion(event, message);
  };

  const handleInputChange = (event) => {
    setDmvMessage(event.target.value);
    // const currentLength = e.target.value.length;
    // setDmvCountMessage(currentLength + "/200");
  };

  const handleCopyDmv = (text) => {
    let parsedText = text.replace(/<[^>]+>/g, "");
    const suggestiveQuestionsIndex = parsedText.indexOf(
      "Suggestive Questions:"
    );
    if (suggestiveQuestionsIndex !== -1) {
      parsedText = parsedText.substring(0, suggestiveQuestionsIndex).trim();
    }

    const recordIdPattern = /Record Id:\[\d+\]/i;
    parsedText = parsedText
      .split("\n")
      .filter((line) => !recordIdPattern.test(line.trim()))
      .join("\n");

    navigator.clipboard
      .writeText(parsedText)
      .then(() => {
        setDmvCopied(true);
        setTimeout(() => {
          setDmvCopied(false);
        }, 2000); // Change back to copy icon after 2 seconds
      })
      .catch((error) => {
        console.error("Failed to copy:", error);
        alert("Failed to copy to clipboard.");
      });
  };

  const openModalDmv = (index) => {
    const ratingsitem = { ...dmvRatings };
    setDmvItems(ratingsitem[index + 1].item);
    setDmvShowModal(true);
  };

  const closeModal = () => {
    setDmvShowModal(false);
  };

  const openPDFModal = (url, page, block, pdffname) => {
    setPdfUrl(url);
    setPageNumber(page);
    setBlockIndex(block);
    setPdffilename(pdffname)
    setDmvPDFShowModal(true);
  };

  const closePDFModal = () => {
    setDmvPDFShowModal(false);
  };

  const handleKeyPress = (event) => {
    if (event.key === "Enter" && dmvMessage) {
      event.preventDefault(); // Prevent creating a new line
      if (dmvScrollableDivRef.current) {
        dmvScrollableDivRef.current.scrollTop =
          dmvScrollableDivRef.current.scrollHeight;
      }
      chat(event, dmvMessage);
    }
  };

  const newChatHandler = () => {
    newDmvSession("");
    setDmvIsCentered(true);
    setHistory();
    setDmvIsTyping(false);
    setDmvRatings({});
    setDmvAssistantContent({});
    setDmvChats([]);
    setDmvLLMLoadingInProgress(false);
    setDmvIsExpanded({});
    setDmvFeedback({});
    dmvInputRef.current.focus();
  };

  return (
    <>
      {!showHistoryOnly && (
        <div className="chat">
          <div
            className={`new-chat-button ${dmvIsCentered ? "centered" : ""}`}
            ref={dmvScrollableDivRef}
          >
            {dmvIsLoadingChat ? (
              <CircularLoader />
            ) : (
              <div className="responses" ref={dmvResponseRef}>
                {dmvChats && dmvChats.length ? (
                  <ChatResponse
                    formsubmittedfromparent={formsubmittedfromparent}
                    formconfigs={formconfigs}
                    chats={dmvChats}
                    replaceWithBr={replaceWithBrDmv}
                    elRefs={dmvElRefs}
                    assistantContent={dmvAssistantContent}
                    isTyping={dmvIsTyping}
                    ratings={dmvRatings}
                    copied={dmvCopied}
                    handleThumbsUp={handleThumbsUpDmv}
                    handleThumbsDown={handleThumbsDownDmv}
                    handleCopy={handleCopyDmv}
                    openModal={openModalDmv}
                    isUpAccordionVisible={dmvIsUpAccordionVisible}
                    isExpanded={dmvIsExpanded}
                    toggleAccordion={toggleAccordionDmv}
                    feedback={dmvFeedback}
                    handleFeedbackChange={handleFeedbackChangeDmv}
                    handleFormConfigChange={handleFormConfigChange}
                    handlefeedback={handlefeedbackDmv}
                    isSubmitted={dmvIsSubmitted}
                  />
                ) : (
                  <ScrollableCards
                    apptype={apptype}
                    cards={dmvCards}
                    selectsuggestivequestion={selectsuggestiveDmvquestion}
                    cardsWithImages={dmvcardsWithImages}
                    setCardsWithImages={setDmvCardsWithImages}
                    isCardScrollable={isdmvCardScrollable}
                    setIsCardScrollable={setIsDmvCardScrollable}
                  />
                  // <HorizontalScrollContainer dmvCards={dmvCards} />
                )}
              </div>
            )}
            <div>
              <ReusableModal
                open={dmvShowModal}
                handleClose={closeModal}
                // modalTitle="Terms and Policy"
                modalContent={
                  <Grid container>
                    <Grid
                      container
                      item
                      style={{
                        fontWeight: "bold",
                        minWidth: "100px",
                      }}
                    >
                      {dmvHeaders.map((header, index) => (
                        <Grid
                          item
                          key={index}
                          style={{
                            padding: "10px",
                            // border: "0px solid #e5eaff",
                            textAlign: "center",
                            minWidth: "24%",
                            mixWidth: "76%",
                          }}
                        >
                          <Typography variant="body1" paragraph>
                            <strong>{header}</strong>
                          </Typography>
                        </Grid>
                      ))}
                    </Grid>
                    {dmvItems.map((item, index) => (
                      <Grid
                        container
                        item
                        key={index}
                        style={{ padding: "10px", border: "1px solid #e5eaff" }}
                      >
                        <Grid
                          item
                          style={{
                            padding: "10px",
                            borderRight: "1px solid #e5eaff",
                            minWidth: "24%",
                            maxWidth: "24%",
                            wordWrap: "break-word",
                          }}
                        >
                          <Typography variant="body2" paragraph>
                            {item["score"]}
                          </Typography>
                        </Grid>                                               
                        <Grid
                          item
                          style={{
                            padding: "10px",
                            // border: "1px solid #e5eaff",
                            minWidth: "76%",
                            maxWidth: "76%",
                            wordWrap: "break-word",
                          }}
                        >
                          <Typography variant="body2" paragraph>
                            {item["page"]}
                          </Typography>
                        </Grid>
                        <Grid
                          item
                          style={{
                            padding: "10px",
                            // border: "1px solid #e5eaff",
                            minWidth: "76%",
                            maxWidth: "76%",
                            wordWrap: "break-word",
                          }}
                        >
                          <Typography variant="body2" paragraph>
                            {item["para"]}
                          </Typography>
                        </Grid>
                        <Grid
                          item
                          style={{
                            padding: "10px",
                            // border: "1px solid #e5eaff",
                            minWidth: "76%",
                            maxWidth: "76%",
                            wordWrap: "break-word",
                          }}
                        >
                          <Typography variant="body2" paragraph>
                            {item["content"]}
                          </Typography>
                        </Grid> 
                      </Grid>
                    ))}
                  </Grid>
                }
                confirmText="close"
                // cancelText="Cancel"
                onConfirm={() => {
                  closeModal();
                }}
              />
            </div>
            <div>
              <ReusableModal
                open={dmvPDFShowModal}
                handleClose={closePDFModal}
                // modalTitle="Terms and Policy"
                modalContent={
                  <div className="modal-overlay">
                    <div className="modal-content">                                              
                        <PDFViewer
                            pdfUrl={pdfUrl}
                            initialPageNumber={pageNumber}
                            blockIndex={blockIndex}
                            finename={pdffilename}
                        />             
                    </div>                    
                </div>
                }
                confirmText="close"
                // cancelText="Cancel"
                onConfirm={() => {
                  closePDFModal();
                }}
              />
            </div>
          </div>

          <div className="frame-div">
            {dmvChats && dmvChats.length > 0 && dmvSuggestiveQuestions && (
              <SuggestiveQuestionContent
                isScrollable={dmvIsScrollable}
                handleLeftScroll={handleLeftScroll}
                handleRightScroll={handleRightScroll}
                suggestiveQuestions={dmvSuggestiveQuestions}
                selectsuggestivequestion={selectsuggestiveDmvquestion}
                linksContainerRef={dmvLinksContainerRef}
              />
            )}
            <TextField
              value={dmvMessage}
              inputRef={dmvInputRef}
              onChange={handleInputChange}
              onKeyDown={handleKeyPress}
              multiline
              maxRows={4}
              placeholder="Ask me about motor vehicles rules.."
              variant="outlined"
              fullWidth
              autoFocus
              InputProps={{
                endAdornment: (
                  <>
                    {/* <IconButton>
                    <MicIcon />
                  </IconButton> */}

                    <IconButton
                      onClick={(e) => chat(e, dmvMessage)}
                      style={{
                        color: dmvMessage.trim()
                          ? "var(--color-blueviolet)"
                          : "var(--color-disabled)",
                      }} // Change color based on input value
                      disabled={!dmvMessage.trim()} // Disable if input is empty or contains only whitespace
                    >
                      <SendIcon />
                    </IconButton>
                  </>
                ),
              }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  border: "1px solid var(--primary-p7)",
                  borderRadius: "8px",
                  padding: "12px",
                },
                "& .MuiOutlinedInput-input": {
                  color: "var(--color-darkslategray-100)",
                  // opacity: 0.8,
                },
              }}
            />
            {/* <div className="chatgpt-may-produce-container">
            <span>{`ChatGPT may produce inaccurate information about people, places, or facts. `}</span>
            <a
              className="chatgpt-may-12-version"
              href="https://help.openai.com/en/articles/6825453-chatgpt-release-notes"
              target="_blank"
            >
              <span className="chatgpt-may-12">ChatGPT May 12 Version</span>
            </a>
          </div> */}
          </div>
        </div>
      )}
      <HistoryDmv
        todays={todaysDmv}
        settodays={settodaysDmv}
        previous7Days={previous7DaysDmv}
        setprevious7Days={setprevious7DaysDmv}
        lastMonth={lastMonthDmv}
        setlastMonth={setlastMonthDmv}
        olderItems={olderItemsDmv}
        setolderItems={setolderItemsDmv}
        selectedItemIndex={selectedItemIndexDmv}
        setSelectedItemIndex={setSelectedItemIndexDmv}
        sessionuuid={dmvSessionUUID}
        User={dmvUser}
        chats={dmvChats}
        newChatHandler={newChatHandler}
        getHistory={getHistory}
        setHistory={setHistory}
        query={query}
        historyData={dmvHistoryData}
        isLoading={dmvIsLoading}
        getHistoryList={getHistoryList}
        setChats={setDmvChats}
        currentchatid={dmvSessionUUID}
        showHistoryOnly={showHistoryOnly}
        onClosebtn={onClosebtn}
      />
    </>
  );
}

export default ChatInterfaceDmv;
