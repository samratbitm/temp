import React, { useRef, useEffect, useState } from "react";
import "../../styles/ScrollableCards.scss";
import { useError } from "../contexts/ErrorContext";
import { Typography } from "@mui/material";
import ErrorContent from "../common/ErrorContent";

// Define the images locally
const images = [
  "/cardImages/Image3.png",
  "/cardImages/Image4.png",
  "/cardImages/Image5.png",
  "/cardImages/Image6.png",
  "/cardImages/Image7.png",
  "/cardImages/Image8.png",
  "/cardImages/Image9.png",
  "/cardImages/Image10.png",
  "/cardImages/Image11.png",
  "/cardImages/Image12.png",
  "/cardImages/Image13.png",
  "/cardImages/Image14.png",
  "/cardImages/Image15.png",
  "/cardImages/Image16.png",
  "/cardImages/Image17.png",
  "/cardImages/Image18.png",
];

const dmvimages = [
  "/dmvcardImages/Image1.png",
  "/dmvcardImages/Image2.png",
  "/dmvcardImages/Image3.png",
  "/dmvcardImages/Image4.png",
  "/dmvcardImages/Image5.png",
  "/dmvcardImages/Image6.png",
  "/dmvcardImages/Image7.png",
  "/dmvcardImages/Image8.png",
  "/dmvcardImages/Image9.png",
  "/dmvcardImages/Image10.png",
  "/dmvcardImages/Image11.png",
  "/dmvcardImages/Image12.png",
  "/dmvcardImages/Image13.png",
  "/dmvcardImages/Image14.png",
];

const roadimages = [
  "/roadcardImages/Image1.jpeg",
  "/roadcardImages/Image2.jpeg",
  "/roadcardImages/Image3.jpeg",
  "/roadcardImages/Image4.jpeg",
  "/roadcardImages/Image5.jpeg",
  "/roadcardImages/Image6.jpeg",
  "/roadcardImages/Image7.jpeg",
  "/roadcardImages/Image8.jpeg",
  "/roadcardImages/Image9.jpeg",
  "/roadcardImages/Image10.jpeg",
  "/roadcardImages/Image11.jpeg",
  "/roadcardImages/Image12.jpeg",
  "/roadcardImages/Image13.jpeg",
  "/roadcardImages/Image14.jpeg",
];
// const BING_API_KEY = "8d0ebbf31b21461d8d15fa68a4372acf";
// const BING_ENDPOINT = "https://api.bing.microsoft.com/v7.0/images/search";

// const fetchAIGeneratedImage = async (
//   query = "AI generated cyberpunk alleyway"
// ) => {
//   try {
//     const url = new URL(BING_ENDPOINT);
//     url.searchParams.append("q", query);
//     url.searchParams.append("count", 1);
//     url.searchParams.append("offset", Math.floor(Math.random() * 50)); // Randomize results a bit

//     const response = await fetch(url, {
//       headers: {
//         "Ocp-Apim-Subscription-Key": BING_API_KEY,
//       },
//     });

//     if (!response.ok) {
//       throw new Error("Failed to fetch");
//     }

//     const data = await response.json();
//     return data.value.length
//       ? data.value[0].contentUrl
//       : "https://via.placeholder.com/200x150";
//   } catch (error) {
//     console.error("Error fetching images from Bing:", error);
//     return "https://via.placeholder.com/200x150";
//   }
// };

// const PEXELS_API_KEY =
//   "vDcXRJqznG4ball9XLVkrs4kr24UoYN74vmUHB9EqZy0T4QpWFSGTxEX"; // Replace with your Pexels API key

// const keywords = [
//   'AI generated beautiful abstract painting',
//   'AI generated futuristic cityscape at night',
//   'AI generated serene landscape with mountains',
//   'AI generated imaginative creature',
//   'AI generated intricate fractal pattern',
//   'AI generated colorful sunset over the ocean',
//   'AI generated surreal dreamscape',
//   'AI generated vibrant underwater scene',
//   'AI generated magical forest',
//   'AI generated cyberpunk alleyway'
// ];

// const getRandomKeyword = () =>
//   keywords[Math.floor(Math.random() * keywords.length)];

// const fetchAIGeneratedImage = async () => {
//   const keyword = getRandomKeyword();
//   try {
//     const response = await fetch(
//       `https://api.pexels.com/v1/search?query=${keyword}&per_page=1&page=${
//         Math.floor(Math.random() * 100) + 1
//       }`,
//       {
//         headers: {
//           Authorization: PEXELS_API_KEY,
//         },
//       }
//     );
//     const data = await response.json();
//     return data.photos.length
//       ? data.photos[0].src.medium
//       : "https://via.placeholder.com/200x150";
//   } catch (error) {
//     console.error("Error fetching images from Pexels:", error);
//     return "https://via.placeholder.com/200x150";
//   }
// };

// const fetchRandomImage = async () => {
//   try {
//     const response = await fetch(
//       `https://api.pexels.com/v1/curated?per_page=1&page=${
//         Math.floor(Math.random() * 100) + 1
//       }`,
//       {
//         headers: {
//           Authorization: PEXELS_API_KEY,
//         },
//       }
//     );
//     const data = await response.json();
//     return data.photos.length
//       ? data.photos[0].src.medium
//       : "https://via.placeholder.com/200x150";
//   } catch (error) {
//     console.error("Error fetching images from Pexels:", error);
//     return "https://via.placeholder.com/200x150";
//   }
// };

const ScrollableCards = ({
  apptype,
  cards,
  selectsuggestivequestion,
  cardsWithImages,
  setCardsWithImages,
  isCardScrollable,
  setIsCardScrollable,
}) => {
  // const [cardsWithImages, setCardsWithImages] = useState([]);
  const cardsContainerRef = useRef(null);
  const { errorMessages } = useError();
  // const [isCardScrollable, setIsCardScrollable] = useState(false);

  useEffect(() => {
    const checkScrollable = () => {
      const container = cardsContainerRef.current;
      if (container) {
        setIsCardScrollable(container.scrollWidth > container.clientWidth);
      }
    };

    checkScrollable();
    window.addEventListener("resize", checkScrollable);
    return () => window.removeEventListener("resize", checkScrollable);
  }, [cardsWithImages]);

  const fetchLocalImage = () => {
    try {
      debugger;
      if (apptype == "legislativebills") {
        const randomIndex = Math.floor(Math.random() * images.length);
        return images[randomIndex];
      } else if (apptype == "dmv") {
        const randomIndex = Math.floor(Math.random() * dmvimages.length);
        return dmvimages[randomIndex];
      } else if (apptype == "dmv") {
        const randomIndex = Math.floor(Math.random() * roadimages.length);
        return roadimages[randomIndex];
      }
    } catch (error) {
      console.error("Error fetching local image:", error);
    }
  };

  useEffect(() => {
    console.log("hi", cards);
    const updateCardsWithImages = async () => {
      const updatedCards = cards.map((card) => {
        const image = fetchLocalImage();
        return {
          ...card,
          image,
        };
      });
      setCardsWithImages(updatedCards);
    };

    updateCardsWithImages();
  }, [cards]);

  //   const fetchImages = async () => {
  //     try {
  //       const response = await fetch(
  //         `https://api.pexels.com/v1/search?query=nature&per_page=${cards.length}`,
  //         {
  //           headers: {
  //             Authorization: PEXELS_API_KEY,
  //           },
  //         }
  //       );
  //       const data = await response.json();
  //       const updatedCards = cards.map((card, index) => ({
  //         ...card,
  //         image: data.photos[index].src.medium,
  //       }));
  //       setCardsWithImages(updatedCards);
  //     } catch (error) {
  //       console.error("Error fetching images from Pexels:", error);
  //     }
  //   };

  //   fetchImages();
  // }, [cards]);

  const handleLeftScroll = () => {
    const container = cardsContainerRef.current;
    if (container) {
      //     const maxScrollLeft = container.scrollWidth - container.clientWidth;
      //     const newScrollLeft = Math.max(
      //       0,
      //       container.scrollLeft - container.clientWidth / 2
      //     );
      const cardWidth = container.querySelector(".card").clientWidth;
      const newScrollLeft = Math.max(0, container.scrollLeft - cardWidth);
      container.scrollTo({
        left: newScrollLeft,
        behavior: "smooth",
      });
    }
  };

  const handleRightScroll = () => {
    const container = cardsContainerRef.current;
    if (container) {
      const cardWidth = container.querySelector(".card").clientWidth;
      const newScrollLeft = Math.min(
        container.scrollLeft + cardWidth,
        container.scrollWidth - container.clientWidth
      );
      container.scrollTo({
        left: newScrollLeft,
        behavior: "smooth",
      });
    }
  };

  return (
    <div className="parent-container1">
      {errorMessages.cards && <ErrorContent message={errorMessages.cards} />}
      {isCardScrollable && (
        <button className="scroll-btn1 left-btn1" onClick={handleLeftScroll}>
          &#10094;
        </button>
      )}
      <div className="scrollable" ref={cardsContainerRef}>
        {cardsWithImages.map((card, index) => (
          <div
            className="card"
            key={index}
            onClick={(e) => selectsuggestivequestion(e, card.title)}
          >
            <img src={card.image} alt={card.title} className="card-image" />

            <div className="card-text">{card.title}</div>
          </div>
        ))}
      </div>
      {isCardScrollable && (
        <button className="scroll-btn1 right-btn1" onClick={handleRightScroll}>
          &#10095;
        </button>
      )}
    </div>
  );
};

export default ScrollableCards;
