import React, { useState } from "react";
import {
  ThumbUpAlt as ThumbUpAltIcon,
  ThumbUpAltOutlined as ThumbUpAltOutlinedIcon,
  ThumbDownAlt as ThumbDownAltIcon,
  ThumbDownAltOutlined as ThumbDownAltOutlinedIcon,
  Done as DoneIcon,
  FileCopyOutlined as FileCopyOutlinedIcon,
  InfoOutlined as InfoOutlinedIcon,
} from "@mui/icons-material";
import { Container, Typography } from "@mui/material";
import FeedbackAccordion from "./FeedbackAccordion";
import { useNavigate } from "react-router-dom";
import FormComponent from "../formikForm/FormComponent";
import ReactMarkdown from 'react-markdown';


const BotMessage = ({
  formsubmittedfromparent,
  formconfigs,
  chats,
  index,
  replaceWithBr,
  assistantContent,
  isTyping,
  ratings,
  handleThumbsUp,
  handleThumbsDown,
  openModal,
  isUpAccordionVisible,
  isExpanded,
  toggleAccordion,
  feedback,
  handleFeedbackChange,
  handleFormConfigChange,
  handlefeedback,
  isSubmitted,
}) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = (text) => {
    let parsedText = text.replace(/<[^>]+>/g, "");
    navigator.clipboard
      .writeText(parsedText)
      .then(() => {
        setCopied(true);
        setTimeout(() => {
          setCopied(false);
        }, 2000); //  Change back to copy icon after 2 seconds */
      })
      .catch((error) => {
        console.error("Failed to copy:", error);
        alert("Failed to copy to clipboard.");
      });
  };

  return (
    <div className="bot-message">
      <img className="ai-avatar-icon" src="/AI Avatar.svg" alt="AI Avatar" />
      <div className="this-line-is-a-comment-it-won-parent">
        <div
          className="this-line-is"
          style={{ display: "inline-block", whiteSpace: "pre-wrap" }}
        >          
            {replaceWithBr(assistantContent[index + 1]?.content)}          
        </div>
        <div
          className={
            isTyping && index === chats.length - 1 ? "hide" : "thumb-up-group"
          }
        >
          <div
            onClick={() => handleThumbsUp(index)}
            style={{
              display: "inline-flex",
              alignItems: "center",
              cursor: "pointer",
            }}
          >
            {ratings[index + 1]?.thumbsUp > 0 ? (
              <ThumbUpAltIcon />
            ) : (
              <ThumbUpAltOutlinedIcon />
            )}
          </div>
          <div
            onClick={() => handleThumbsDown(index)}
            style={{
              display: "inline-flex",
              alignItems: "center",
              cursor: "pointer",
            }}
          >
            {ratings[index + 1]?.thumbsDown > 0 ? (
              <ThumbDownAltIcon />
            ) : (
              <ThumbDownAltOutlinedIcon />
            )}
          </div>
          {copied ? (
            <DoneIcon className="refresh-icon" style={{ cursor: "pointer" }} />
          ) : (
            <FileCopyOutlinedIcon
              className="refresh-icon"
              onClick={() => handleCopy(assistantContent[index + 1]?.content)}
              style={{ cursor: "pointer" }}
            />
          )}
          {ratings[index + 1]?.item && (
            <InfoOutlinedIcon
              className="info-icon1"
              onClick={() => openModal(index)}
              style={{ cursor: "pointer" }}
            />
          )}
        </div>
        {ratings[index + 1]?.thumbsUp > 0 && isUpAccordionVisible && (
          <Container
            maxWidth="sm"
            width="100%"
            sx={{
              boxShadow: "0 0 0 1px #0D99FF",
              borderRadius: "4px",
              backgroundColor: "var(--color-white)",
              padding: "8px 10px !important",
            }}
          >
            <Typography variant="body1" sx={{ fontSize: "14px" }}>
              Glad you liked this answer!
            </Typography>
          </Container>
        )}
        {ratings[index + 1]?.thumbsDown > 0 && (
          <FeedbackAccordion
            index={index}
            ratings={ratings}
            isExpanded={isExpanded}
            toggleAccordion={toggleAccordion}
            feedback={feedback}
            handleFeedbackChange={handleFeedbackChange}
            handlefeedback={handlefeedback}
            isSubmitted={isSubmitted}
          />
        )}
        {Object.keys(formconfigs).map(
          (key, ind) =>
            formconfigs[key].formconfig &&
            key == index + 1 && (
              <FormComponent
                formsubmittedfromparent={formsubmittedfromparent}
                key={ind}
                index={index}
                formconfig={formconfigs[key].formconfig}
                handleFormConfigChange={handleFormConfigChange}
                submitvalid={formconfigs[key].isvalid}
              />
            )
        )}
      </div>
    </div>
  );
};

export default BotMessage;
