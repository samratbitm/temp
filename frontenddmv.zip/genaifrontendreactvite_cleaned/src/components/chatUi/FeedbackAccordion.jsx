import React from "react";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Typography,
  Button,
  Container,
  TextareaAutosize,
} from "@mui/material";
import { ExpandMore as ExpandMoreIcon } from "@mui/icons-material";

const FeedbackAccordion = ({
  index,
  ratings,
  isExpanded,
  toggleAccordion,
  feedback,
  handleFeedbackChange,
  handlefeedback,
  isSubmitted,
}) => (
  <Accordion
    key={ratings[index + 1]?.question_id}
    expanded={isExpanded[ratings[index + 1]?.question_id]}
    onChange={() => toggleAccordion(ratings[index + 1]?.question_id)}
    sx={{
      width: "100%",
      borderRadius: "4px",
      boxShadow: "none",
      border: "1px solid #0D99FF",
      marginTop: "0px !important",
      "& .MuiAccordionSummary-root": {
        minHeight: "0px !important",
        padding: "8px 10px",
      },
    }}
  >
    <AccordionSummary
      sx={{
        "& .MuiAccordionSummary-content": {
          margin: "0px !important",
        },
      }}
      expandIcon={
        <div style={{ display: "flex", alignItems: "center" }}>
          <ExpandMoreIcon />
        </div>
      }
      aria-controls="panel1bh-content"
    >
      <div className="div-container">
        <Typography variant="body1" sx={{ fontSize: "14px" }}>
          {isSubmitted[ratings[index + 1]?.question_id]
            ? "Thanks for your feedback"
            : "Why wasn’t this helpful?"}
        </Typography>
        <Typography variant="body1" sx={{ fontSize: "14px" }}>
          <a
            href="#"
            style={{
              textDecoration: "none",
              color: "#0D99FF",
              marginLeft: "5px",
            }}
          >
            Give Feedback
          </a>
        </Typography>
      </div>
    </AccordionSummary>
    <AccordionDetails>
      <TextareaAutosize
        aria-label="Feedback"
        placeholder="Please provide your feedback..."
        value={feedback[ratings[index + 1]?.question_id]}
        id="feedback-textarea"
        onChange={(e) =>
          handleFeedbackChange(e, ratings[index + 1]?.question_id)
        }
        style={{
          width: "100%",
          borderBottom: "1px solid #0D99FF",
          borderTop: "none",
          borderLeft: "none",
          borderRight: "none",
          height: "auto",
          resize: "none",
          fontFamily: "Lato",
        }}
      />
      <Button
        variant="text"
        size="small"
        style={{ textTransform: "none", padding: "8px 0", minWidth: "0px" }}
        onClick={() => handlefeedback(index)}
      >
        Submit
      </Button>
    </AccordionDetails>
  </Accordion>
);

export default FeedbackAccordion;
