import React from 'react';

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render shows the fallback UI.
    return { hasError: true };
  }

  static customMarkdownParser(markdown) {
    if (typeof markdown !== 'string') {
      console.error('Expected a string but received:', typeof markdown);
      return markdown;
    }

    // Convert bold (**text**)
    markdown = markdown.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // Convert italics (*text*)
    markdown = markdown.replace(/\*(.*?)\*/g, '<em>$1</em>');

    // Convert underline (__text__)
    markdown = markdown.replace(/__(.*?)__/g, '<u>$1</u>');

    // Convert strikethrough (~~text~~)
    markdown = markdown.replace(/~~(.*?)~~/g, '<del>$1</del>');

    // Convert headings (# Heading)
    markdown = markdown.replace(/^# (.*$)/gim, '<h1>$1</h1>');
    markdown = markdown.replace(/^## (.*$)/gim, '<h2>$1</h2>');
    markdown = markdown.replace(/^### (.*$)/gim, '<h3>$1</h3>');

    // Convert unordered lists (* item)
    markdown = markdown.replace(/^\* (.*$)/gim, '<ul><li>$1</li></ul>');

    // Convert line breaks
    markdown = markdown.replace(/\n/g, '<br>');

    return markdown.trim();
  }

  componentDidCatch(error, errorInfo) {
    // You can also log the error to an error reporting service
    console.error("Error caught by ErrorBoundary:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      // Render the fallback UI with parsed content
      const parsedContent = ErrorBoundary.customMarkdownParser(this.props.content);
      return parsedContent;
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
