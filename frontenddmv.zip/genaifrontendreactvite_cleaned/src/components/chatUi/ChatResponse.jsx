import React from "react";
import UserInput from "./UserInput";
import BotMessage from "./BotMessage";
import parse from "html-react-parser"; //  Assuming parse function is imported */

const ChatResponse = ({
  formsubmittedfromparent,
  formconfigs,
  chats,
  elRefs,
  assistantContent,
  isTyping,
  ratings,
  handleThumbsUp,
  handleThumbsDown,
  openModal,
  isUpAccordionVisible,
  isExpanded,
  toggleAccordion,
  feedback,
  handleFeedbackChange,
  handleFormConfigChange,
  handlefeedback,
  isSubmitted,
}) => {
  const replaceWithBr = (text) => {
    try {
      text = parse(text);
    } catch {}
    return text && text.length ? text : "Loading...";
  };

  return (
    <>
      {chats.map((chat, index) => (
        <div key={index} ref={elRefs.current[index]} className="response-inner">
          {chat.role === "user" ? (
            <UserInput chat={chat} replaceWithBr={replaceWithBr} />
          ) : (
            <BotMessage
              formsubmittedfromparent={formsubmittedfromparent}
              formconfigs={formconfigs}
              chats={chats}
              index={index}
              replaceWithBr={replaceWithBr}
              assistantContent={assistantContent}
              isTyping={isTyping}
              ratings={ratings}
              handleThumbsUp={handleThumbsUp}
              handleThumbsDown={handleThumbsDown}
              openModal={openModal}
              isUpAccordionVisible={isUpAccordionVisible}
              isExpanded={isExpanded}
              toggleAccordion={toggleAccordion}
              feedback={feedback}
              handleFeedbackChange={handleFeedbackChange}
              handleFormConfigChange={handleFormConfigChange}
              handlefeedback={handlefeedback}
              isSubmitted={isSubmitted}
            />
          )}
        </div>
      ))}
    </>
  );
};

export default ChatResponse;
