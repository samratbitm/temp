import React from "react";

const SuggestiveQuestionContent = ({
  isScrollable,
  handleLeftScroll,
  handleRightScroll,
  suggestiveQuestions,
  selectsuggestivequestion,
  linksContainerRef,
}) => (
  <div className="parent-container">
    {isScrollable && (
      <button className="scroll-btn left-btn" onClick={handleLeftScroll}>
        &#10094;
      </button>
    )}
    <div className="scrollable-area" ref={linksContainerRef}>
      <div className="links-container">
        {suggestiveQuestions.map((question, index) => (
          <a
            key={index}
            href="javascript:void(0)"
            className="question-container"
            onClick={(e) => selectsuggestivequestion(e, e.target.textContent)}
          >
            {question}
          </a>
        ))}
      </div>
    </div>
    {isScrollable && (
      <button className="scroll-btn right-btn" onClick={handleRightScroll}>
        &#10095;
      </button>
    )}
  </div>
);

export default SuggestiveQuestionContent;
