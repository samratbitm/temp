from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings, ChatOpenAI
import openai
from app.config import settings

class OpenAIService:
    def __init__(self):
        self.api_key = settings.OPENAI_KEY
        self.azure_api_key = settings.AZURE_OPENAI_KEY
        self.azure_endpoint = settings.AZURE_OPENAI_ENDPOINT
        self.embeddings_model = AzureOpenAIEmbeddings( 
                                            azure_deployment=settings.AZUREEMBEDDINGDEPLOYMENT, 
                                            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                                            openai_api_key=settings.AZURE_OPENAI_KEY,                        
                                            openai_api_version=settings.AZUREOPENAIEMBEDDINGVERSION,
                                            model =settings.EMBEDDINGMODEL                                       
                                            )  
        
        if settings.MODELPROVIDER == "AZUREOPENAI":
            self.llm = AzureChatOpenAI(
                deployment_name=settings.AZUREDEPLOYMENT,
                azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                openai_api_key=settings.AZURE_OPENAI_KEY,
                openai_api_version=settings.AZUREOPENAIVERSION,
                model_name=settings.MODEL,
                temperature=0
            )
            self.client = openai.AzureOpenAI(
                                            azure_endpoint=settings.AZURE_OPENAI_ENDPOINT,
                                            azure_deployment=settings.AZUREDEPLOYMENT,
                                            api_version=settings.AZUREOPENAIVERSION,
                                            api_key=settings.AZURE_OPENAI_KEY,                   
                                            )           
        else:
            self.llm = ChatOpenAI(temperature=0, model=settings.MODEL, openai_api_key=settings.OPENAI_KEY)
            openai.api_key = "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"  
            self.client = openai

    def reformulate_query(self,messages,temp=0):        
        response = self.client.chat.completions.create(
                                                model=settings.MODEL,
                                                messages=messages,
                                                temperature=temp                                  
                                                ) 
        
        reformulated_query = response.choices[0].message.content
        return reformulated_query
    
    
    def generate_langchain_selfquery(self,query,prompt,output_parser):        
        query_constructor = prompt | self.llm | output_parser
        structured_query = query_constructor.invoke({"query": query})  
        return structured_query
    
    def generate_completion_stream(self,completion_prompt,temp=0.4):        
        return self.client.chat.completions.create(
                                    model=settings.MODEL,
                                    messages=completion_prompt,
                                    temperature=temp,
                                    stream=True
                                    )   

    def generate_embeddings(self,text): 
        return self.embeddings_model.embed_query(text)
    
    def generate_dvm(self,messages,temp=0):        
        response = self.client.chat.completions.create(
                                                model=settings.MODEL,
                                                messages=messages,
                                                temperature=temp                                  
                                                ) 
        
        dvmroute = response.choices[0].message.content
        return dvmroute     
    

def get_openai_service():
    return OpenAIService()