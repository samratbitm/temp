import openai
import pymongo
from bson import ObjectId
from app.config import settings
from app.models.models  import FeedbackRatingItem, HistorySessionItem, CardSessionItem
from app.utils.common import JSONEncoder
import urllib.parse

class MongoDBService:
    def __init__(self):
        self.user = urllib.parse.quote_plus(settings.COSMOS_MONGO_USER)                                            
        self.password = urllib.parse.quote_plus(settings.COSMOS_MONGO_PWD)
        mongo_conn = f"mongodb+srv://{self.user}:{self.password}@{settings.COSMOS_MONGO_SERVER}?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000"
        self.client = pymongo.MongoClient(mongo_conn)
        self.db = self.client[settings.DB]

    def fetch_chathistory(self, chat_id):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        chat_historys = list(collection.find({"chatid":chat_id,"gptresponse":{"$not":{"$regex":"I apologize, but there is no data matching your message"}}}).sort({"insertedDate":-1}).limit(3))
        return chat_historys
    
    def add_history(self, record):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        return collection.insert_one(record)
    
    
    def upsert_session(self, chat_id, record):
        collection = self.db[settings.DB_COLLECTION_SESSION]
        query = {"chatid": chat_id}
        return collection.update_one(query,record,upsert=True)
    
    
    def bills_search_pipeline(self, aggregatepipeline):
        collection = self.db[settings.DB_COLLECTION_BILLS]        
        return collection.aggregate(aggregatepipeline)
    
    
    def fetch_dmv_pipeline(self, aggregatepipeline):
        collection = self.db[settings.DB_COLLECTION_DMV]
        return list(collection.aggregate(aggregatepipeline))

def get_mongo_service():
    return MongoDBService()