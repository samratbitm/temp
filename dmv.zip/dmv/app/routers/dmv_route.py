import os
from typing import List
from fastapi import APIRouter, HTTPException, Response
from fastapi.params import Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from app.businesslogic.orchestrator import Orchestrator
from app.businesslogic.response_generator import ResponseGenerator
from app.models.models import ChatCompletionItem, DMVChatCompletionItem, PDFRequest, Section
from app.services.mongo_service import MongoDBService
from app.services.openai_service import OpenAIService
from app.middlewares import jwt_bearer
from app.utils.common import create_pdf, ensure_values_are_strings


router = APIRouter()

@router.get("/")
def read_root():
    return {"Message": "DMV APIs running..."}

@router.post("/chatcompletion/stream", dependencies=[Depends(jwt_bearer)])
async def generate_dmv_response(json_data: dict, orchestrator: Orchestrator = Depends(),response_generator: ResponseGenerator = Depends()):
    try:
        ensure_values_are_strings(json_data)
        dmvitem = DMVChatCompletionItem(**json_data)
        reformulated_query = orchestrator.reformulate_query(dmvitem.chatcompletiontitem)
        json_dmvroute = orchestrator.dvmroute_identification(reformulated_query,dmvitem)

        if "NonForm" in json_dmvroute["UserIntent"]:    
            search_result = orchestrator.search_dmv(reformulated_query,dmvitem.chatcompletiontitem)   
            return StreamingResponse(response_generator.generate_dmv_completion_stream(search_result,dmvitem.chatcompletiontitem), media_type='text/event-stream')
        
        dvmformvalue = orchestrator.dmvformvalue_identification(dmvitem.chatcompletiontitem.user_message,dmvitem)
        #return: load_form_driverlicense
        return StreamingResponse(response_generator.generate_dmv_driverlicenseformresponse(json_dmvroute,dvmformvalue,dmvitem), media_type='text/event-stream')
    
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")
    

@router.post("/generate-pdf", dependencies=[Depends(jwt_bearer)])
async def generate_pdf(pdf_request: PDFRequest):    
    try:
        #sections = List[Section](**json_data)
        name = pdf_request.sections[0].fields[0].value
        topic = "DRIVERS LICENSE  AI AGENT DEMONSTRATION"
        pdf_content = create_pdf(pdf_request.sections,os.path.join("app/data", "TexLogoLight.png"),topic)
        return Response(content=pdf_content, media_type="application/pdf", headers={
            "Content-Disposition": f"attachment; filename=DriverLicenseForm_{name}.pdf"
        })
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")