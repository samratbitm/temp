from fastapi import APIRouter
from app.routers import dmv_route

router = APIRouter()

@router.get("/")
def read_root():
    return {"Message": "Pilot GenAI Copilot APIs running for DMV module..."}

router.include_router(dmv_route.router, prefix="/dmv", tags=["dmv"])
