import json
from bson import ObjectId
from typing import List, Optional
from fastapi import HTTPException
from fpdf import FPDF
from app.models.models import Section
from app.config import settings
from typing import List
import unicodedata


class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)

# def create_pdf(sections: List[Section]) -> bytes:
#     pdf = FPDF()
#     pdf.add_page()
#     pdf.set_font("Arial", size=12)
    
#     for section in sections:
#         pdf.cell(200, 10, txt=section.title, ln=True, align='C')
#         pdf.ln(10)  # Add some vertical space
#         for field in section.fields:
#             if field.value:
#                 field_text = f"{field.label}: {field.value}"
#             else:
#                 field_text = f"{field.label}: [Not Provided]"
#             pdf.cell(200, 10, txt=field_text, ln=True)
#         pdf.ln(10)  # Add some vertical space after each section
    
#     # Output PDF to a bytes object
#     pdf_buffer = pdf.output(dest='S').encode('latin1')  # Using 'S' returns a string
    
#     return pdf_buffer

def sanitize_text(text: str) -> str:
    """Replace non-ASCII characters with their closest ASCII equivalents."""
    return unicodedata.normalize('NFKD', text).encode('ascii', 'ignore').decode('ascii')


def create_pdf(sections: List[Section], header_image_path: str, topic: str) -> bytes:
    pdf = FPDF()
    pdf.add_page()
    
    # Add a line at the top
    pdf.set_draw_color(50, 50, 50)  # Dark gray color
    pdf.line(10, 10, 200, 10)
    
    # Add the header image with a white background
    pdf.set_fill_color(255, 255, 255)  # White background
    pdf.rect(10, 10, 190, 30, style='F')  # Draw a white rectangle for the background
    pdf.image(header_image_path, x=10, y=10, w=190)  # Add the image with full width of the page
    
    # Add spacing between image and topic
    pdf.ln(40)
    
    # Sanitize the topic
    topic = sanitize_text(topic)
    
    # Add the topic with a proper underline (not underscores)
    pdf.set_font("Arial", style="B", size=14)
    pdf.set_text_color(50, 50, 50)  # Dark gray text
    pdf.cell(0, 10, txt=topic, ln=True, align="C")
    
    # Draw a proper underline directly below the topic
    topic_width = pdf.get_string_width(topic)
    pdf.set_draw_color(50, 50, 50)  # Dark gray for underline
    x_start = (210 - topic_width) / 2  # Center the underline
    pdf.line(x_start, pdf.get_y(), x_start + topic_width, pdf.get_y())
    pdf.ln(5)  # Minimal gap after underline
    
    # Add sections and fields
    for section in sections:
        for field in section.fields:
            label_text = sanitize_text(f"{field.label}: ")
            value_text = sanitize_text(field.value if field.value else "[Not Provided]")
            
            # Add label in bold with left margin
            pdf.set_font("Arial", style="B", size=12)
            pdf.cell(15, 10, "", ln=False)  # Left margin
            pdf.cell(80, 10, txt=label_text, ln=False)
            
            # Add value in bold with dark gray box and proper right margin
            pdf.set_font("Arial", style="B", size=12)
            pdf.set_fill_color(255, 255, 255)  # White background
            pdf.set_draw_color(50, 50, 50)  # Dark gray border
            pdf.cell(90, 10, txt=value_text, border=1, ln=True, align="C", fill=True)
        
        pdf.ln(10)  # Add some vertical space after each section
    
    # Output PDF to a bytes object
    pdf_buffer = pdf.output(dest='S').encode('latin1')  # Using 'S' returns a string
    return pdf_buffer

def load_form_driverlicense():
    with open(settings.DRIVER_LICENSE_FORMTEMPLATE, 'rb') as file:
        data = json.loads(file.read())
    return data

def reload_form_driverlicense(formconfig, reformconfig):  
    fieldsempty = []    
    if is_valid_dict(reformconfig):
        formconfig = json.loads(formconfig)
        for section in formconfig["sections"]:            
            for field in section["fields"]:
                try:
                    if field["name"] == "weight" or field["name"] == "height":
                        label = "Height" if field["name"] == "height" else "Weight"
                        field["value"] = int(float(reformconfig["UpdatedFieldValues"][label].replace("lbs","").replace("inches","").replace("inch","").strip()))
                        if field["value"] == 0:
                            raise HTTPException(status_code=400, detail=f"number 0")
                    else:
                        field["value"] = reformconfig["UpdatedFieldValues"][field["label"]]
                except:
                    fieldsempty.append(field["name"])
        formconfig = json.dumps(formconfig)
    
    return {"form":formconfig, "emptyfields": fieldsempty}

def is_valid_json(json_string):
    try:
        json.loads(json_string)
        return True
    except ValueError as e:
        return False
    
def is_valid_dict(obj):
    return isinstance(obj, dict)

def ensure_values_are_strings(data):
    if isinstance(data, dict):
        for key, value in data.items():
            if key == 'value' and not isinstance(value, str):
                data[key] = str(value)
            else:
                ensure_values_are_strings(value)
    elif isinstance(data, list):
        for item in data:
            ensure_values_are_strings(item)