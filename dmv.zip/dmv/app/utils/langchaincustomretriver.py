from collections import defaultdict
import json
from typing import List
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from langchain.chains.query_constructor.base import (  
    StructuredQuery,
)
from app.services.mongo_service import MongoDBService
from app.services.openai_service import OpenAIService
from app.utils.mongo_query_converter import parse_operation

class CosmosMongoVectorRetriever(BaseRetriever):
    """A Cosmos Mongo retriever that contains the top k documents that contain the user query.

    This retriever only implements the sync method _get_relevant_documents.

    If the retriever were to involve file access or network access, it could benefit
    from a native async implementation of `_aget_relevant_documents`.

    As usual, with Runnables, there's a default async implementation that's provided
    that delegates to the sync implementation running on another thread.
    """

    # documents: List[Document]
    # """List of documents to retrieve from."""
    k: int
    """Number of top results to return"""
    structuredquery:StructuredQuery

    mongo_service:MongoDBService
    
    openai_service:OpenAIService


    def _get_relevant_documents(
        self, query: str, *, run_manager: CallbackManagerForRetrieverRun
    ) -> List[Document]:
        """Sync implementations for retriever."""
        
        results = self.vector_search_retriver()
        userquery = results["user_query"] 
        count = results["count"]
        docs = results['results']
        
        return docs

    # Optional: Provide a more efficient native implementation by overriding
    # _aget_relevant_documents
    # async def _aget_relevant_documents(
    #     self, query: str, *, run_manager: AsyncCallbackManagerForRetrieverRun
    # ) -> List[Document]:
    #     """Asynchronously get documents relevant to a query.

    #     Args:
    #         query: String to find relevant documents for
    #         run_manager: The callbacks handler to use

    #     Returns:
    #         List of relevant documents
    #     """
    def vector_search_retriver(self):
    
        query_embedding = self.openai_service.generate_embeddings(self.structuredquery.query)
        filterJson = cosmosdb_query_convertor(self.structuredquery)
        
        if filterJson is not None: 
            search = {
                '$search': {
                    "cosmosSearch": {                    
                            "vector": query_embedding,
                            "path": "contentVector",
                            "k": self.k, #, "efsearch": 40 # optional for HNSW only  
                            "filter" :  filterJson                     
                        },
                    "returnStoredSource": True
                }
            }
        else:
            search = {
                '$search': {
                    "cosmosSearch": {                    
                            "vector": query_embedding,
                            "path": "contentVector",
                            "k": self.k #, "efsearch": 40 # optional for HNSW only 
                        },
                    "returnStoredSource": True
                }
            }
        
        vectorpipeline = [
            search
            ,
            {
                '$project':{ 
                    'similarityScore':{ 
                            '$meta': 'searchScore' 
                        }, 
                    'document' : '$$ROOT'                     
                } 
            },
            {
                '$set':{
                    'similarityScore': '$similarityScore',                
                    'page_content':'$document.page_content',
                    'year': {'$toInt':'$document.year'},
                    'serialnumber': '$document.serialnumber',
                    'house': '$document.house',
                    'billstatus': '$document.billstatus',
                    'order': '$document.order',
                    'title': '$document.title',
                    'docTitle': '$document.docTitle',
                    'docName': '$document.docName',
                    'category': '$document.category',                     
                }
            },  
            {
                '$group':{                
                    '_id':{
                        'serialnumber':'$serialnumber',    
                        'year':'$year',
                        'order':'$order'
                    },
                    'similarityScore': {'$last':'$similarityScore'},    
                    'score': {'$last':'$similarityScore'}, 
                    'content': {'$last':'$page_content'},             
                    'page_content':{'$last':'$page_content'},
                    'year': {'$last':'$year'},
                    'serialnumber': {'$last':'$serialnumber'},
                    'house': {'$last':'$house'},
                    'billstatus': {'$last':'$billstatus'},
                    'order': {'$last':'$order'},
                    'title': {'$last':'$title'},
                    'docTitle': {'$last':'$docTitle'},
                    'docName': {'$last':'$docName'},
                    'category': {'$last':'$category'},          
                }
            } ,    
            {
                '$sort' :{
                    'similarityScore' : -1               
                }
            },
            # {
            #     '$limit': K_searcchcounter_default
            # },        
            {
                '$sort' :{
                    'year' : -1,
                    'serialnumber':1,
                    'order':1             
                }
            }
        ]
        
        allresults = self.mongo_service.bills_search_pipeline(vectorpipeline)

        key = []
        count = 0
        searchresults = []
        for x in allresults:       
            searchresults.append(VectorSearchContent(x["year"],x["serialnumber"],x["billstatus"],x["score"],x["content"],x['title']))
            if (x["serialnumber"],x["year"]) not in key:
                key.append((x["serialnumber"],x["year"]))
                count += 1    
        
        res = defaultdict(VectorSearchContent)

        for result in searchresults:
            res[result.get_key()].page_content =  "%s%s" % (res[result.get_key()].page_content,result.page_content)
            res[result.get_key()].score =  result.score
            res[result.get_key()].billstatus =  result.billstatus
            res[result.get_key()].year =  result.year
            res[result.get_key()].serialnumber =  result.serialnumber
            res[result.get_key()].metadata =  result.metadata
            res[result.get_key()].title =  result.title

        results = [VectorSearchContent(*k, v.billstatus,v.score,v.page_content) for k, v in res.items()]   

        results = sorted(results, key=lambda x: x.score, reverse=True)

        return {"results":results, "user_query":self.structuredquery.query, "count":count}


class CosmosMongoTextSearchRetriever(BaseRetriever):
    """A Cosmos Mongo retriever that contains the top k documents that contain the user query.

    This retriever only implements the sync method _get_relevant_documents.

    If the retriever were to involve file access or network access, it could benefit
    from a native async implementation of `_aget_relevant_documents`.

    As usual, with Runnables, there's a default async implementation that's provided
    that delegates to the sync implementation running on another thread.
    """

    # documents: List[Document]
    # """List of documents to retrieve from."""
    k: int 
    """Number of top results to return"""
    structuredquery:StructuredQuery

    mongo_service:MongoDBService    
    

    def _get_relevant_documents(
        self, query: str, *, run_manager: CallbackManagerForRetrieverRun
    ) -> List[Document]:
        """Sync implementations for retriever."""        
            
        results = self.text_search_retriver()
        userquery = results["user_query"] 
        count = results["count"]
        docs = results['results']
        
        return docs

    # Optional: Provide a more efficient native implementation by overriding
    # _aget_relevant_documents
    # async def _aget_relevant_documents(
    #     self, query: str, *, run_manager: AsyncCallbackManagerForRetrieverRun
    # ) -> List[Document]:
    #     """Asynchronously get documents relevant to a query.

    #     Args:
    #         query: String to find relevant documents for
    #         run_manager: The callbacks handler to use

    #     Returns:
    #         List of relevant documents
    #     """

    def text_search_retriver(self):   
    
        filteroptions = text_query_convertor(self.structuredquery)
        
        search_text = f"\\{self.structuredquery.query}\\"
        
        if filteroptions["filter"] != '':
            search_text = search_text + " " + filteroptions["filter"]
        
        query = {"$text": {"$search": search_text}}
        if filteroptions["additional_filters"] != '':
                query = {
                    "$and": [
                        {"$text": {"$search": search_text}},
                        json.loads(json.dumps(filteroptions["additional_filters"]))
                    ]
                }

        test_searchpipeline = [
        { "$match": query },    
        { "$sort": { 'year' : -1,'serialnumber':1,'order':1 } },
        { "$project": { "year":1, "serialnumber":1, "billstatus":1, "page_content": 1, "title":1, "_id": 0, "score": { "$meta": "textScore" } } }     
    ]
        
        
        allresults = self.mongo_service.bills_search_pipeline(test_searchpipeline)

        key = []
        count = 0
        searchresults = []
        for x in allresults:       
            searchresults.append(VectorSearchContent(x["year"],x["serialnumber"],x["billstatus"],x["score"],x["page_content"],x['title']))
            if (x["serialnumber"],x["year"]) not in key:
                key.append((x["serialnumber"],x["year"]))
                count += 1    
        
        res = defaultdict(VectorSearchContent)

        for result in searchresults:
            res[result.get_key()].page_content =  "%s%s" % (res[result.get_key()].page_content,result.page_content)
            res[result.get_key()].score =  result.score
            res[result.get_key()].billstatus =  result.billstatus
            res[result.get_key()].year =  result.year
            res[result.get_key()].serialnumber =  result.serialnumber
            res[result.get_key()].metadata =  result.metadata
            res[result.get_key()].title =  result.title

        results = [VectorSearchContent(*k, v.billstatus,v.score,v.page_content,v.title) for k, v in res.items()]   

        results = sorted(results, key=lambda x: x.score, reverse=True)

        return {"results":results, "user_query":self.structuredquery.query, "count":count}



def cosmosdb_query_convertor(structuredquery, selected_attributes = ['serialnumber', 'year','billstatus','house']):    
    filter = None
    try:
        if structuredquery.filter is not None:            
            operation_obj = parse_operation("Operation("+str(structuredquery.filter)+")")
            filter = operation_obj.to_mongo_query(attributes=selected_attributes,isvector = True)
    except Exception as err:
        print("error"+err)
        filter = None

    return filter

def text_query_convertor(structuredquery):    
    filter = ''
    selected_attributes = ''

    try:
        if structuredquery.filter is not None:
            operation_obj = parse_operation("Operation("+str(structuredquery.filter)+")")
            try:
                selected_attributes = ['serialnumber', 'year','billstatus', 'user','house']
                additional_filters = operation_obj.to_mongo_query(attributes=selected_attributes,isvector = False)
            except Exception as err:
                print("error"+err)
                selected_attributes = ''
            try:
                selected_attributes = ['user', 'usertype']            
                filter = operation_obj.to_custom_string(attributes=selected_attributes)
            except Exception as err:
                print("error"+err)
                filter = ''
    except Exception as err:   
        print("error"+err) 
        filter = ''
        selected_attributes = ''

    return {"filter": filter,"additional_filters":additional_filters}


class VectorSearchContent:    
    metadata ={}
    page_content = ""
    year = ""
    serialnumber =""
    billstatus =""
    score=""
    title=""

    def __init__(self, year="", serialnumber="", billstatus="",score="",page_content="",title=""):
        if year != '':
            self.year = int(year) if year else 0
            self.serialnumber = serialnumber
            self.billstatus = billstatus
            self.score = float(score) if score else 0.0
            self.metadata = {"year":year,"serialnumber":serialnumber,"billstatus":billstatus}
            self.page_content = page_content
            self.title = title

    def get_key(self):
        return (self.year, self.serialnumber)

    def __repr__(self):
        return "<{}, {}>".format(self.metadata, self.page_content)
    
    def to_dict(self):
        return {
            'year': self.year,
            'serialnumber': self.serialnumber,
            'billstatus': self.billstatus,
            'score': self.score,
            'metadata': self.metadata,
            'page_content': self.page_content,
            'title': self.title
        }


class CustomVectorSearchContentEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, VectorSearchContent):
            return obj.to_dict()
        # Let the base class default method raise the TypeError
        return super().default(obj)


def listVectorSearchContent_to_json_string(lst):
    return json.dumps(lst, cls=CustomVectorSearchContentEncoder)


def json_string_to_listVectorSearchContent(raw_list,isjson=True,isscore = True):
    
    if isjson:
        raw_list = json.loads(raw_list)    

    def to_vector_search_content(x,isscore = True):
        if isscore:
            return VectorSearchContent(x["year"],x["serialnumber"],x["billstatus"],x["score"],x["page_content"],x["title"])
        else:
            return VectorSearchContent(x["year"],x["serialnumber"],x["billstatus"],"1",x["page_content"],x["title"])
        
    return [to_vector_search_content(item,isscore) for item in raw_list]


