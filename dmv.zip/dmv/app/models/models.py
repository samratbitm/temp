from pydantic import BaseModel
from typing import List, Optional
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    COSMOS_MONGO_USER: str
    COSMOS_MONGO_PWD: str
    COSMOS_MONGO_SERVER: str
    DB: str
    DB_COLLECTION_BILLS: str
    DB_COLLECTION_DMV: str
    DB_COLLECTION_HISTORY: str
    DB_COLLECTION_SESSION: str
    MODELPROVIDER: str
    MODEL: str
    EMBEDDINGMODEL: str
    AZUREOPENAIVERSION: str
    AZUREOPENAIEMBEDDINGVERSION: str
    AZUREDEPLOYMENT: str    
    AZUREEMBEDDINGDEPLOYMENT: str    
    AZURE_OPENAI_ENDPOINT: str
    AZURE_OPENAI_KEY: str
    OPENAI_KEY: str    
    DRIVER_LICENSE_FORMTEMPLATE: str

    class Config:
        env_file = ".env"

class ChatCompletionItem(BaseModel):
    model_name: str = "3.5"
    user_message: str
    filter_options: str
    chat_history: None
    chat_id: str
    user_id: str
    app_type: str = "legislativebills"

    class Config:
        protected_namespaces = ()

class FeedbackRatingItem(BaseModel):
    question_id: str
    user_sentiment: str
    user_comment: str
    app_type: str = "legislativebills"

class HistorySessionItem(BaseModel):
    chat_id: str
    user_id: str
    app_type: str = "legislativebills"

class CardSessionItem(BaseModel):
    card_id: str
    user_id: str
    app_type: str = "legislativebills"

class Validation(BaseModel):
    required: Optional[bool] = False
    minLength: Optional[int] = None

class Field(BaseModel):
    name: str
    label: str
    type: str
    value: Optional[str] = ""
    validation: Optional[Validation] = None
    options: Optional[List[str]] = None

class Section(BaseModel):
    title: str
    fields: List[Field]

class DMVChatCompletionItem(BaseModel):
    chatcompletiontitem: ChatCompletionItem
    sections: Optional[List[Section]] = None
    
class PDFRequest(BaseModel):
    sections: List[Section]
