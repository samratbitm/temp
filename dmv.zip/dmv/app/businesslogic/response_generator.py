import base64
import datetime
import json
from app.models.models import ChatCompletionItem, DMVChatCompletionItem
from app.services.mongo_service import MongoDBService, get_mongo_service
from app.services.openai_service import OpenAIService, get_openai_service
from app.config import settings
from app.utils.langchaincustomretriver import listVectorSearchContent_to_json_string
from app.utils.common import create_pdf, is_valid_dict, is_valid_json, load_form_driverlicense, reload_form_driverlicense
from fastapi import Depends, HTTPException


class ResponseGenerator:
    def __init__(self, mongo_service: MongoDBService = Depends(get_mongo_service),
                 openai_service: OpenAIService = Depends(get_openai_service)):
        self.mongo_service = mongo_service
        self.openai_service = openai_service
        self.num_result_default = 500
        self.K_searcchcounter_default = 5

    def generate_dmv_completion_stream(self, search_results, item:ChatCompletionItem):

        context = "" 
        info_df = []
        isInformationPassed = False 
        agent_result =  None

        aiquerycount = 0
        agent_count = 0
        is_agent = False

        for i, blockcontent in enumerate(search_results):
            image_htlm = ""
            context += f"record_id:{i+1}, text_content: {blockcontent['metadata']['text']}\n\n"

            for j, image in enumerate(blockcontent['metadata']['images']):
                image_tag = f"<img src='data:image/{image['ext']};base64,{image['base64']}'/>"
                image_htlm += image_tag
            
            info_df.append({'id':i+1 ,'content':blockcontent['metadata']['text'], 'score': blockcontent['similarityScore'],'page': blockcontent['page'],'para': blockcontent['para'],'image_htlm':f"<br/>{image_htlm}"  if "image_htlm" != "" else image_htlm})
            isInformationPassed = True  
        
        system_prompt = f"""
        You are a helpful assistant specialized in answering questions about Driver Motor Vehicle. You will answer questions strictly based on the provided DMV data. Each record in DMV data is seperated by two new lines where record id i.e. "record_id" is numeric id of record and text content i.e. "text_content" is the texts to answer user question if found relevant. Follow these guidelines closely:
        
        DMV data:
        {context}

        """

        # User guidelines for accurate responses
        user_prompt = """
            Guidelines:
            1. Identify all records that is relevant to answers based on user question.
            2. Provide answers in bullet points for each record.   
            3. Answer only using the provided DMV data and never infer information not present.
            4. If unable to answer, respond with: 'I apologize, but there is no data matching your message. Could you please provide more information or clarify your request? We recommend refining your question with additional details for more specific results.'
            5. Always mention record id after the bullet poits of that record and before starting bullet point of new record based on below instrunction:
                - Always prefix with '<div class="recordId" style="display:none">\nRecord Id:' and postfix with '</div>'.
                - Example Record Id:
                    <div class="recordId" style="display:none"> 
                    Record Id:123               
                    </div>
            6. Always Suggest three relevant questions after answering the user question based on below instruction:
                - Always prefix with '<div class="suggestiveQuestions" style="display:none">\nSuggestive Questions:' and postfix with '</div>'
                - These questions should be strictly related to DMV data search and summary.
                - Always suggest questions which can be stricly answered based on above DMV data.
                - Example Suggestive Questions:
                    <div class="suggestiveQuestions" style="display:none"> 
                    Suggestive Questions:
                    - What are dependent sign of abc.
                    - What motor law abc it comes under.
                    - Do you want to see similar symbols?.
                    </div>
            7. Answer strictly in below Format:

            Formats for Responses:
            • <your response i.e. list of bullet points using relevant record>.
            <div class="recordId" style="display:none"> 
            Record Id:record_id              
            </div>
            • <your response i.e. list of bullet points using next relevant record>.
            <div class="recordId" style="display:none"> 
            Record Id:record_id            
            </div>        
            <div class="suggestiveQuestions" style="display:none">
            Suggestive Questions:
            [list_of_questions]        
            </div>

            Example of a correct response on above format:        
            • This symbol represt abc.
            • we can do with abc.
            <div class="recordId" style="display:none"> 
            Record Id:0                
            </div>
            • This symbol xyz is oppisite of abc.
            • Never try with xyz below steps.
            <div class="recordId" style="display:none"> 
            Record Id:3               
            </div>
            <div class="suggestiveQuestions" style="display:none"> 
            Suggestive Questions:
            - What are dependent sign of abc.
            - What motor law abc it comes under.
            - Do you want to see similar symbols?.
            </div>     
        """
        
        prompt_template = f"""
            System Role:
            {system_prompt}
            
            User Role:
            {user_prompt}
        """   

        
        completed_prompt = [
            {
                "role": "system",
                "content": prompt_template
            },        
            {
                "role": "user",
                "content": item.user_message
            }
        ]

        info_json_string = json.dumps(info_df)
                
        openai_stream = self.openai_service.generate_completion_stream(completed_prompt,temp=0.7)        
    
        gptresponse = ""
        if isInformationPassed:
            for event in openai_stream: #finish_reason            
                    if(len(event.choices)>0):
                        current_response = event.choices[0].delta.content
                        if current_response is not None and current_response != "":
                            gptresponse = gptresponse + current_response
                            if isInformationPassed:
                                yield "data:" +  "Custom_Information_Used_By_LLM:"+base64.b64encode(info_json_string.encode("utf-8")).decode("ascii")  + "\n\n"
                                yield "data:" +  base64.b64encode(("You: "+item.user_message+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"
                                isInformationPassed = False                        
                            
                            yield "data:" +  base64.b64encode(current_response.encode("utf-8")).decode("ascii")  + "\n\n"
        else:
            yield "data:" +  base64.b64encode(("You: "+item.user_message+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"
            yield "data:" +  base64.b64encode(("I apologize, but there is no data matching your message. Could you please provide more information or clarify your request. We recommend refining your question with additional details for more specific results."+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"
            gptresponse = "I apologize, but there is no data matching your message. Could you please provide more information or clarify your request. We recommend refining your question with additional details for more specific results."

        remaning_item_list = None
        # if len(search_results) > 0:
        #     remaning_item_list = search_results
        #     del remaning_item_list[:self.K_searcchcounter_default]
        
        if remaning_item_list is not None and "I apologize, but there is no data matching your message" not in gptresponse:
            yield "data:" +  base64.b64encode(("There may be additional information matching your query, type/click <a href='javascript:void(0)' class='element_conitnue'>Continue</a> or ask different question."+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"

        inserted_history = self.set_chat_record(item.user_message,gptresponse,remaning_item_list,info_json_string,aiquerycount,agent_count,is_agent,agent_result,item)
        yield "data:" +  "Custom_Information_Used_By_LLM_QuestionID:"+str(inserted_history.inserted_id) + "\n\n"
    
    
    
    def set_chat_record(self,userquery,gptresponse,remaning_item_list,info_json_string,aiquerycount,agent_count,is_agent,agent_result,item:ChatCompletionItem):
        history_addrecord = {
            "chatid": item.chat_id,
            "topic":"",
            "userquery": userquery,
            "gptresponse": gptresponse, 
            "user_id": item.user_id,
            "user_feedback_sentiment": "",
            "user_feedback_comment": "",   
            "info_json_string":info_json_string,           
            "applicationid": item.app_type,
            
            "insertedDate": datetime.datetime.now(datetime.UTC).strftime("%m-%d-%Y %H:%M:%S")
        }

        inserted_history = self.mongo_service.add_history(history_addrecord)

        if remaning_item_list is not None:
            session_upsertrecord = {
                "$set": {
                    "chatid": item.chat_id,            
                    "userquery":userquery,
                    "aiquerycount":aiquerycount,        
                    "agent_count":agent_count,
                    "is_agent":is_agent,
                    "agent_result": listVectorSearchContent_to_json_string(agent_result) if agent_result is not None else agent_result,
                    "records":listVectorSearchContent_to_json_string(remaning_item_list),             
                    "insertedDate": datetime.datetime.now(datetime.UTC).strftime("%m-%d-%Y %H:%M:%S"),
                    "applicationid": item.app_type
                }
            }                                   

            session_upsertedrecord = self.mongo_service.upsert_session(item.chat_id,session_upsertrecord)

        return inserted_history
    
    
    def generate_dmv_driverlicenseformresponse(self, json_dmvroute,dvmformvalue,dmvitem:DMVChatCompletionItem):

        submitstring = None
        emptyfileds = []
        if "FillForm" in json_dmvroute["UserIntent"]:
            formconfig = json.dumps(load_form_driverlicense())    
            if is_valid_dict(dvmformvalue):              
               reloadvalues = reload_form_driverlicense(formconfig,dvmformvalue)
               formconfig = reloadvalues["form"]
               emptyfileds = reloadvalues["emptyfields"]    
        elif "FillForm" in json_dmvroute["UserIntent"] or "FollowupForm" in json_dmvroute["UserIntent"]:
            sections = json.dumps({"sections": [section.dict() for section in dmvitem.sections]})
            reloadvalues = reload_form_driverlicense(sections,dvmformvalue)
            formconfig = reloadvalues["form"]
            emptyfileds = reloadvalues["emptyfields"]
        elif "SubmitForm" in json_dmvroute["UserIntent"]:
            sections = json.dumps({"sections": [section.dict() for section in dmvitem.sections]})
            reloadvalues = reload_form_driverlicense(sections,dvmformvalue)
            formconfig = reloadvalues["form"]
            emptyfileds = reloadvalues["emptyfields"]
            if len(emptyfileds) == 0 or "All required fields are filled" in dvmformvalue["Response"] or "All required fields are filled" in dvmformvalue["UpdatedFieldValues"] or "All required fields are filled" in json_dmvroute["UpdatedFieldValues"] or "All required fields are filled" in dvmformvalue["UpdatedFieldValues"] or "Your form is ready to be submitted" in dvmformvalue["Response"] or "All required fields are filled" in json_dmvroute["NextSteps"] or "Your form is ready to be submitted" in json_dmvroute["NextSteps"] :
                submitstring = "Submitted, Downloading Drive Licenses Form..." + formconfig
            else:
                submitstring = "Please fill the mandatory fields before submiting: " + ", ".join(emptyfileds)
        else:
            raise HTTPException(status_code=400, detail=f"Intent Unidentified")

        
        forvaluemessage = dvmformvalue["Response"] if is_valid_dict(dvmformvalue) else dvmformvalue
        if forvaluemessage == '':
            forvaluemessage = json_dmvroute["UserAnswer"]

        if "SubmitForm" not in json_dmvroute["UserIntent"]:
            yield "data:" +  "Custom_Information_FormConfigrationAgent:"+base64.b64encode(formconfig.encode("utf-8")).decode("ascii")  + "\n\n"
        yield "data:" +  base64.b64encode(("You: "+dmvitem.chatcompletiontitem.user_message+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"  
        if forvaluemessage and "SubmitForm" not in json_dmvroute["UserIntent"]:
            yield "data:" +  base64.b64encode((forvaluemessage+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"
        if json_dmvroute["NextSteps"] and "SubmitForm" not in json_dmvroute["UserIntent"]:
            yield "data:" +  base64.b64encode((json_dmvroute["NextSteps"]+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"   
        if len(emptyfileds) == 0 and "SubmitForm" in json_dmvroute["UserIntent"]:
            yield "data:" +  base64.b64encode((json_dmvroute["NextSteps"]+"\n\n").encode("utf-8")).decode("ascii")  + "\n\n"
        if submitstring is not None:
            yield "data:" +  base64.b64encode((submitstring+"\n\n").encode("utf-8")).decode("ascii") + "\n\n"