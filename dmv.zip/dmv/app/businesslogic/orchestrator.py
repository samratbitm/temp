import json
from app.models.models import ChatCompletionItem, DMVChatCompletionItem
from app.services.mongo_service import MongoDBService, get_mongo_service
from app.services.openai_service import OpenAIService, get_openai_service
from app.config import settings
from langchain.chains.query_constructor.base import AttributeInfo, StructuredQueryOutputParser, get_query_constructor_prompt
from app.utils.common import is_valid_json
from fastapi import Depends



class Orchestrator:
    def __init__(self, mongo_service: MongoDBService = Depends(get_mongo_service),
                 openai_service: OpenAIService = Depends(get_openai_service)):
        self.mongo_service = mongo_service
        self.openai_service = openai_service
        self.num_result_default = 500

    def self_query(self, query: str):

        metadata_field_info = [
            AttributeInfo(
                name="intent",
                description="Indetify the users top intent. One of ['bills','greeting','continue','mongodbagent','none']. Always in small case. Always intent is 'continue' if query contains value 'continueonpreviousquestion'",
                type="string",
            ),
            AttributeInfo(
                name="continueintent",
                description="Indetify the user intent, is he asking a new question or asking to continue on previous question. One of [false, true]. Default is false, always in small case.",
                type="bool",
            ),
            AttributeInfo(
                name="querytype",
                description="The user query for bill and legislation type which has intent list all/get all/more than one similar bills on legislation. One of [false, true]. Default is false, always in small case.",
                type="bool",
            ),
            AttributeInfo(
                name="category",
                description="The bill or legislation type of the session. add only if keyword ""Motor Vehicle"" is available in user query. One of ['Motor Vehicles', 'All']",
                type="string",
            ),
            AttributeInfo(
                name="year",
                description="The session year when bill or legislation was intrduced",
                type="integer",
            ),
            AttributeInfo(
                name="billstatus",
                description="The bill or legislation status. One of ['PASSED', 'INPROGRESS', 'CONTINUED']",
                type="string",
            ),
            AttributeInfo(
                name="serialnumber", 
                description="The serial number introduce in session like HB 0, hb0, Hb 000, sB 00, hb 000, SB 0000. Always return a alpha numeric upper case character with no blank space in between any character like ""SB000"". ", 
                type="string"
            ),
            AttributeInfo(
                name="house", 
                description="The house where bill or legislation was introduce for that session. One of ['House Bill(HB)', 'Senate Bill(SB)',""]", 
                type="string"
            ),
            AttributeInfo(
                name="user",
                description="The person who is Patrons of the bill. Always in small case.",
                type="string",
            ),
            AttributeInfo(
                name="usertype",
                description="The person who is Patrons or a Senator of the bill. One of ['patron', 'senator']",
                type="string",
            )
        ]
    
        examples = [        
            (
                "HB 0",
                {
                    "query": "HB0",
                    "filter": 'and(eq("serialnumber", "HB0"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "hb 0",
                {
                    "query": "HB0",
                    "filter": 'and(eq("serialnumber", "HB0"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "hb0",
                {
                    "query": "HB0",
                    "filter": 'and(eq("serialnumber", "HB0"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "HB0 2024",
                {
                    "query": "HB0",
                    "filter": 'and(eq("serialnumber", "HB0"), eq("year", 2024), eq("house", "House Bill(HB)"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "give summary about pass bills Hb 0",
                {
                    "query": "HB0",
                    "filter": 'and(eq("billstatus", "PASSED"), eq("house", "House Bill(HB)"), eq("serialnumber", "HB3"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "give details about sb 0000 current",
                {
                    "query": "SB0000",
                    "filter": 'and(eq("billstatus", "INPROGRESS"), eq("house", "Senate Bill(SB)"), eq("serialnumber", "SB0000"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "give details about sB 0000 current",
                {
                    "query": "SB0000",
                    "filter": 'and(eq("billstatus", "INPROGRESS"), eq("house", "Senate Bill(SB)"), eq("serialnumber", "SB0000"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "give details about Sb 0000 current",
                {
                    "query": "SB0000",
                    "filter": 'and(eq("billstatus", "INPROGRESS"), eq("house", "Senate Bill(SB)"), eq("serialnumber", "SB0000"), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "provide summary about Sj 000 related to hJ 000",
                {
                    "query": "SJ000 related to HJ000",
                    "filter": 'and(or(eq("serialnumber", "SJ000"),eq("serialnumber", "HJ000")), eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "please share the mondda resson bill details between 2020 and 2024",
                {
                    "query": "mondda resson",
                    "filter": 'and(gte("year", 2020), lte("year", 2024), eq("querytype",true), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "list all monoorgan bills of year 2024",
                {
                    "query": "monoorgan",
                    "filter": 'and(eq("year", 2024), eq("querytype",true), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "pleasse privide all moonday bills of year 2024",
                {
                    "query": "moonday",
                    "filter": 'and(eq("year", 2024), eq("querytype",true), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "list moon day bill which are passed on year 2024",
                {
                    "query": "moon day",
                    "filter": 'and(eq("year", 2024),  eq("billstatus", "PASSED"), eq("querytype",true), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "List license plate bill between 2022 to 2023",
                {
                    "query": "license plate",
                    "filter": 'and(gte("year", 2022), lte("year", 2023), eq("billstatus", "PASSED"), eq("querytype",true), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "provide summary/details of moon day in progress",
                {
                    "query": "moon day",
                    "filter": 'and(eq("billstatus", "INPROGRESS"), eq("querytype",true), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "list moon days bills",
                {
                    "query": "moon days",
                    "filter": 'and(eq("querytype",true), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "get first 5 of 2023 motor emissions bill",
                {
                    "query": "motor emissions",
                    "filter": 'and(eq("category", "Motor Vehicles"), eq("querytype",true), eq("year", 2023), eq("continueintent",false), eq("intent","bills"))',
                },
            ),        
            (
                "list all bills by samrat",
                {
                    "query": "samrat",
                    "filter": 'and(eq("user", "samrat"), eq("continueintent",false), eq("intent","bills"), eq("querytype",true), or(eq("usertype","Patrons"), eq("usertype", "Senator")))',
                },
            ),
            (
                "Is hb0 patron is samrat",
                {
                    "query": "samrat",
                    "filter": 'and(eq("serialnumber","HB0"), eq("user", "samrat"), eq("usertype","Patrons"),eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "What bills were sponsored by Senator Samrat in 2023",
                {
                    "query": "Samrat",
                    "filter": 'and(eq("year", "2023"), eq("user", "samrat"), eq("usertype","Senator"),eq("querytype",false), eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "Find all relative or equvalent or similar bills for HB 000",
                {
                    "query": "HB 000",
                    "filter": 'and(eq("serialnumber", "HB000"), eq("house", "Senate Bill(SB)"),eq("querytype",true), eq("continueintent",false), eq("intent","mongodbagent"))',                    
                },
            ),
            (
                "What are the equivalent bills for HB 000?",
                {
                    "query": "HB 000",
                    "filter": 'and(eq("serialnumber", "HB000"), eq("house", "Senate Bill(SB)"),eq("querytype",true), eq("continueintent",false), eq("intent","mongodbagent"))',                    
                },
            ),   
            (
                "What are the similar bills for HB 000?",
                {
                    "query": "HB 000",
                    "filter": 'and(eq("serialnumber", "HB000"), eq("house", "Senate Bill(SB)"),eq("querytype",true), eq("continueintent",false), eq("intent","mongodbagent"))',                    
                },
            ),   
            (
                "What are the relative bills for HB 000?",
                {
                    "query": "HB 000",
                    "filter": 'and(eq("serialnumber", "HB000"), eq("house", "Senate Bill(SB)"),eq("querytype",true), eq("continueintent",false), eq("intent","mongodbagent"))',                    
                },
            ),                   
            (
                "Find all relative or equvalent or similar bills for SB 000",
                {
                    "query": "SB 000",
                    "filter": 'and(eq("serialnumber", "SB000"), eq("house", "House Bill(HB)"),eq("querytype",true), eq("continueintent",false), eq("intent","mongodbagent"))',                    
                },
            ),
            (
                "Count total bills sponsored by Samrat",
                {
                    "query": "",
                    "filter": 'and(eq("user", "samrat"), eq("usertype","Patrons"),eq("querytype",false), eq("continueintent",false), eq("intent","mongodbagent"))',
                },
            ),
            (
                "Total bills by Chief Patron Samrat",
                {
                    "query": "",
                    "filter": 'and(eq("user", "samrat"), eq("usertype","Patrons"),eq("querytype",false), eq("continueintent",false), eq("intent","mongodbagent"))',
                },
            ),
            (
                "How many moon day bills were passed in the year 2024",
                {
                    "query": "moon day",
                    "filter": 'and(eq("year", 2023), eq("billstatus", "PASSED"),eq("querytype",true), eq("continueintent",false), eq("intent","mongodbagent"))',
                },
            ),
            (
                "How many bills were passed in 2021 by Samrat",
                {
                    "query": "",
                    "filter": 'and(eq("year", "2021"), eq("billstatus", "PASSED"),eq("user", "samrat"), eq("usertype","Patrons"),eq("querytype",false), eq("continueintent",false), eq("intent","mongodbagent"))',
                },
            ),        
            (
                "How many bills by Chief Patron Samrat",
                {
                    "query": "",
                    "filter": 'and(eq("user", "samrat"), eq("usertype","Patrons"),eq("querytype",false), eq("continueintent",false), eq("intent","mongodbagent"))',
                },
            ),
            (
                "Total bill passed on year 2024",
                {
                    "query": "",
                    "filter": 'and(eq("year", "2024"), eq("billstatus", "PASSED"), eq("querytype",false), eq("continueintent",false), eq("intent","mongodbagent"))',
                },
            ),
            (
                "How many bill passed on year 2024",
                {
                    "query": "",
                    "filter": 'and(eq("year", "2024"), eq("billstatus", "PASSED"), eq("querytype",false), eq("continueintent",false), eq("intent","mongodbagent"))',
                },
            ),
            (
                "get summary of moonday bills",
                {
                    "query": "moonday",
                    "filter": 'and(eq("querytype",true),eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "get information of moondays",
                {
                    "query": "moondays",
                    "filter": 'and(eq("querytype",true),eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "get moondays bill",
                {
                    "query": "moon days",
                    "filter": 'and(eq("querytype",true),eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "get privalage information about headdays bills",
                {
                    "query": "headdays",
                    "filter": 'and(eq("querytype",true),eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "driver information",
                {
                    "query": "driver information",
                    "filter": 'and(eq("querytype",true),eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "headday",
                {
                    "query": "headdays",
                    "filter": 'and(eq("querytype",true),eq("continueintent",false), eq("intent","bills"))',
                },
            ),
            (
                "List a song of 2024",
                {
                    "query": "List a song of 2024",
                    "filter": 'and(eq("querytype",false),eq("continueintent",false), eq("intent","none"))',
                },
            ),
            (
                "Hello",
                {
                    "query": "Hi",
                    "filter": 'and(eq("querytype",false),eq("continueintent",false), eq("intent","greeting"))',
                },
            ),
            (
                "nice answers",
                {
                    "query": "nice answers",
                    "filter": 'and(eq("querytype",false),eq("continueintent",false), eq("intent","greeting"))', 
                },
            ),
            (
                "bad response",
                {
                    "query": "bad response",
                    "filter": 'and(eq("querytype",false),eq("continueintent",false), eq("intent","greeting"))',
                },
            ),
            (
                "Bye",
                {
                    "query": "Bye",
                    "filter": 'and(eq("querytype",false),eq("continueintent",false), eq("intent","greeting"))',
                },
            ),
            (
                "continue on next bills",
                {
                    "query": "continue on next bills",
                    "filter": 'and(eq("querytype",false),eq("continueintent",true), eq("intent","continue"))',
                },
            ),
            (
                "Is there more detials/information",
                {
                    "query": "Is there more detials/information",
                    "filter": 'and(eq("querytype",false),eq("continueintent",true), eq("intent","continue"))',
                },
            ),
            (
                "next",
                {
                    "query": "next",
                    "filter": 'and(eq("querytype",false),eq("continueintent",true), eq("intent","continue"))',
                },
            ),
            (
                "next steps",
                {
                    "query": "next steps",
                    "filter": 'and(eq("querytype",false),eq("continueintent",true), eq("intent","continue"))',
                },
            ),
            (
                "move/go ahead",
                {
                    "query": "move/go ahead",
                    "filter": 'and(eq("querytype",false),eq("continueintent",true), eq("intent","continue"))',
                },
            ),
            (
                "yes, continue",
                {
                    "query": "yes, continue",
                    "filter": 'and(eq("querytype",false),eq("continueintent",true), eq("intent","continue"))',
                },
            )
        ]

        document_content_description = "Brief summary/details of a bill or legistation with its historical events, title, year, patron, serialnumber."

        prompt = get_query_constructor_prompt(
                document_content_description,
                metadata_field_info,
                examples=examples,
            )

        output_parser = StructuredQueryOutputParser.from_components()

        structured_query = self.openai_service.generate_langchain_selfquery(query,prompt,output_parser)
        return structured_query

    def reformulate_query(self,item:ChatCompletionItem):
        reformulated_query = item.user_message
        chat_historys = self.chat_historys(item.chat_id)
        chat_history = []
        if len(chat_historys)> 0:
                for chatrecord in chat_historys:
                    chat_history.append({"role": "user", "content": chatrecord["userquery"]})
                    chat_history.append({"role": "assistant", "content": chatrecord["gptresponse"]})               
                        
                try:   
                    current_user_question = item.user_message

                    # Create prompt
                    prompt_template = """
                    ### Instructions
                    You are an assistant who accurately and helpfully Reformulate user questions based on the chat history provided. Follow these instructions strictly:
                    1. Always strictly pass the question as-is as a standalone question based on below instruction:
                    - If the user request is an initial question (no previous context), pass the question as-is as a standalone question.
                    - If the user request does not relate to any chat history, pass the question as-is as a standalone question.
                    - If the user request is related to dmv license form make sure to reformulate question for dmv license form.
                    2. If a follow-up question matches or references previous chat history:
                    - Check if it relates to a previous question/answer pair.
                    - If yes, reformulate it into a standalone question including the relevant context.
                    - If no, consider it a new question and pass it as-is as a standalone question.
                    3. If the follow-up question indicates continuation intent on last assisstant response i.e. "There may be more information matching your query shall i Continue. you can ask different query if information you need is provided." (with phrases like "Yes, please," "Continue," "Tell me more," "Go on," etc.), and the last assistant response ends with "Do you want me to Continue?":
                    - Reformulate it using the last user question with the prefix "continueonpreviousquestion, "
                    - Provide the reformulated standalone question.
                    4. Never answer as user questions.
                    5. Never include extra explanations or commentary.
                    6. Standalone questions should contain all necessary context for the assistant to answer.

                    ### Chat History
                    {chat_history}

                    ### Example Execution
                    ```plaintext
                    User: What is Azure Cosmos DB?
                    Assistant: Azure Cosmos DB is a fully managed NoSQL database service provided by Microsoft for modern app development.

                    User: How can I use it for data retrieval?
                    Assistant Reformulated: How can I use Azure Cosmos DB for data retrieval?
                    Assistant: You can use Azure Cosmos DB for data retrieval by leveraging its multiple APIs, including SQL API, MongoDB API, and Cassandra API.

                    User: What is a traffic manager in Azure?
                    Assistant: Azure Traffic Manager is a DNS-based traffic load balancer that distributes traffic optimally to services across global Azure regions.
                    There may be more information matching your query shall i Continue. you can ask different query if information you need is provided.

                    User: Yes, please.               
                    Assistant: continueonpreviousquestion: How can I use Azure Traffic Manager with multi-region databases?
                    
                    ### Instructions
                    Use the chat history provided to Reformulate the user's follow-up questions. Reformulate the questions according to the instructions.

                    User: {current_user_question}                
                    """

                    chat_history_str = "\n".join([f"{entry['role']}: {entry['content']}" for entry in chat_history])
                    prompt = prompt_template.format(
                        chat_history=chat_history_str,
                        current_user_question=current_user_question,
                        reformulated_question="",
                        answer=""
                    )

                    messages=[
                        {"role": "system", "content": prompt},
                        {"role": "user", "content": current_user_question},
                    ]    

                    reformulated_query = self.openai_service.reformulate_query(messages)

                except Exception as err:
                    print(err) 
                    reformulated_query = item.user_message                  
        
        return reformulated_query
    
    def search_dmv(self,query,item:DMVChatCompletionItem):
    
        query_embedding = self.openai_service.generate_embeddings(query)
        filterJson = None
        if filterJson is not None: 
            search = {
                '$search': {
                    "cosmosSearch": {                    
                            "vector": query_embedding,
                            "path": "contentVector",
                            "k": 50, #, "efsearch": 40 # optional for HNSW only  
                            "filter" :  filterJson                     
                        },
                    "returnStoredSource": True
                }
            }
        else:
            search = {
                '$search': {
                    "cosmosSearch": {                    
                            "vector": query_embedding,
                            "path": "contentVector",
                            "k": 50 #, "efsearch": 40 # optional for HNSW only 
                        },
                    "returnStoredSource": True
                }
            }
        
        vectorpipeline = [
            search
            ,
            {
                '$project':{ 
                    'similarityScore':{ 
                            '$meta': 'searchScore' 
                        }, 
                    'document' : '$$ROOT'                     
                } 
            },
            {
                '$set':{
                    'similarityScore': '$similarityScore',                
                    'page_content':'$document.page_content',
                    'metadata': '$document.metadata',
                    'page': '$document.page',
                    'para': '$document.para',                               
                }
            },
            {
                '$sort' :{
                    'similarityScore' : -1               
                }
            }            
            
        ]
        
        result = self.mongo_service.fetch_dmv_pipeline(vectorpipeline)

        return result
    
    def dvmroute_identification(self,reformulated_usermessge,dmvitem:DMVChatCompletionItem):
        
        dvmroute = ""
        try:
            
            #infuture fill these fields dynamically from item fileds
            filled_fields = {
                'name': 'N/A',
                'birthdate': 'N/A',
                'phone_number': 'N/A',
                'sex': 'N/A',
                'weight': '',
                'height': '',
                'eye_color': 'N/A',
                'hair_color': 'N/A',
                'street_address': 'N/A',
                'city': 'N/A',
                'state': 'N/A',
                'zip_code': 'N/A',
                'mailing_address': 'N/A'
                                }
            
            if dmvitem.sections is not None:
                for section in dmvitem.sections:
                        for field in section.fields:
                            filled_fields[field.name] = field.value if field.value else 'N/A'

            prompt_template = f"""
                You are an AI assistant. The user has been interacting with you to fill out a driver's license form. You have the following partially filled fields:

                Fields:
                1. Full Legal Name: {filled_fields['name']}
                2. Birthdate: {filled_fields['birthdate']}
                3. Phone Number: {filled_fields['phone_number']}
                4. Sex: {filled_fields['sex']}
                5. Weight (number in lbs): {filled_fields['weight']}
                6. Height (number in inch): {filled_fields['height']}
                7. Eye Color: {filled_fields['eye_color']}
                8. Hair Color: {filled_fields['hair_color']}
                9. Street Address: {filled_fields['street_address']}
                10. City: {filled_fields['city']}
                11. State: {filled_fields['state']}
                12. ZIP Code: {filled_fields['zip_code']}
                13. Mailing Address: {filled_fields['mailing_address']}
                
                Your task is to:
                1. Identify user intent, chose any one intent ["NonForm","FillForm","FollowupForm","SubmitForm"] from below user action:
                - Asking a general question not related to the form i.e. "NonForm" intent.
                - Requesting to fill the driver's license form i.e. "FillForm" intent.
                - Asking a question related to a specific field in the form i.e. "FollowupForm" intent.
                - Providing a value to update a specific field i.e. "FollowupForm" intent.
                - Asking to submit the completed form, i.e. "SubmitForm" intent.
                2. If the user is providing a value for a specific field, update that field.
                3. If the user is asking a question related to the form or fields, provide a clear and concise answer.
                4. User can provide Birthdate/DOB in any date format but always conver it to yyyy-mm-dd  for Birthdate filed, if you cannot convert ask user for corrent format.
                5. If all required fields are filled then always response with ""All required fields are filled"".
                6. If the user intends to submit the form, check that all required fields are filled. 
                7. If full legal name is not provided, still consider it for Full Legal Name filed.    
                8. User can provide Weight in any units of weight but always conver it to Pound (lbs) number for Weight filed like 10kg = 22, if you cannot convert ask user for corrent format.    
                9. User can provide Height in any units of length but always conver it to Inch (in) number for Height filed like 6 feet = 72, if you cannot convert ask user for corrent format.        

                Always respond in below JSON format:
                {{
                    "UserIntent": "User's intent",
                    "UpdatedFieldValues": "Any updated field values (if applicable)",
                    "UserAnswer": "Answer to the user's question (if applicable)",
                    "NextSteps": "Next steps for the user"
                }}
                """
            
            #just in case format of prompt template needed to get formatted answers
            prompt = prompt_template

            messages=[
                {"role": "system", "content": prompt},
                {"role": "user", "content": reformulated_usermessge},
            ]    

            response = self.openai_service.generate_dvm(messages)
            dvmroute = json.loads(response.replace("json","").replace("```","").replace("\n",""))
                
        except Exception as err:
            print(err)  
            dvmroute =""                          
        
        return dvmroute
    
    def dmvformvalue_identification(self,reformulated_usermessge,dmvitem:DMVChatCompletionItem):
        
        dvmformvalue = ""
        try:
                      
            #infuture fill these fields dynamically from item fileds
            filled_fields = {
                'name': 'N/A',
                'birthdate': 'N/A',
                'phone_number': 'N/A',
                'sex': 'N/A',
                'weight': '',
                'height':'',
                'eye_color': 'N/A',
                'hair_color': 'N/A',
                'street_address': 'N/A',
                'city': 'N/A',
                'state': 'N/A',
                'zip_code': 'N/A',
                'mailing_address': 'N/A'
            }
            
            if dmvitem.sections is not None:
                for section in dmvitem.sections:
                    for field in section.fields:
                        filled_fields[field.name] = field.value if field.value else 'N/A'

            value_identification_prompt = f"""
                    You are an AI assistant helping a user fill out a driver's license form. You have the following partially filled fields:

                    Fields:
                    1. Full Legal Name: {filled_fields['name']}
                    2. Birthdate: {filled_fields['birthdate']}
                    3. Phone Number: {filled_fields['phone_number']}
                    4. Sex: {filled_fields['sex']}
                    5. Weight (number in lbs): {filled_fields['weight']}
                    6. Height (number in inch): {filled_fields['height']}
                    7. Eye Color: {filled_fields['eye_color']}
                    8. Hair Color: {filled_fields['hair_color']}
                    9. Street Address: {filled_fields['street_address']}
                    10. City: {filled_fields['city']}
                    11. State: {filled_fields['state']}
                    12. ZIP Code: {filled_fields['zip_code']}
                    13. Mailing Address: {filled_fields['mailing_address']}                    

                    Your task is to:
                    1. Identify if the user is providing a value for a specific field.
                       - If full legal name is not provided, still consider it for Full Legal Name filed.
                    2. Extract the value and update the relevant field.
                    3. If the user is asking a question about a field, provide a clear and concise answer.  
                    4. User can provide Birthdate/DOB in any date format but always conver it to yyyy-mm-dd  for Birthdate filed, if you cannot convert ask user for corrent format.
                    5. Filed Weight, Height is mandatory, an approximate weight can be provided but we cannot move on to the next field if any filed is mandatory.
                    6. If all required fields are filled then always response with ""All required fields are filled"".
                    7. User can provide Weight in any units of weight but always conver it to Pound (lbs) for Weight filed, if you cannot convert ask user for corrent format.    
                    8. User can provide Height in any units of length but always conver it to Inch (in) for Height filed, if you cannot convert ask user for corrent format.
                    9. Alwasy respond in below JSON format:
                    {{                        
                        "UpdatedFieldValues": "Extract the value and update the relevant field (if applicable)",
                        "Response": "If the user is asking a question about a field, provide a clear and concise answer (if applicable)",                        
                    }}
                    """

            messages=[
                {"role": "system", "content": value_identification_prompt},
                {"role": "user", "content": reformulated_usermessge},
            ]    

            response = self.openai_service.generate_dvm(messages)
            response = response.replace("json","").replace("```","").replace("\n","")
            if is_valid_json(response):
               dvmformvalue = json.loads(response)            
                
        except Exception as err:
            print(err)
            dvmformvalue = ""                            
        
        return dvmformvalue



    def chat_historys(self, chat_id):
        return self.mongo_service.fetch_chathistory(chat_id)
    

    