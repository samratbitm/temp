from fastapi import APIRouter, HTTPException
from fastapi.params import Depends
from app.models.models import FeedbackRatingItem
from app.middlewares import jwt_bearer
from app.services.mongo_service import MongoDBService


router = APIRouter()

@router.get("/")
def read_root():
    return {"Message": "Feedback Copilot API running..."}


@router.post("/rating", dependencies=[Depends(jwt_bearer)])
def chatfeedbackrating(item: FeedbackRatingItem, mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.update_rating(item)
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")