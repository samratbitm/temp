import json
import os
from app.businesslogic.suggestivequestion import SuggestiveQuestion
from fastapi import APIRouter, HTTPException, Response
from fastapi.params import Depends
from app.models.models import HistorySessionItem
from app.middlewares import jwt_bearer
from app.services.mongo_service import MongoDBService
from app.utils.common import exporthistory_pdf

router = APIRouter()


@router.get("/")
def read_root():
    return {"Message": "History Copilot API running..."}

@router.post("/setsession", dependencies=[Depends(jwt_bearer)])
def chathistorysetsession(item: HistorySessionItem, mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.history_setsession(item)
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")

@router.post("/getsession", dependencies=[Depends(jwt_bearer)])
def chathistorygetsession(item: HistorySessionItem, mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.history_getsession(item)
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")

@router.post("/all", dependencies=[Depends(jwt_bearer)])
def chathistorylist(item: HistorySessionItem, mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.history_getall(item)
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")

@router.post("/delete", dependencies=[Depends(jwt_bearer)])
def chathistorydelete(item: HistorySessionItem, mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.history_delete(item)
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")

@router.post("/suggestivequestion", dependencies=[Depends(jwt_bearer)])
def getsuggestivequestion(item: HistorySessionItem, suggestive_question: SuggestiveQuestion = Depends()):
    try:
        results = suggestive_question.generate_suggestivequestion(item)
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")

@router.post("/export", dependencies=[Depends(jwt_bearer)])
def chathistoryexport(item: HistorySessionItem, mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.history_getsession(item)        
        data = json.loads(results)
        if len(data) > 0:
            topic = data[0]["topic"]

        pdf_content = exporthistory_pdf(results,os.path.join("app/images", "TexLogoLight.png"),topic)
        return Response(content=pdf_content, media_type="application/pdf", headers={
            "Content-Disposition": f'attachment; filename="{topic}.pdf"' })
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")
    
    
    
