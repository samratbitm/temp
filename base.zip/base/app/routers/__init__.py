from fastapi import APIRouter
from app.routers import feedback_route, app_route, history_route

router = APIRouter()

@router.get("/")
def read_root():
    return {"Message": "GenAI Copilot base APIs running..."}

router.include_router(app_route.router, prefix="/app", tags=["app"])
router.include_router(feedback_route.router, prefix="/feedback", tags=["feedback"])
router.include_router(history_route.router, prefix="/history", tags=["history"])
