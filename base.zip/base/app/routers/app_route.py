from fastapi import APIRouter, HTTPException
from fastapi.params import Depends
from app.models.models import CardSessionItem, FeedbackRatingItem
from app.middlewares import jwt_bearer
from app.services.mongo_service import MongoDBService

router = APIRouter()

@router.get("/")
def read_root():
    return {"Message": "Pilot GenAI Copilot APIs running..."}

@router.post("/cards", dependencies=[Depends(jwt_bearer)])
def getcards(item: CardSessionItem, mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.card_loaddefaultquestions(item)
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")

@router.get("/faq/all", dependencies=[Depends(jwt_bearer)])
def getallfaqs(mongo_service: MongoDBService = Depends()):
    try:
        results = mongo_service.listallfaqs()
        return {"output": results}
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Invalid input data: {str(e)}")
