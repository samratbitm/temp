from app.models.models import Settings
import os

def get_settings():
    env = os.getenv("ENV", "dev")
    if env.lower() == "prod":
        return Settings(_env_file=".env.prod")
    elif env.lower() == "client":
        return Settings(_env_file=".env.client")
    elif env.lower() == "uat":
        return Settings(_env_file=".env.uat")
    
    return Settings(_env_file=".env.dev")

settings = get_settings()
