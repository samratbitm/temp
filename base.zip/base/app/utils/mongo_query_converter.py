from enum import Enum
from typing import Any, List, Union, Dict, Optional

class Operator(Enum):
    AND = 'and'
    OR = 'or'

class Comparator(Enum):
    EQ = 'eq'
    NE = 'ne'
    LT = 'lt'
    LTE = 'lte'
    GT = 'gt'
    GTE = 'gte'

class Comparison:
    def __init__(self, comparator: Comparator, attribute: str, value: Any):
        self.comparator = comparator
        self.attribute = attribute
        self.value = value

    def to_mongo_query(self, attributes: Optional[List[str]] = None, isvector = False) -> Dict[str, Any]:
        if attributes and self.attribute not in attributes:
            return {}
        comparator_mapping = {
            Comparator.EQ: "$eq",
            Comparator.NE: "$ne",
            Comparator.LT: "$lt",
            Comparator.LTE: "$lte",
            Comparator.GT: "$gt",
            Comparator.GTE: "$gte"
        }

        if self.comparator not in comparator_mapping:
            raise ValueError(f"Unsupported comparator: {self.comparator}")
        
        query = {self.attribute: {comparator_mapping[self.comparator]: self.value}}
        if self.attribute == "year" and not isvector:           
            query =  {"$expr": {  comparator_mapping[self.comparator]: [{ "$toInt": "$"+self.attribute }, int(self.value)] }}

        return query

    def to_custom_string(self, attributes: Optional[List[str]] = None) -> str:
        if attributes and self.attribute not in attributes:
            return ""
        if self.comparator == Comparator.NE:
            return f"-\\{self.attribute}: {self.value}\\"
        else:
            return f"\\{self.attribute}: {self.value}\\"

    def __repr__(self):
        return f"Comparison(comparator={self.comparator}, attribute='{self.attribute}', value={self.value})"


class Operation:
    def __init__(self, operator: Operator, arguments: List[Union[Comparison, 'Operation']]):
        self.operator = operator
        self.arguments = arguments

    def to_mongo_query(self, attributes: Optional[List[str]] = None, isvector = False) -> Dict[str, Any]:
        operator_mapping = {
            Operator.AND: "$and",
            Operator.OR: "$or"
        }
        if self.operator not in operator_mapping:
            raise ValueError(f"Unsupported operator: {self.operator}")
        sub_queries = [arg.to_mongo_query(attributes,isvector) for arg in self.arguments if arg.to_mongo_query(attributes,isvector)]
        if not sub_queries:
            return {}
        return {operator_mapping[self.operator]: sub_queries}

    def to_custom_string(self, attributes: Optional[List[str]] = None, user_value: Optional[str] = None) -> str:
        parts = []
        user_assigned = user_value is not None
        for arg in self.arguments:
            if isinstance(arg, Comparison) and arg.attribute == 'usertype' and user_value:
                if arg.comparator == Comparator.NE:
                    parts.append(f"-\\{arg.value}: {user_value}\\")
                else:
                    parts.append(f"\\{arg.value}: {user_value}\\")
            else:
                part = arg.to_custom_string(attributes)
                if isinstance(arg, Comparison) and arg.attribute == 'user' and not user_assigned:
                    user_value = arg.value
                    user_assigned = True
                parts.append(part)

        if user_value and not any(p.startswith('\\Patrons') or p.startswith('\\Senator') or p.startswith('-\\Senator') for p in parts):
            parts = [f"\\{user_value}\\" if p.startswith(f"\\{user_value}") else p for p in parts]

        return ' '.join([part for part in parts if part])    
    

    def __repr__(self):
        return f"Operation(operator={self.operator}, arguments={self.arguments})"


# Function to convert string to Operation object
def parse_comparison(comparison_str: str) -> Comparison:
    parts = comparison_str.strip().split(',')
    comparator_str = parts[0].split('=')[1].strip().split('>')[0].split(':')[1].strip().strip("'")
    comparator = Comparator(comparator_str)
    attribute = parts[1].split('=')[1].strip().strip("'")
    value_str = parts[2].split('=')[1].strip().strip(')').strip("'").strip("'")

    # Convert value to appropriate type
    if value_str.lower() == 'true':
        value = True
    elif value_str.lower() == 'false':
        value = False
    elif value_str.startswith("'") and value_str.endswith("'"):
        value = value_str.strip("'")
    else:
        # try:
        #     value = int(value_str)
        # except ValueError:
        #     try:
        #         value = float(value_str)
        #     except ValueError:
        value = value_str

    return Comparison(comparator=comparator, attribute=attribute, value=value)


def parse_operation(operation_str: str) -> Operation:
    operator_str = operation_str.split('operator=<')[1].split('>')[0].split(':')[1].strip().strip("'")
    operator = Operator(operator_str)

    args_str = operation_str.split('arguments=[')[1].rstrip('])')
    args_list = []
    arg_strs = [arg.strip() for arg in args_str.split('Comparison(') if arg]

    for arg_str in arg_strs:
        if arg_str.startswith('operator=<'):
            nested_operation = 'Operation(' + arg_str
            args_list.append(parse_operation(nested_operation))
        else:
            args_list.append(parse_comparison(arg_str.rstrip('])')))

    return Operation(operator=operator, arguments=args_list)


# selected_attributes = ['serialnumber', 'year','billstatus']
# operation_str = """operator=<Operator.AND: 'and'>, arguments=[Comparison(comparator=<Comparator.EQ: 'eq'>, attribute='category', value='Motor Vehicles'), Comparison(comparator=<Comparator.GTE: 'gte'>, attribute='year', value=2022), Comparison(comparator=<Comparator.LTE: 'lte'>, attribute='year', value=2023), Comparison(comparator=<Comparator.EQ: 'eq'>, attribute='querytype', value=True), Comparison(comparator=<Comparator.EQ: 'eq'>, attribute='continueintent', value=False), Comparison(comparator=<Comparator.EQ: 'eq'>, attribute='intent', value='bills')]"""
# operation_obj = parse_operation("Operation("+operation_str+")")
# filter = operation_obj.to_mongo_query(attributes=selected_attributes)
# print(filter)
# selected_attributes = ['serialnumber', 'year', 'user', 'usertype','billstatus']            
# filter = operation_obj.to_custom_string(attributes=selected_attributes)
# print(filter)