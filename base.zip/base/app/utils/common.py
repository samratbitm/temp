import json
import base64
from bson import ObjectId
from typing import List, Optional
from fastapi import HTTPException
from fpdf import FPDF
from app.models.models import Section
from app.config import settings
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from PIL import Image
import re
import json
from io import BytesIO
from reportlab.lib.utils import ImageReader, simpleSplit
from reportlab.lib.colors import white
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from PIL import Image, ImageDraw
import re
import json
from io import BytesIO
from reportlab.lib.utils import simpleSplit
import uuid



class JSONEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, ObjectId):
            return str(o)
        return json.JSONEncoder.default(self, o)



def create_pdf(sections: List[Section]) -> bytes:
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)
    
    for section in sections:
        pdf.cell(200, 10, txt=section.title, ln=True, align='C')
        pdf.ln(10)  # Add some vertical space
        for field in section.fields:
            if field.value:
                field_text = f"{field.label}: {field.value}"
            else:
                field_text = f"{field.label}: [Not Provided]"
            pdf.cell(200, 10, txt=field_text, ln=True)
        pdf.ln(10)  # Add some vertical space after each section
    
    # Output PDF to a bytes object
    pdf_buffer = pdf.output(dest='S').encode('latin1')  # Using 'S' returns a string
    
    return pdf_buffer


# def remove_record_id(text):
#     return re.sub(r"Record Id:\s*\d+", "", text).strip()

# def exporthistory_pdf(json_data, image_file_name, topic,image_topic_gap=60) -> bytes:
#     data = json.loads(json_data)
    
#     # Create a bytes buffer for the PDF
#     buffer = BytesIO()
#     c = canvas.Canvas(buffer, pagesize=letter)
#     width, height = letter

#     # Process the image to add a white background if it has transparency
#     with Image.open(image_file_name) as img:
#         if img.mode in ("RGBA", "LA") or ("transparency" in img.info):  # Check for transparency
#             # Create a white background image
#             background = Image.new("RGB", img.size, (255, 255, 255))
#             background.paste(img, mask=img.split()[3])  # Paste the image with alpha channel as mask
#             processed_image_path = image_file_name.replace(".png", "_processed.png")
#             background.save(processed_image_path, "PNG")
#             image_file_name = processed_image_path
#         img_width, img_height = img.size
#         aspect_ratio = img_height / img_width
#         image_height = width * aspect_ratio

#      # Add header image
#     c.drawImage(image_file_name, 0, height - image_height, width=width, height=image_height)

#     # Add topic below the image with adjustable gap
#     c.setFont("Helvetica-Bold", 14)
#     c.drawString(20, height - image_height - image_topic_gap, topic)

#     # Y-position tracker below the topic
#     y = height - image_height - image_topic_gap - 30

#     # Function to clean HTML tags from strings
#     def clean_html(raw_html):
#         clean_text = re.sub('<.*?>', '', raw_html)
#         clean_text = re.sub(r'Suggestive Questions:.*', '', clean_text, flags=re.DOTALL)
#         clean_text = re.sub(r'\n\s*\n', '\n', clean_text).strip()
#         return clean_text

#     def replace_non_latin1(text):
#         replacements = {
#             '’': "'",
#             '“': '"',
#             '”': '"',
#             '–': '-',
#             '—': '-',
#             '…': '...',
#             '•': '-',
#         }
#         for original, replacement in replacements.items():
#             text = text.replace(original, replacement)
#         return text.encode('latin-1', 'ignore').decode('latin-1')

#     for item in data:
#         user_query = replace_non_latin1(clean_html(item["userquery"]))
#         assistance_response = replace_non_latin1(clean_html(remove_record_id(item["gptresponse"])))

#         # Check if there's enough space, add a new page if needed
#         if y < 100:
#             c.showPage()
#             c.setFont("Helvetica", 10)
#             y = height - 50

#         # Add User Query
#         c.setFont("Helvetica-Bold", 10)
#         c.drawString(20, y, "User Query:")
#         y -= 15
#         c.setFont("Helvetica", 10)
#         for line in simpleSplit(user_query, "Helvetica", 10, width - 40):
#             c.drawString(40, y, line)
#             y -= 12

#         # Add Assistance Response
#         c.setFont("Helvetica-Bold", 10)
#         c.drawString(20, y, "Assistance Response:")
#         y -= 15
#         c.setFont("Helvetica", 10)
#         for line in simpleSplit(assistance_response, "Helvetica", 10, width - 40):
#             c.drawString(40, y, line)
#             y -= 12

#         # Add spacing between entries
#         y -= 20

#     # Save the PDF to the buffer
#     c.save()
#     buffer.seek(0)

#     # Return the PDF content as bytes
#     return buffer.getvalue()

def remove_record_id(text):
    return re.sub(r"Record Id:\s*\d+", "", text).strip()

def replace_record_id_with_image(gptresponse, info_json):
    
    if isinstance(info_json, str):
        try:
            info_data = json.loads(info_json)
        except json.JSONDecodeError as e:
            raise ValueError("Invalid JSON data") from e
    else:
        info_data = info_json  # Assume already parsed

    # Validate data structure
    if not isinstance(info_data, list):
        raise ValueError("Parsed data is not a list of dictionaries")
    
    info_dict = {str(item['id']): item['image_htlm'] for item in info_data}
    
    def replace_callback(match):
        record_id = match.group(0).split(":")[-1].strip()
        return info_dict.get(record_id, "")

    return re.sub(r"Record Id:\s*\d+", replace_callback, gptresponse)

def process_and_draw_content(gptresponse_with_images, canvas, x, y, text_width, width, max_height):
    """
    Processes gptresponse_with_images to draw text and images in order.
    :param gptresponse_with_images: The string containing text and HTML with base64 images.
    :param canvas: ReportLab canvas object.
    :param x: X-coordinate for placement.
    :param y: Current Y-coordinate for placement.
    :param width: Width for images.
    :param max_height: Maximum height for images.
    :return: Updated Y-coordinate after processing the content.
    """
    page_height = letter[1]  # PDF page height
    margin = 50  # Bottom margin
    content_parts = re.split(r"(<img[^>]*src=['\"]data:image/[\w\W]+?;base64,.*?['\"][^>]*?>)", gptresponse_with_images)

    for part in content_parts:
        if part.startswith("<img"):
            # Extract base64 image data
            match = re.search(r"data:image/[\w\W]+?;base64,([^'\"]+)", part)
            if match:
                base64_data = match.group(1)
                image_data = base64.b64decode(base64_data)

                # Decode and draw the image
                with Image.open(BytesIO(image_data)) as img:
                    aspect_ratio = img.height / img.width
                    if img.width > width:
                        height = width * aspect_ratio
                    else:
                        width = img.width
                        height = img.height

                    if height > max_height:
                        height = max_height
                        width = height / aspect_ratio

                    # Check for page overflow
                    if y - height - 20 < margin:
                        canvas.showPage()  # Start a new page
                        canvas.setFont("Helvetica", 10)
                        y = page_height - 50  # Reset y position

                    # Save image to in-memory buffer
                    img_buffer = BytesIO()
                    img.save(img_buffer, format="PNG")
                    img_buffer.seek(0)

                    # Draw the image directly from memory
                    canvas.drawImage(ImageReader(img_buffer), x, y - height, width=width, height=height)
                    y -= height + 20  # Adjust y position after drawing

        else:
            # Treat as text, clean HTML, and draw
            text = clean_html(part)
            canvas.setFont("Helvetica", 10)
            for line in simpleSplit(text, "Helvetica", 10, text_width - 40):
                if y - 12 < margin:  # Check if the next line will overflow
                    canvas.showPage()  # Start a new page
                    canvas.setFont("Helvetica", 10)  # Reset font
                    y = page_height - 50  # Reset y position to top of the new page
                canvas.drawString(x, y, line)
                y -= 12

    return y


# Function to clean HTML tags from strings
def clean_html(raw_html):
    clean_text = re.sub(r'<img[^>]*>', '', raw_html)  # Remove <img> tags specifically
    clean_text = re.sub(r'<br\s*/?>', '\n', clean_text)  # Replace <br> with a newline
    clean_text = re.sub(r'<.*?>', '', clean_text)  # Remove remaining HTML tags
    clean_text = re.sub(r'Suggestive Questions:.*', '', clean_text, flags=re.DOTALL)  # Remove specific sections
    clean_text = re.sub(r'\n\s*\n', '\n', clean_text).strip()  # Remove extra newlines
    return clean_text

def replace_non_latin1(text):
    replacements = {
        '’': "'",
        '“': '"',
        '”': '"',
        '–': '-',
        '—': '-',
        '…': '...',
        '•': '-',
    }
    for original, replacement in replacements.items():
        text = text.replace(original, replacement)
    return text.encode('latin-1', 'ignore').decode('latin-1')

def exporthistory_pdf(json_data, image_file_name, topic, image_topic_gap=60) -> bytes:
    data = json.loads(json_data)

    # Create a bytes buffer for the PDF
    buffer = BytesIO()
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter

    # Process the image to add a white background if it has transparency
    # Replace this block
    with Image.open(image_file_name) as img:
        if img.mode in ("RGBA", "LA") or ("transparency" in img.info):
            # Create a white background image
            background = Image.new("RGB", img.size, (255, 255, 255))
            background.paste(img, mask=img.split()[3])  # Paste the image with alpha channel as mask

            # Save processed image to an in-memory buffer
            img_buffer = BytesIO()
            background.save(img_buffer, format="PNG")
            img_buffer.seek(0)  # Reset buffer position to the beginning
            image_file_name = img_buffer  # Use the buffer instead of a file path

        img_width, img_height = img.size
        aspect_ratio = img_height / img_width
        image_height = width * aspect_ratio

    # Add header image
    c.drawImage(ImageReader(image_file_name), 0, height - image_height, width=width, height=image_height)

    # Add topic below the image with adjustable gap
    c.setFont("Helvetica-Bold", 14)
    c.drawString(20, height - image_height - image_topic_gap, topic)

    # Y-position tracker below the topic
    y = height - image_height - image_topic_gap - 30    

    for item in data:
        # Add User Query
        user_query = replace_non_latin1(clean_html(item["userquery"]))
        c.setFont("Helvetica-Bold", 10)
        c.drawString(20, y, "User Query:")
        y -= 15
        c.setFont("Helvetica", 10)
        for line in simpleSplit(user_query, "Helvetica", 10, width - 40):
            c.drawString(40, y, line)
            y -= 12

        # Replace Record Id with corresponding image HTML and process the content
        appid = item["applicationid"]
        if appid in ["dmv","vdotspec"]:
            gptresponse_with_images = replace_record_id_with_image(replace_non_latin1(clean_html(item["gptresponse"])), item["info_json_string"])
        else:
            gptresponse_with_images = replace_non_latin1(clean_html(item["gptresponse"]))

        # Process Assistance Response text and images in sequence
        c.setFont("Helvetica-Bold", 10)
        c.drawString(20, y, "Assistance Response:")
        y -= 15
        y = process_and_draw_content(gptresponse_with_images, c, x=20, y=y, text_width=540, width=400, max_height=300)

        # Add spacing between entries
        y -= 20

        # Check if there's enough space, add a new page if needed
        if y < 100:
            c.showPage()
            c.setFont("Helvetica", 10)
            y = height - 50

    # Save the PDF to the buffer
    c.save()
    buffer.seek(0)

    # Return the PDF content as bytes
    return buffer.getvalue()

def is_valid_json(json_string):
    try:
        json.loads(json_string)
        return True
    except ValueError as e:
        return False
    
def is_valid_dict(obj):
    return isinstance(obj, dict)