import openai
import pymongo
from bson import ObjectId
from app.config import settings
from app.models.models  import FeedbackRatingItem, HistorySessionItem, CardSessionItem
from app.utils.common import JSONEncoder
from app.services.openai_service import OpenAIService, get_openai_service
from fastapi import Depends
import urllib.parse

class MongoDBService:
    def __init__(self, openai_service: OpenAIService = Depends(get_openai_service)):
        self.user = urllib.parse.quote_plus(settings.COSMOS_MONGO_USER)                                            
        self.password = urllib.parse.quote_plus(settings.COSMOS_MONGO_PWD)
        mongo_conn = f"mongodb+srv://{self.user}:{self.password}@{settings.COSMOS_MONGO_SERVER}?tls=true&authMechanism=SCRAM-SHA-256&retrywrites=false&maxIdleTimeMS=120000"
        self.client = pymongo.MongoClient(mongo_conn)
        self.db = self.client[settings.DB]
        self.openai_service = openai_service

    def update_rating(self, item: FeedbackRatingItem):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        collection.update_one({"_id": ObjectId(item.question_id)}, {"$set": {"user_feedback_sentiment": item.user_sentiment, "user_feedback_comment": item.user_comment}})
        return "updated successfully"
    
    def history_getsession(self, item: HistorySessionItem):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        chathistoryrecords = list(collection.find({"chatid": item.chat_id}).sort({"insertedDate": 1}))
        return JSONEncoder().encode(chathistoryrecords)

    def history_getall(self, item: HistorySessionItem):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        chathistoryrecords = list(collection.find({"user_id": item.user_id,"applicationid":item.app_type},{"info_json_string": 0 }).sort({"insertedDate": -1}))
        chathistorylists = []
        ids = []
        for record in chathistoryrecords:
            if str(record["chatid"]) not in ids:
                chathistorylists.append(record)
                ids.append(str(record["chatid"]))
        return JSONEncoder().encode(chathistorylists)

    def history_setsession(self, item: HistorySessionItem):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        chathistoryrecord = list(collection.find({"chatid": item.chat_id}))
        topic = ""
        chatHistory = ""
        if chathistoryrecord:
            for chatrecord in chathistoryrecord:
                chatHistory += f"User:{chatrecord['userquery']}\n Assistant:{chatrecord['gptresponse']}\n"
            system_prompt = f"""You are a chat Summarization bot. Summarize the following chat history in maximum 5 words, focusing on the topic. chat history:{chatHistory}"""
            messages = [{"role": "system", "content": system_prompt}, {"role": "user", "content": "consolidated all chat history and summarize the consolidated chat history in meaningful topic within maximum 5 words."}]
            #client = openai.AzureOpenAI(azure_endpoint=settings.AZURE_OPENAI_ENDPOINT, azure_deployment="gpt-35-turbo-16k", api_version="2023-12-01-preview", api_key=settings.AZURE_OPENAI_KEY)
            #response = client.chat.completions.create(model="gpt-35-turbo-16k", messages=messages, temperature=0)
            #topic = response.choices[0].message.content
            topic = self.openai_service.reformulate_query(messages)
            collection.update_many({"chatid": item.chat_id}, {"$set": {"topic": topic}})
        return {"chatid": item.chat_id, "topic": topic}

    def history_delete(self, item: HistorySessionItem):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        collection.delete_many({"chatid": item.chat_id})
        return "deleted successfully"

    def history_suggestivequestion(self, item: HistorySessionItem):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        nextrecord = list(collection.find({"chatid": item.chat_id}).sort("insertedDate", -1).limit(1))
        
        suggestiveQuestion = ["Provide a list of drivers license related bills", "Provide summary of HB 3 bill from 2024", "What are the bills where Mullin is the chief patron"]
        if item.app_type == "dmv":
            suggestiveQuestion = ["What does red symbol means?", "How is the signal to cross road?", "What red flash light represent?"]
        elif item.app_type == "vdotspec":
            suggestiveQuestion = ["What are the design consideratioins for minor channels?", "What is Littoral Drift?", "What are the materials of paint?","What are galvanic anodes?"]

        if nextrecord:
            if "Questions:" in nextrecord[0]["gptresponse"]:
                questionlist = nextrecord[0]["gptresponse"].split("Questions:")[1].split("\n")
                suggestiveQuestion = [question.replace("-","").strip() for question in questionlist if question and "div" not in question]
        return suggestiveQuestion
    
    def fetch_chathistory(self, chat_id):
        collection = self.db[settings.DB_COLLECTION_HISTORY]
        chat_historys = list(collection.find({"chatid":chat_id,"gptresponse":{"$not":{"$regex":"I apologize, but there is no data matching your message"}}}).sort({"insertedDate":-1}).limit(10))
        return chat_historys

    def card_loaddefaultquestions(self, item:CardSessionItem):
        cardQuestions = [
                {"title": "Provide a list of drivers license related bills"},
                {"title": "Provide summary of HB 3 bill from 2024"},
                {"title": "What are the bills where Mullin is the chief patron"}
            ]
        if item.app_type == "dmv":
            cardQuestions = [
                {"title": "What does red arrow symbol means?"},
                {"title": "What is the sign for crossing road?"},
                {"title": "What does red flash light denotes?"}
            ]
        elif item.app_type == "vdotspec":
            cardQuestions = [
                {"title": "What are the design consideratioins for minor channels?"},
                {"title": "What is Littoral Drift?"},
                {"title": "What are the materials of paint?"},
                {"title": "What are galvanic anodes?"}
            ]

        return cardQuestions

    def listallfaqs(self):
        faqs = [
            {"question": "What information can I find about a legislative bill?", "answer": """You can find various details about legislative bills, including: - Bill Number - Bill Title - Bill Chief Patron - Year of Introduction - Bill Status - Summary and Analysis"""},
            {"question": "How can I search for a legislative bill?", "answer": """You can search for a legislative bill using different parameters, such as: - Bill Number - Chief Patron - Year of Introduction - Keywords in the Bill Text - Simply enter your search criteria, and the system will provide the relevant results"""},
            {"question": "How do I find bills from a specific legislative session or year?", "answer": """A bill is a proposal for new legislation or an amendment to existing legislation that must be approved by both houses of the legislature and signed by the executive to become law. A resolution is a formal expression of opinion, will, or intent by the legislature, which may not have the force of law."""},
            {"question": "Can I view the full text of a bill?", "answer": """Yes, you can view the full text of a bill. After finding the bill through a search, you will have the option to view or download the complete text, including any amendments and revisions."""},
            {"question": "How can I track the progress of a bill?", "answer": """You can track the progress of a bill by subscribing to updates. Once you find the bill you are interested in, look for the option to receive notifications about its status changes, committee meetings, and voting outcomes."""},
            {"question": "Where can I find voting records for a bill?", "answer": """Voting records for a bill are available alongside the bill details. After locating the bill, you can view the voting records to see how each legislator voted on the bill at different stages."""}
        ]
        return faqs

def get_mongo_service():
    return MongoDBService()