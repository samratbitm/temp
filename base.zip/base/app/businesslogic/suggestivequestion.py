import json
from app.models.models import HistorySessionItem
from app.services.mongo_service import MongoDBService, get_mongo_service
from app.services.openai_service import OpenAIService, get_openai_service
from app.config import settings
from collections import defaultdict
from app.utils.mongo_query_converter import parse_operation
from app.utils.common import is_valid_json
from fastapi import Depends



class SuggestiveQuestion:
    def __init__(self, mongo_service: MongoDBService = Depends(get_mongo_service),
                 openai_service: OpenAIService = Depends(get_openai_service)):
        self.mongo_service = mongo_service
        self.openai_service = openai_service
        self.num_result_default = 500    


    def generate_suggestivequestion(self,item: HistorySessionItem):

        suggestiveQuestion = self.suggestive_question(item.app_type)
        try:
            chat_historys = self.chat_historys(item.chat_id)
            chat_history = [] 
            if len(chat_historys)> 0:
                    for chatrecord in chat_historys:
                        chat_history.append({"role": "user", "content": chatrecord["userquery"]})
                        chat_history.append({"role": "assistant", "content": chatrecord["gptresponse"]})

                    current_user_question = "Suggest three or more short relevant questions based on Chat History"

                    # Create prompt
                    prompt_template = """
                    ### Instructions
                    You are an assistant to generate few question based on last assistant responese from Chat History
                    1. Only suggeest question based on chat_history data.                                      
                    2. Always Suggest three or more short relevant questions based on Chat History.
                    3. Question should be as such that, its answers should be easily deduced from Chat History itself.
                    4. Alwasy respond in below JSON format:
                    {{                        
                        "SuggestiveQuestions": ["suggistive question 1?","suggistive question 2?","suggistive question 3?"]
                                                
                    }}

                    ### Chat History
                    {chat_history}
                    """

                    chat_history_str = "\n".join([f"{entry['role']}: {entry['content']}" for entry in chat_history])
                    prompt = prompt_template.format(
                        chat_history=chat_history_str,
                        current_user_question=current_user_question,
                        reformulated_question="",
                        answer=""
                    )

                    messages=[
                        {"role": "system", "content": prompt},
                        {"role": "user", "content": current_user_question},
                    ]    

                    response = self.openai_service.suggiestive_query(messages)
                    response = response.replace("json","").replace("```","").replace("\n","")
                    suggestiveQuestion = json.loads(response)["SuggestiveQuestions"]

        except Exception as err:
            print(err)                    
            suggestiveQuestion = self.suggestive_question(item.app_type)
                    
        return suggestiveQuestion  
    
    def chat_historys(self, chat_id):
        return self.mongo_service.fetch_chathistory(chat_id)
    
    def suggestive_question(self, app_type):
        suggestiveQuestion = ["Provide a list of drivers license related bills", "Provide summary of HB 3 bill from 2024", "What are the bills where Mullin is the chief patron"]
        if app_type == "dmv":
            suggestiveQuestion = ["What does red symbol means?", "How is the signal to cross road?", "What red flash light represent?"]
        elif app_type == "vdotspec":
            suggestiveQuestion = ["What are the design consideratioins for minor channels?", "What is Littoral Drift?", "What are the materials of paint?","What are galvanic anodes?"] 

        return suggestiveQuestion