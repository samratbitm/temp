
Project Structure:
project/
├── main.py
├── app/
│   ├── __init__.py
│   ├── routers/
│   │   ├── __init__.py
│   │   └── items.py
│   ├── models/
│   │   ├── __init__.py
│   │   └──  models.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── openai_service.py
│   │   ├── mongo_service.py
│   │   └──  dmv_service.py
│   ├── businesslogic/
│   │   ├── __init__.py
│   │   ├── vector_search.py
│   │   ├── response_generator.py
│   │   ├── query_replacer.py
│   │   └──  query_converter.py
│   ├── utils/
│   │   └──  common.py
│   ├── config.py
│   ├── middlewares.py
├── .env
├── .env.dev
├── .env.prod
├── requirements.txt
└── README.md